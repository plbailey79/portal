package H0513;

public class WordScrambler
{
    private String[] scrambledWords;
    
    public WordScrambler(String[] wordArr)
    {
        scrambledWords = wordArr; // mixedWords(wordArr);
    }
    
    private String recombine(String word1, String word2)
    {
        return word1.substring(0, word1.length() / 2) 
             + word2.substring(word1.length() / 2);
    }
    
    public boolean checkValidLength(String word1, String word2)
    {
        // First obtain the recombined word with a call to recombine.
        // Then, compare the length of the recombined word with
        // the lengths of each of the original words.
        // If it is shorter than one of them, return true,
        // otherwise return false.
        // To do this, we need the recombine method, and we
        // need one new variable to trap the recombined word.
        return false;
    }
    
    private static void test(String word1, String word2)
    {
        String[] pointless = { "Thing1" };
        WordScrambler ws = new WordScrambler(pointless);
        System.out.printf("recombine(%s, %s) = %s\n", 
                word1, word2, ws.recombine(word1, word2));   
    }
    
    public static void main(String[] args)
    {
        test("apple", "pear");
        test("pear", "apple");
    }
}
