package H0513;

import java.util.ArrayList;

public class Stats
{
    private ArrayList<ScoreInfo> scoreList;
    
    public Stats()
    {
        scoreList = new ArrayList<ScoreInfo>();
    }
    
    public boolean record(int score)
    {
        int k = 0;
        while (k < scoreList.size())
        {
            ScoreInfo si = scoreList.get(k);
            if (si.getScore() > score) break;
            if (si.getScore() == score)
            {
                si.increment();
                return false;
            }
            k++;
        }
        ScoreInfo sn = new ScoreInfo(score);
        sn.increment();
        scoreList.add(k, sn);
        return true;
    }
    
    public void recordScores(int[] stuScores)
    {
        for (int score : stuScores)
        {
            record(score);
        }
    }
    
    public double getSeniorPercent(int score)
    {
        // We need to modify the ScoreInfo class to indicate
        // whether a student is a senior.  The most flexible
        // change would probably be to create a new instance variable
        // grade, from 1 to 12.  We would also like to modify
        // the constructor to take and store this value.
        // Finally, a getter method should be added to ScoreInfo.
        return 0;
    }
    
    public static void main(String args[])
    {
        int[] scores = 
            { 90, 90, 80, 80, 80, 85, 82, 87, 99, 72, 33, 62, 88, 
              86, 80, 90, 92, 88, 66, 83, 72, 93, 85, 17, 99, 98 };
        Stats stats = new Stats();
        stats.recordScores(scores);
        
        for (ScoreInfo si : stats.scoreList)
        {
            System.out.printf("score: %d  freq: %d\n", si.getScore(), si.getFrequency());
        }
    }
}
