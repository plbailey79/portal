package starter;

import graphtheory.*;
import java.util.List;
import java.util.ArrayList;

public class Graph
{
    private ArrayList<Vertex> V = new ArrayList<Vertex>();
    private ArrayList<Edge> E = new ArrayList<Edge>();
    
    public String toString()
    {
        return V.toString() + " | " + E.toString();
    }
    
    public int sizeV()
    {
        return V.size();
    }
    
    public int sizeE()
    {
        return E.size();
    }
    
    public Vertex getV(int i)
    {
        return V.get(i);
    }
    
    public Edge getE(int i)
    {
        return E.get(i);
    }
    
    public boolean add(Vertex v, List<Vertex> L)
    {
        boolean r = false;
        if (!L.contains(v))
        {
            L.add(v);
            r = true;
        }
        return r;
    }
    
    public boolean add(Vertex v)
    {
        return add(v, V);
    }
    
    public boolean add(int a)
    {
        return add(new Vertex(a));
    }
    
    public boolean add(Edge e)
    {
        boolean r = false;
        if (!contains(e))
        {
            add(e.v());
            add(e.w());
            r = E.add(e);
        }
        return r;
    }
    
    public boolean add(int a, int b)
    {
        return add(new Edge(a, b));
    }
    
    public boolean contains(Vertex v)
    {
        return V.contains(v);
    }
    
    public boolean contains(Edge e)
    {
        return E.contains(e);
    }    
    
    public void print()
    {
        System.out.println("Vertices:");
        for (Vertex vertex : V)
        {
            System.out.println(vertex);
        }
        System.out.println("Edges:");
        for (Edge edge : E)
        {
            System.out.println(edge);
        }
    }
    
    public int degree(Vertex v)
    {
        if (!contains(v)) return -1;
        int d = 0;
        for (Edge e : E)
        {
            if (e.involves(v)) d++;
        }
        return d;
    }
}
