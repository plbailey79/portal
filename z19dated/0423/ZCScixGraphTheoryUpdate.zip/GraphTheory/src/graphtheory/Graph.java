package graphtheory;

import java.util.List;
import java.util.ArrayList;

public class Graph
{
    private ArrayList<Vertex> V = new ArrayList<Vertex>();
    private ArrayList<Edge> E = new ArrayList<Edge>();
    
    public String toString()
    {
        return V.toString() + " | " + E.toString();
    }
    
    public int sizeV()
    {
        return V.size();
    }
    
    public int sizeE()
    {
        return E.size();
    }
    
    public Vertex getV(int i)
    {
        return V.get(i);
    }
    
    public Edge getE(int i)
    {
        return E.get(i);
    }
    
    public boolean add(Vertex v, List<Vertex> L)
    {
        boolean r = false;
        if (!L.contains(v))
        {
            L.add(v);
            r = true;
        }
        return r;
    }
    
    public boolean add(Vertex v)
    {
        return add(v, V);
    }
    
    public boolean add(int a)
    {
        return add(new Vertex(a));
    }
    
    public boolean add(Edge e)
    {
        boolean r = false;
        if (!contains(e))
        {
            add(e.v());
            add(e.w());
            r = E.add(e);
        }
        return r;
    }
    
    public boolean add(int a, int b)
    {
        return add(new Edge(a, b));
    }
    
    public boolean contains(Vertex v)
    {
        return V.contains(v);
    }
    
    public boolean contains(Edge e)
    {
        return E.contains(e);
    }    
    
    public void print()
    {
        System.out.println("Vertices:");
        for (Vertex vertex : V)
        {
            System.out.println(vertex);
        }
        System.out.println("Edges:");
        for (Edge edge : E)
        {
            System.out.println(edge);
        }
    }
    
    public int degree(Vertex v)
    {
        if (!contains(v)) return -1;
        int d = 0;
        for (Edge e : E)
        {
            if (e.involves(v)) d++;
        }
        return d;
    }
    
    public List<Vertex> adjacents(Vertex v)
    {
        List<Vertex> L = new ArrayList<Vertex>();
        if (!contains(v)) return L;
        
        for (Edge e : E)
        {
            if (e.involves(v))
            {
                L.add(e.other(v));
            }
        }
        return L;
    }
    
    public List<Vertex> associates(Vertex v)
    {
        List<Vertex> A = new  ArrayList<Vertex>();
        if (!contains(v)) return A;
        A.add(v);
        for (int i = 0; i < A.size(); i++)
        {
            List<Vertex> L = adjacents(A.get(i));
            for (int k = 0; k < L.size(); k++)
            {
                if (A.indexOf(L.get(k)) < 0)
                {
                    A.add(L.get(k));
                }
            }
        }
        return A;
    }

    public boolean isConnected()
    {
        boolean b = false;
        if (V.size() > 0)
        {
            b = associates(V.get(0)).size() == V.size();
        }
        return b;
    }
    
    public int numberOfComponents()
    {
        int n = 0;
        List<Vertex> W = (List<Vertex>)V.clone();
        while (W.size() > 0)
        {
            List<Vertex> A = associates(W.get(0));
            for (Vertex v : A)
            {
                W.remove(v);
            }
            n++;
        }
        return n;
    }
    
    public List<Vertex> seekTree(Vertex v)
    {
        if (!V.contains(v)) return null;
        List<Vertex> A = new ArrayList<Vertex>();
        List<Edge> D = new ArrayList<Edge>();
        A.add(v);
        for (int i = 0; i < A.size(); i++)
        {
            v = A.get(i);
            for (Edge e : E)
            {
                if (e.involves(v) && !D.contains(e))
                {
                    Vertex w = e.other(v);
                    if (A.contains(w)) return null;
                    A.add(w);
                    D.add(e);
                }
            }
        }
        return A;
    }
    
    public boolean isTree()
    {
        if (V.size() < 1) return false;
        List<Vertex> A = seekTree(V.get(0));
        if (A == null) return false;
        if (A.size() < V.size()) return false;
        return true;
    }
    
    public boolean isForest()
    {
        List<Vertex> W = (List<Vertex>)V.clone();
        while (W.size() > 0)
        {
            List<Vertex> A = seekTree(W.get(0));
            if (A == null) return false;
            if (A.size() == W.size()) return true;
            for (Vertex v : A)
            {
                W.remove(v);
            }
        }
        return true;
    }
    
    public static Graph component(Graph G, Vertex v)
    {
        Graph C = new Graph();
        if (!G.contains(v)) return C;
        C.add(v);
        for (int i = 0; i < C.V.size(); i++)
        {
            v = C.V.get(i);
            List<Vertex> L = G.adjacents(v);
            for (int k = 0; k < L.size(); k++)
            {
                Vertex w = L.get(k);
                C.add(new Edge(v, w));
            }
        }
        return C;
    }
    
    public static Graph merge(Graph G, Graph H)
    {
        Graph M = new Graph();
        for (Vertex v : G.V)
        {
            M.add(v);
        }
        for (Edge e : G.E)
        {
            M.add(e);
        }
        for (Vertex v : H.V)
        {
            M.add(v);
        }
        for (Edge e : H.E)
        {
            M.add(e);
        }
        return M;
    }
}
