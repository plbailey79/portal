public class Program
{
    public static void main(String[] args)
    {
        Prob1();
    }
    
    public static void Prob1()
    {
        RouteCipher rc = new RouteCipher(2, 3);
        String inp = "Now is the time for all good men.";
        String out = rc.encryptMessage(inp);
        System.out.println(inp);
        System.out.println(out);
    }
}
