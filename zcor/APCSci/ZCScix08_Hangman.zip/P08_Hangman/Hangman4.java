import java.util.Random;
import java.util.Scanner;

class Hangman4
{
    public static String[] words =
    {
        "AARDVARK",
        "BEETLE",
        "CAMEL",
        "DINGO",
        "ELEPHANT",
        "FLAMINGO",
        "GOOSE",
        "HOG",
        "IGUANA",
        "JAGUAR",
		"KANGAROO",
		"LEOPARD",
		"MOOSE",
		"NARWHAL",
		"OSTRICH",
		"PENGUIN",
		"QUAIL",
		"RHINOCEROS",
		"STORK",
		"TIGER",
		"UNICORN",
		"VIPER",
		"WHALE",
		"XENOP",
		"YAK",
		"ZEBRA"
    };
	
	private static final int maxWrong = 6;
    
    private static Random random = new Random();
	private static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args)
    {
        Prog3b();
    }
    
    public static void Prog1()
    {
        int k = 0;
        while (k < words.length)
        {
            String s = words[k];
            if (s.length() < 1) break;
            System.out.printf("%3d) %s\n", k+1, s);
            k++;
        }
    }
    
    public static void Prog2a()
    {
        for (int i = 1; i <= 10; i++)
        {
            String s = randomWord();
            System.out.printf("%3d) %s\n", i, s);
        }
    }
    
    public static void Prog2b()
    {
        for (int i = 1; i <= 10; i++)
        {
            String a = randomWord();
            String b = blankWord(a);
            System.out.printf("%3d) %-20s %-20s\n", i, a, b);
        }
    }
    
    public static void Prog2c()
    {
        for (int i = 1; i <= 10; i++)
        {
            String a = randomWord();
            String b = blankWord(a);
            b = adjustWord(a, b, 'A');
            System.out.printf("%3d) %-20s %-20s\n", i, a, b);
        }
    }
	
	public static void Prog3a()
	{
		char g = '@';
		while (g != '.')
		{
			g = guess();
			System.out.println("> " + g);
		}
	}
	
	public static void Prog3b()
	{
		String a = randomWord();
		play(a);
	}
	
	public static void play(String a)
	{
		String b = blankWord(a);
		String w = "";
		char g = '@';
		
		while (true)
		{
			showGallows(w.length());
			System.out.println(b + " [" + w + "]");
			if (a.equals(b))
			{
				System.out.println("You win!");
				break;
			}
			if (w.length() >= maxWrong)
			{
				System.out.println(a);
				System.out.println("Too many guesses, YOU LOSE!");
				break;
			}
			g = guess();
			if (g == '.')
			{
				System.out.println("Quitter!");
				break;
			}
			if (a.contains(g + ""))
			{
				b = adjustWord(a, b, g);
			}
			else
			{
				w += g;
			}
			System.out.println();
		}
	}
	
    public static char guess()
    {
        String s;
        char c;
        while (true)
        {
            System.out.print("Guess: ");
            s = scanner.nextLine().toUpperCase();
            if (s.length() == 1)
            {
                c = s.charAt(0);
                if ((c >= 'A' && c <= 'Z') || c == '.') break;
            }
        }
        return c;
    }
    
    public static String randomWord()
    {
        return words[random.nextInt(words.length)];
    }
    
    public static String blankWord(String s)
    {
        char[] tA = new char[s.length()];
        for (int i = 0; i < tA.length; i++)
        {
            tA[i] = '_';
        }
        return new String(tA);
    }
    
    public static String adjustWord(String s, String t, char g)
    {
        if (s.length() == t.length())
        {
            char[] sA = s.toCharArray();
            char[] tA = t.toCharArray();
            
            for (int i = 0; i < sA.length;i++)
            {
                if (sA[i] == g) tA[i] = g;
            }
            t = new String(tA);
        }
        return t;
    }
	
	public static void showGallows(int n)
	{
		char[][] m = new char[8][8];
		
		m[0] = "--------".toCharArray();
		m[1] = "|     | ".toCharArray();
		m[2] = "|       ".toCharArray();
		m[3] = "|       ".toCharArray();
		m[4] = "|       ".toCharArray();
		m[5] = "|       ".toCharArray();
		m[6] = "|       ".toCharArray();
		m[7] = "========".toCharArray();
		
		if (n > 0) m[2][6] = 'O';
		if (n > 1) m[3][6] = '|';
		if (n > 2) m[3][5] = '/';
		if (n > 3) m[3][7] = '\\';
		if (n > 4) m[4][5] = '/';
		if (n > 5) m[4][7] = '\\';
		
		for (int i = 0; i < 8; i++)
		{
			for (int j = 0; j < 8; j++)
			{
				System.out.print(m[i][j]);
			}
			System.out.println();
		}
		System.out.println();
	}
}
