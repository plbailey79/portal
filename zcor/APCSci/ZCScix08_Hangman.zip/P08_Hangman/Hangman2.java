import java.util.Random;

class Hangman2
{
    public static String[] words =
    {
        "AARDVARK",
        "BEETLE",
        "CAMEL",
        "DINGO",
        "ELEPHANT",
        "FLAMINGO",
        "GOOSE",
        "HOG",
        "IGUANA",
        "JAGUAR"
    };
    
    private static Random random = new Random(0);

    public static void main(String[] args)
    {
        Prog2c();
    }
    
    public static void Prog1()
    {
        int k = 0;
        while (k < words.length)
        {
            String s = words[k];
            if (s.length() < 1) break;
            System.out.printf("%3d) %s\n", k+1, s);
            k++;
        }
    }
    
    public static void Prog2a()
    {
        for (int i = 1; i <= 10; i++)
        {
            String s = randomWord();
            System.out.printf("%3d) %s\n", i, s);
        }
    }
    
    public static void Prog2b()
    {
        for (int i = 1; i <= 10; i++)
        {
            String a = randomWord();
            String b = blankWord(a);
            System.out.printf("%3d) %-20s %-20s\n", i, a, b);
        }
    }
    
    public static void Prog2c()
    {
        for (int i = 1; i <= 10; i++)
        {
            String a = randomWord();
            String b = blankWord(a);
            b = adjustWord(a, b, 'A');
            System.out.printf("%3d) %-20s %-20s\n", i, a, b);
        }
    }
    
    public static String randomWord()
    {
        return words[random.nextInt(words.length)];
    }
    
    public static String blankWord(String s)
    {
        char[] tA = new char[s.length()];
        for (int i = 0; i < tA.length; i++)
        {
            tA[i] = '_';
        }
        return new String(tA);
    }
    
    public static String adjustWord(String s, String t, char g)
    {
        if (s.length() == t.length())
        {
            char[] sA = s.toCharArray();
            char[] tA = t.toCharArray();
            
            for (int i = 0; i < sA.length;i++)
            {
                if (sA[i] == g) tA[i] = g;
            }
            t = new String(tA);
        }
        return t;
    }
}
