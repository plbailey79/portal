class Hangman1
{
    public static String[] words =
    {
        "AARDVARK",
        "BEETLE",
        "CAMEL",
        "DINGO",
        "ELEPHANT",
        "FLAMINGO",
        "GOOSE",
        "HOG",
        "IGUANA",
        "JAGUAR"
    };

    public static void main(String[] args)
    {
        Prog1();
    }
    
    public static void Prog1()
    {
        int k = 0;
        while (k < words.length)
        {
            String s = words[k];
            if (s.length() < 1) break;
            System.out.printf("%3d) %s\n", k+1, s);
            k++;
        }
    }
}
