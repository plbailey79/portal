import java.util.Random;

public class Graction implements Comparable<Graction>
{
	private int top = 0;
	private int bot = 1;
	
	public int getTop() { return top; }
	public int getBot() { return bot; }
	
	public Graction()
	{ 
		install(0, 1);
	}
	
	public Graction(int top)
	{
		install(top, 1);
	}
	
	public Graction(int top, int bot)
	{
		install(top, bot);
	}
	
	private void install(int a, int b)
	{
		if (a == 0) return;
		if (b == 0) return;
		if (b < 0)
		{
			a = -a;
			b = -b;
		}
		int d = Number.gcd(a, b);
		if (d > 1)
		{
			a /= d;
			b /= d;
		}
		top = a;
		bot = b;
	}
	
	public String toString()
	{
		if (bot == 1) return top + "";
		return top + "/" + bot;
	}
	
	public boolean equals(Graction that)
	{
		return equals(this, that);
	}
	
	public int compareTo(Graction that)
	{
		return compare(this, that);
	}
	
	public float toFloat()
	{
		return top / (float)bot;
	}
	
	public static boolean equals(Graction x, Graction y)
	{
		return compare(x, y) == 0;
	}
	
	public static int compare(Graction x, Graction y)
	{
		long left = (long)x.top * (long)y.bot;
		long right = (long)x.bot * (long)y.top;
		if (left < right) return -1;
		if (left > right) return 1;
		return 0;
		//return x.top * y.bot - x.bot * y.top;
	}
	
	public static Graction negative(Graction x)
	{
		return new Graction(-x.top, x.bot);
	}
	
	public static Graction reciprocal(Graction x)
	{
		return new Graction(x.bot, x.top);
	}
	
	public static Graction add(Graction x, Graction y)
	{
		return new Graction(x.top * y.bot + y.top * x.bot, x.bot * y.bot);
	}
	
	public static Graction subtract(Graction x, Graction y)
	{
		return new Graction(x.top * y.bot - y.top * x.bot, x.bot * y.bot);
	}
	
	public static Graction multiply(Graction x, Graction y)
	{
		return new Graction(x.top * y.top, x.bot * y.bot);
	}
	
	public static Graction divide(Graction x, Graction y)
	{
		return new Graction(x.top * y.bot, x.bot * y.top);
	}
	
	public static Graction[] generate(int length)
	{
		if (length < 0) length = 0;
		if (length > 10000) length = 10000;
		Random random = new Random();
		Graction[] a = new Graction[length];
		for (int i = 0; i < a.length; i++)
		{
			int top = random.nextInt(10000);
			int bot = random.nextInt(10000);
			a[i] = new Graction(top, bot);
		}
		return a;
	}
	
	public static Graction sqrt(Graction x)
	{
		Graction seed = new Graction(1);
		int depth = 5;
		return sqrt(x, seed, depth);
	}
	
	public static Graction sqrt(Graction x, Graction seed, int depth)
	{
		Graction q = seed;
		Graction h = new Graction(1, 2);
		int k = 0;
		while (k < depth)
		{
			q = multiply(h, add(q, divide(x, q)));
			System.out.printf(
				"x: %s  q: %s  %.3f\n",
				x,
				q,
				q.toFloat());
			k++;
		}
		return q;
	}
}