public class Grade
{
	public static int test(int a1, int b1, int a2, int b2)
	{
		System.out.printf("In1: %d/%d   In2: %d/%d\n", a1, b1, a2, b2);
		
		int p = 0;
		Graction x1 = new Graction(a1, b1);
		Graction x2 = new Graction(a2, b2);
		
		Fraction y1 = new Fraction(a1, b1);
		Fraction y2 = new Fraction(a2, b2);
		
		//System.out.println("Graction1: %s  Fraction1: %s\n", x1, y1);
		//System.out.println("Graction2: %s  Fraction2: %s\n", x2, y2);
		
		p += compare("primary", 	x1, y1);
		p += compare("secondary",	x2, y2);
		p += compare("equals", 		x1.equals(x2), y1.equals(y2));
		p += compare("compare", 	x1.compareTo(x2), y1.compareTo(y2));
		p += compare("negative", 	Graction.negative(x1), Fraction.negative(y1));
		p += compare("reciprocal", 	Graction.reciprocal(x1), Fraction.reciprocal(y1));
		p += compare("add", 		Graction.add(x1, x2), Fraction.add(y1, y2));
		try
		{
		p += compare("subtract", 	Graction.subtract(x1, x2), Fraction.subtract(y1, y2));
		} catch (Exception e) { }
		p += compare("multiply", 	Graction.multiply(x1, x2), Fraction.multiply(y1, y2));
		p += compare("divide", 		Graction.divide(x1, x2), Fraction.divide(y1, y2));
		return p;
	}
	
	public static int compare(String s, Graction x, Fraction y)
	{
		int p = 0;
		if (x.getTop() == y.getTop() && x.getBot() == y.getBot()) p += 1;
		System.out.printf("%10s  Graction: %10.10s  Fraction: %10.10s  Score: %d\r\n",
			s, x, y, p);
		return p;
	}
	
	public static int compare(String s, boolean a, boolean b)
	{
		int p = 0;
		if (a == b) p += 1;
		System.out.printf("%10s  Graction: %10.10s  Fraction: %10.10s  Score: %d\r\n",
			s, a, b, p);
		return p;
	}
	
	public static int compare(String s, int m, int n)
	{
		int p = 0;
		if (m == 0 && n == 0) p += 1;
		else if (m < 0 && n < 0) p += 1;
		else if (m > 0 && n > 0) p += 1;
		
		
		System.out.printf("%10s  Graction: %10.10s  Fraction: %10.10s  Score: %d\r\n",
			s, m, n, p);
		return p;
	}
	
	public static void main(String[] args)
	{
		int score = 50;
		int grade = 0;
		int total = 100;
		
		boolean f1 = false, f2 = false;
		try
		{
			Fraction y1 = new Fraction(0, 2);
			f1 = y1.getTop() == 0 && y1.getBot() == 1;
		}
		catch (Exception e) { }
		try
		{
			Fraction y2 = new Fraction(2, 0);
			f2 = y2.getTop() == 0 && y2.getBot() == 1;
		}
		catch (Exception e) { }
		
		score += f1 ? 5 : 0;
		score += f2 ? 5 : 0;
		
		System.out.printf("Handles zero top: %s\n", f1);
		System.out.printf("Handles zero bot: %s\n", f2);
		
		score += test(1, 2, 1, 2);
		score += test(2, 4, 3, 6);
		score += test(123, 498, 221, 4234);
		score += test(4234, 231, 4838, 22);
		grade = (int)((double)score / total * 100);
		System.out.println();
		System.out.printf("Score: %d  Grade: %d\r\n", score, grade);
	}
}