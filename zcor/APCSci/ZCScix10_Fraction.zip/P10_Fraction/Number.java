public class Number
{
	public static int gcd(int m, int n)
	{
		if (n == 0 || m == 0) return 0;
		if (n < 0) n = -n;
		if (m < 0) m = -m;
		int r = 0;
		while ((r = n % m) > 0)
		{
			n = m;
			m = r;
		}
		return m;
	}
	
	public static int lcm(int m, int n)
	{
		int d = gcd(m, n);
		if (d ==0) return 0;
		return m * n / d;
	}
}
