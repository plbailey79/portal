import java.util.Arrays;

public class Program
{
	public static void main(String[] args)
	{
		test5();
	}
	
	public static void test6()
	{
		Fraction x = new Fraction(5);
		Fraction q = Fraction.sqrt(x);
		Fraction s = Fraction.multiply(q, q);
		System.out.printf(
			"x: %s  q: %s  %.3f  (%.3f)  %s  %s\n",
			x,
			q,
			q.toFloat(),
			q.toFloat() * q.toFloat(),
			s,
			s.toFloat());
		
	}
	
	public static void test5()
	{
		Fraction[] a = Fraction.generate(10);
		show(a);
		//System.out.println(Arrays.toString(a));
		Arrays.sort(a);
		show(a);
	}
	
	public static void show(Fraction[] a)
	{
		System.out.println();
		for (int i = 0; i < a.length; i++)
		{
			System.out.printf("%10s  %.2f\n", a[i], a[i].toFloat());
		}
	}
	
	public static void test4()
	{
		Fraction x = new Fraction(50, 18);
		Fraction y = new Fraction(96, 15);
		Fraction z = new Fraction(75, 27);
		Fraction w = new Fraction(25, 9);
		
		System.out.printf("%s -> %s\n", x, x.toFloat());
		System.out.printf("0 - %s = %s\n", x, Fraction.negative(x));
		System.out.printf("1 / %s = %s\n", x, Fraction.reciprocal(x));
		System.out.printf("%s + %s = %s\n", x, y, Fraction.add(x, y));
		System.out.printf("%s - %s = %s\n", x, y, Fraction.subtract(x, y));
		System.out.printf("%s * %s = %s\n", x, y, Fraction.multiply(x, y));
		System.out.printf("%s / %s = %s\n", x, y, Fraction.divide(x, y));
		System.out.printf("%s = %s = %s\n", x, y, Fraction.equals(x, y));
		System.out.printf("%s = %s = %s\n", x, x, Fraction.equals(x, x));
		System.out.printf("%s < %s -> %s\n", x, y, Fraction.compare(x, y));
		System.out.printf("%s < %s -> %s\n", x, w, Fraction.compare(x, w));
		System.out.printf("%s < %s -> %s\n", y, z, Fraction.compare(y, z));
		
	}
}