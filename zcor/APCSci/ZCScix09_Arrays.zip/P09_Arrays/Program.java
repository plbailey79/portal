public class Program
{
	public static void main(String[] args)
	{
		test1();
	}
	
	public static void test1()
	{	
		int[] a = Arrays.randomize(10);
		int[] b = Arrays.clone(a);
		b[2] = 1;
		b[5] = -2;
		System.out.println(Arrays.toString(a));
		System.out.println(Arrays.toString(b));
		b = Arrays.reverse(a);
		System.out.println(Arrays.toString(b));
		System.out.printf("max = %d\n", Arrays.maximum(a));
		System.out.printf("min = %d\n", Arrays.minimum(a));
		System.out.printf("count(1) = %d\n", Arrays.count(a, 1));
		System.out.printf("find(1) = %d\n", Arrays.find(a, 1));
		System.out.printf("sum = %d\n", Arrays.sum(a));
		System.out.printf("product = %d\n", Arrays.product(a));
		System.out.printf("mean = %f\n", Arrays.mean(a));
		Arrays.sort(a);
		System.out.println(Arrays.toString(a));
	}
	
	public static void test2()
	{
		int[] x = { 2, 3, 5, 7, 11, 13, 17};
		int[] v = { 0, 1, 0, 1,  0,  1,  0};
		
		System.out.println(Arrays.toString(Arrays.rotate(x, 3)));
		System.out.println(Arrays.toString(Arrays.reflect(x)));
		System.out.println(Arrays.toString(Arrays.translate(x, v)));
	}
}