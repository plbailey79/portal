import java.util.Random;

public class Arrays
{
    private static Random random = new Random();
    
    public static int[] randomize(int z)
    {
        int[] a = new int[z];
        for (int i = 0; i < a.length; i++)
        {
            a[i] = random.nextInt(100) + 1;
        }
        return a;
    }
    
    public static int[] clone(int[] x)
    {
        int[] a = new int[x.length];
        for (int i = 0; i < x.length; i++)
        {
            a[i] = x[i];
        }
        return a;
    }
    
    public static int[] rotate(int[] x, int n)
    {
        int i = n % x.length;
        int k = i;
        int a = x[0], b = 0;
        while (i > 0)
        {
            b = x[i];
            x[i] = a;
            a = b;
            i = (i + k) % x.length;
        }
        x[0] = b;
        return x;
    }
    
    public static int[] reflect(int[] x)
    {
        for (int i = 0; i < x.length/2; i++)
        {
            int j = x.length - i - 1;
            int t = x[i];
            x[i] = x[j];
            x[j] = t;
        }
        return x;
    }
    
    public static int[] translate(int[] x, int[] v)
    {
        int k = x.length <= v.length ? x.length : v.length;
        for (int i = 0; i < x.length; i++)
        {
            x[i] += v[i];
        }
        return x;
    }
    
    public static int[] reverse(int[] x)
    {
        int[] a = new int[x.length];
        for (int i = 0; i < x.length; i++)
        {
            a[i] = x[x.length - i - 1];
        }
        return a;
    }
    
    public static int maximum(int[] x)
    {
        int k = 0;
        for (int i = 1; i < x.length; i++)
        {
            if (x[i] > x[k]) k = i;
        }
        return x[k];
    }
    
    public static int minimum(int[] x)
    {
        int k = 0;
        for (int i = 1; i < x.length; i++)
        {
            if (x[i] < x[k]) k = i;
        }
        return x[k];
    }
    
    public static int count(int[] x, int n)
    {
        int c = 0;
        for (int i = 0; i < x.length; i++)
        {
            if (x[i] == n) c++;
        }
        return c;
    }
    
    public static int find(int[] x, int n)
    {
        int k = 0;
        for (int i = 0; i < x.length; i++)
        {
            if (x[i] == n)
            {
                k = i + 1;
                break;
            }
        }
        return k;
    }
    
    public static long sum(int[] x)
    {
        long t = 0;
        for (int i = 0; i < x.length; i++)
        {
            t += x[i];
        }
        return t;
    }
    
    public static long product(int[] x)
    {
        long p = 1;
        for (int i = 0; i < x.length; i++)
        {
            p *= x[i];
        }
        return p;
    }
    
    public static double mean(int[] x)
    {
        long t = 0;
        for (int i = 0; i < x.length; i++)
        {
            t += x[i];
        }
        return (double)t / x.length;
    }
    
    public static void sort(int[] x)
    {
        for (int i = 0; i < x.length - 1; i++)
        {
            int k = i;
            for (int j = i + 1; j < x.length; j++)
            {
                if (x[j] < x[k]) k = j;
            }
            if (k > i)
            {
                int t = x[i];
                x[i] = x[k];
                x[k] = t;
            }
        }
    }
    
    public static void print(int[] x)
    {
        for (int i = 0; i < x.length; i++)
        {
            System.out.println(i + ") " + x[i]);
        }
    }
    
    public static String toString(int[] x)
    {
        String s = "[";
        int k = 0;
        while (k < x.length)
        {
            if (k > 0) s += ", ";
            s += x[k];
            k++;
        }
        s += "]";
        return s;
    }
}