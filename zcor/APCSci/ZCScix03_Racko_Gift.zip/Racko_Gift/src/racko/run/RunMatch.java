package racko.run;

import racko.gui.JFrameMatch;
import java.util.List;
import java.util.LinkedList;
import racko.Card;
import racko.Deck;
import racko.Player;
import racko.Rack;
import racko.Utilities;

public class RunMatch
{
    private static int t1 = 0;
    private static int t2 = 0;
    private static int gc = 0;

    private static final int DELAY1 = 128;
    private static final int DELAY2 = 1024;
    private static final int DELAY3 = 2048;
    
    private static JFrameMatch form;

    public static void main(String[] args)
    {
        form = new JFrameMatch();
        Player player1 = new racko.player.animals.PlayerFlatworm();
        Player player2 = new racko.player.animals.PlayerFrog();
        playMatch(player1, player2);
        form.close();
    }

    public static void playMatch(Player player1, Player player2)
    {   
        t1 = 0;
        t2 = 0;
        gc = 0;

        form.putName(1, Utilities.getPlayerName(player1));
        form.putName(2, Utilities.getPlayerName(player2));

        for (int i = 1; i <= 13; i++)
        {
            List<Rack> racks = playGame(player1, player2);
            show(racks);
        }
        String msg = String.format("Final Score\nPlayer 1: %d (%s)\nPlayer 2: %d (%s)\n",
                t1,
                Utilities.getPlayerName(player1),
                t2,
                Utilities.getPlayerName(player2));
        System.out.println(msg);
        Utilities.showMessageDialog(msg);
        Utilities.delay(DELAY3);
    }

    public static List<Rack> playGame(Player player1, Player player2)
    {
        List<Player> players = new LinkedList<Player>();
        players.add(player1);
        players.add(player2);

        Deck deck = new Deck(true);
        Deck pile = new Deck(false);

        deck.shuffle();

        Rack rack1 = new Rack();
        Rack rack2 = new Rack();
        List<Rack> racks = new LinkedList<Rack>();

        racks.add(rack1);
        racks.add(rack2);
        deck.deal(racks);

        player1.beginGame(new Rack(rack1));
        player2.beginGame(new Rack(rack2));

        pile.push(deck.pop());

        for (int p = 1; p <= 2; p++)
        {
            form.setName(p, Utilities.getPlayerName(players.get(p - 1)));
            form.setName(p, Utilities.getPlayerName(players.get(p - 1)));
            Rack rack = racks.get(p - 1);
            for (int k = 1; k <= 10; k++)
            {
                Card card = rack.get(k - 1);
                int v = card.value();
                form.setSlot(p, k, v);
            }
        }

        int playerNumber = gc % 2 + 1;
        int counter = 1;

        while (true)
        {
            form.setLabels(playerNumber, counter, pile.peek().value());
            Utilities.delay(DELAY1);

            Rack rack = racks.get(playerNumber - 1);
            Player player = players.get(playerNumber - 1);

            Card card = pile.peek();
            Rack temp = new Rack(rack);
            int k = player.acceptCard(temp, card);
            if (k > 0)
            {
                card = pile.pop();
            } else
            {
                if (deck.isEmpty())
                {
                    pile.shuffle();
                    deck = pile;
                    pile = new Deck(false);
                }
                card = deck.pop();
                k = player.placeCard(temp, card);
            }

            if (k >= 1 && k <= Rack.LEN)
            {
                pile.push(rack.get(k - 1));
                rack.set(k - 1, card);

                int p = playerNumber;
                int v = card.value();
                form.setSlot(p, k, v);
            } else
            {
                pile.push(card);
            }

            form.setLabels(playerNumber, counter, pile.peek().value());

            if (rack.isSorted())
            {
                break;
            }
            playerNumber = (playerNumber % 2) + 1;
            if (playerNumber == 1)
            {
                ++counter;
            }
        }
        Utilities.delay(DELAY2);
        return racks;
    }

    public static void show(List<Rack> racks)
    {
        Rack rack1 = racks.get(0);
        Rack rack2 = racks.get(1);
        int s1 = rack1.score();
        int s2 = rack2.score();
        boolean b1 = rack1.isSorted();
        boolean b2 = rack2.isSorted();
        boolean q1 = rack1.numSequence() > 0;
        boolean q2 = rack2.numSequence() > 0;
        t1 += s1;
        t2 += s2;
        gc += 1;

        int pn = b1 ? 1 : 2;

        String message = String.format("Player %d rackos!!!\nGame Player 1: %d\nGame Player 2: %d\n\nMatch Player 1: %d\nMatch Player 2: %d\n",
                pn,
                s1,
                s2,
                t1,
                t2);
        System.out.println(message);
        
        form.putScore(1, gc, s1, b1, q1);
        form.putScore(2, gc, s2, b2, q2);
        form.putTotal(1, t1);
        form.putTotal(2, t2);
    }
}
