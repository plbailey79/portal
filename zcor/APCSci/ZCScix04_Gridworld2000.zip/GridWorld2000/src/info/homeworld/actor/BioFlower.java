package info.homeworld.actor;

import info.gridworld.actor.Flower;
import java.awt.Color;

public class BioFlower extends Flower
{
    private int lifeSpan = 0;
    private int actCount = 0;
    
    public BioFlower()
    {
        super(Color.CYAN);
        lifeSpan = 10;
    }
    
    public BioFlower(int lifeSpan, Color initialColor)
    {
        super(initialColor);
        this.lifeSpan = lifeSpan;
    }
    
    public void act()
    {
        super.act();
        if (++actCount >= lifeSpan)
        {
            this.removeSelfFromGrid();
        }
    }
}
