import info.gridworld.actor.ActorWorld;
import info.gridworld.actor.Bug;
import info.gridworld.actor.Rock;
import java.awt.Color;

public class RetroBugRunner
{
    public static void main(String[] args)
    {
        ActorWorld world = new ActorWorld();
        world.add(new RetroBug());
        world.add(new RetroBug());
        world.add(new Rock(Color.BLUE));
        world.add(new Rock(Color.BLUE));
        world.add(new Rock(Color.BLUE));
        world.add(new Rock(Color.BLUE));
        world.add(new Rock(Color.BLUE));
        world.add(new Bug(Color.YELLOW));
        world.add(new CircleBug(Color.ORANGE));
        world.add(new MorticianBug(Color.GREEN));
        world.add(new MorticianBug(Color.GREEN));
        world.add(new RetroRock());
        world.show();
    }
}
