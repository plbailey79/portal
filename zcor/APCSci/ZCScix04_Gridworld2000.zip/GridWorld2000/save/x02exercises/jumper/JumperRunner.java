import info.gridworld.actor.Actor;
import info.gridworld.actor.Bug;
import info.gridworld.actor.Rock;
import info.gridworld.actor.Flower;
import info.gridworld.actor.ActorWorld;
import info.gridworld.grid.Location;
import info.gridworld.grid.UnboundedGrid;

import java.awt.Color;

public class JumperRunner
{
    public static void main(String[] args)
    {
        ActorWorld world = new ActorWorld();
		
		Rock rock1 = new Rock();
		world.add(new Location(5, 1), rock1);
		Rock rock2 = new Rock();
		world.add(new Location(7, 2), rock2);
		Rock rock3 = new Rock();
		world.add(new Location(0, 9), rock3);
		Bug bug1 = new Bug(Color.YELLOW);
		world.add(new Location(2, 3), bug1);
		Bug bug2 = new Bug(Color.ORANGE);
		world.add(new Location(6, 9), bug2);
		Bug bug3 = new Bug(Color.RED);
		world.add(new Location(8, 6), bug3);
		
		Jumper jumper = new Jumper();
        world.add(new Location(5, 5), jumper);
		
		Hopper hopper = new Hopper();
        world.add(new Location(7, 3), hopper);
        world.show();
    }
}