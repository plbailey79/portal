import info.gridworld.grid.Grid;
import info.gridworld.grid.Location;
import info.gridworld.actor.Actor;
import info.gridworld.actor.Bug;
import info.gridworld.actor.Flower;
import java.awt.Color;

public class MorticianBug extends Bug
{
	private int steps = 0;

    public MorticianBug()
    {
        setColor(Color.RED);
    }
	
    public MorticianBug(Color bugColor)
    {
        setColor(bugColor);
    }
	
    public void act()
    {
        if (steps++ < 5 && canMove())
		{
            move();
		}
        else
		{
            turn();
			steps = 0;
		}
    }
	
    public void move()
    {
        Grid<Actor> gr = getGrid();
        if (gr == null)
            return;
        Location loc = getLocation();
        Location next = loc.getAdjacentLocation(getDirection());
        if (gr.isValid(next))
            moveTo(next);
        else
            removeSelfFromGrid();
        DeadFlower flower = new DeadFlower(getColor());
        flower.putSelfInGrid(gr, loc);
    }
}