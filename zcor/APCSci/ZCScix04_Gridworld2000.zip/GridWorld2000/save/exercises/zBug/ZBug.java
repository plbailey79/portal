package exercises.zBug;

import info.gridworld.actor.Bug;
import info.gridworld.grid.Location;

public class ZBug extends Bug
{
    private int turns;
    private int steps;
    private int sideLength;

    public ZBug(int length)
    {
	turns = 0;
        steps = 0;
        sideLength = length;
	setDirection(Location.EAST);
    }

    public void act()
    {
	if (turns < 3)
	{
            if (steps < sideLength && canMove())
            {
		move();
		steps++;
            }
            else
            {
                steps = 0;
		turns += 1;
		if (turns == 1) setDirection(Location.SOUTHWEST);
		if (turns == 2) setDirection(Location.EAST);
            }
	}
    }
}
