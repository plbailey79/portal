package racko.gui;

import javax.swing.JFrame;

public class JFrameSolo extends JFrame
{
    private JPanelSolo jPanelSolo;

    public JFrameSolo()
    {
        jPanelSolo = new JPanelSolo();

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setTitle("Racko");
        setSize(320, 500);
        setLocationRelativeTo(null);
        add(jPanelSolo);
        setVisible(true);
    }

    public void close()
    {
        // dispatchEvent(new WindowEvent(this, WindowEvent.WINDOW_CLOSING));
        setVisible(false);
        dispose();
    }

    public void setName(String name)
    {
        jPanelSolo.setName(name);
    }

    public void setSlot(int k, int v)
    {
        jPanelSolo.setSlot(k, v);
    }

    public void setLabels(int c, int v)
    {
        jPanelSolo.setLabels(c, v);
    }
}
