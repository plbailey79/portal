package racko.run;

import racko.gui.JFrameTournament;
import java.util.List;
import java.util.LinkedList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.text.SimpleDateFormat;
import racko.Card;
import racko.Deck;
import racko.Player;
import racko.Rack;
import racko.Utilities;
import racko.player.animals.*;
import racko.player.current.*;

class Record implements Comparable<Record>
{
    public Player player;
    public int wins;
    public int losses;
    public int points;

    public Record(Player xplayer)
    {
        player = xplayer;
    }
    
    public int diff()
    {
        return wins - losses;
    }

    public int compareTo(Record that)
    {
        int df = this.diff() - that.diff();

        if (df == 0)
        {
            df = that.losses - this.losses;
        }
        if (df == 0)
        {
            df = this.points - that.points;
        }
        return df;
    }
}

class Match
{
    public int recno1;
    public int recno2;
    public int score1;
    public int score2;
    public int winner;

    public Match(int r1, int r2)
    {
        recno1 = r1;
        recno2 = r2;
        score1 = 0;
        score2 = 0;
        winner = 0;
    }
}

class RunTournament
{
    private static Record[] records;
    private static Match[] matches;
    
    private static JFrameTournament form;
    
    public static int t1 = 0;
    public static int t2 = 0;
    public static int gc = 0;

    private static final int DELAY1 = 32;
    private static final int DELAY2 = 128;
    private static final int DELAY3 = 2048;

//    private static final int DELAY1 = 0;
//    private static final int DELAY2 = 8;
//    private static final int DELAY3 = 64;
////   
//    private static final int DELAY1 = 16;
//    private static final int DELAY2 = 64;
//    private static final int DELAY3 = 512;

    public static void main(String[] args)
    {
        form = new JFrameTournament();
        buildTournament(getTourney2022());
        printTournament();
        printStandings();
        playTournament();
        saveStandings();
        
        Utilities.showMessageDialog("It is finished.");
        
        form.close();
    }
    
    public static String getStandings()
    {
        Record[] stand = records.clone();

        Arrays.sort(stand, Collections.reverseOrder());
        
        StringBuilder sb = new StringBuilder();
        sb.append("           Tournament Standings\r\n\r\n");
        sb.append(String.format("%-20s  %2s  %2s    [%5s]\r\n\r\n",
                "Player",
                "W",
                "L",
                "Pnts"));

        for (int i = 0; i < stand.length; i++)
        {
            Record record = stand[i];

            sb.append(String.format("%-20s  %2d  %2d    [%5d]\r\n",
                    Utilities.getPlayerName(record.player),
                    record.wins,
                    record.losses,
                    record.points));

        }
        sb.append("\r\n");
        return sb.toString();
    }
    
    public static void saveStandings()
    {
        String fileName = fileName = "Tourn" + (new SimpleDateFormat("yyyyMMddHHmmss")).format(new Date()) + ".txt";
        String pathName = System.getProperty("user.home") + "/Desktop/" + fileName;
              
        Utilities.saveText(pathName, getStandings());
    }

    public static void loadTournament(List<Player> players)
    {
        int c = 0;
        records = new Record[players.size()];
        for (Player player : players)
        {
            records[c++] = new Record(player);
        }
        
        c = 0;
        matches = new Match[records.length * (records.length - 1) / 2];
        for (int i = 0; i < records.length - 1; i++)
        {
            for (int j = i + 1; j < records.length; j++)
            {
                matches[c++] = new Match(i, j);
            }
        }
        //Collections.shuffle(Arrays.asList(matches));
    }

    public static void buildTournament(List<Player> players)
    {
        int k = 0;
        records = new Record[players.size()];
        for (Player player : players)
        {
            records[k++] = new Record(player);
        }
        
        k = 0;
        matches = new Match[records.length * (records.length - 1) / 2];
        
        int x = -1;
        int n = records.length;
        if (n % 2 == 1) 
        {
            x = n++;
        }
        
        int[][] a = new int[n / 2][2];
        for (int r = 0; r < n/2; r++)
        {
            a[r][0] = r;
            a[r][1] = r + n / 2;
        }
        
        int w = 1;
        while (true)
        {
            for (int r = 0; r < n/2; r++)
            {
                int i = a[r][0];
                int j = a[r][1];
                if (x > 0 && (i == x || j == x)) continue;
                matches[k++] = new Match(i, j);
            }
            if (++w >= n) break;
            
            // Rotate
            int t = a[0][1];
            for (int r = 1; r < n/2; r++)
            {
                a[r - 1][1] = a[r][1];
            }
            a[n/2 - 1][1] = a[n/2 - 1][0];
            for (int r = n/2 - 1; r > 1; r--)
            {
                a[r][0] = a[r - 1][0];
            }
            a[1][0] = t;
        }
    }

    public static void printTournament()
    {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < matches.length; i++)
        {
            Match match = matches[i];
            sb.append(String.format("Match# %2d  r1: %d %-20s  r2: %d %-20s\n",
                    i,
                    match.recno1,
                    Utilities.getPlayerName(records[match.recno1].player),
                    match.recno2,
                    Utilities.getPlayerName(records[match.recno2].player)));
        }
        System.out.println(sb);
    }

    public static void printStandings()
    {
        String s = getStandings();
        // System.out.println(s);
        form.setText(s);
    }

    public static void playTournament()
    {
        for (int i = 0; i < matches.length; i++)
        {
            Match match = matches[i];
            Record record1 = records[match.recno1];
            Record record2 = records[match.recno2];
            Player player1 = record1.player;
            Player player2 = record2.player;
            int w = 0;
            while (w == 0)
            {
                System.out.printf("Match# %2d %-14s vs %-14s -> ",
                        i,
                        Utilities.getPlayerName(player1),
                        Utilities.getPlayerName(player2));
                playMatch(player1, player2);
                if (t1 > t2)
                {
                    w = 1;
                    System.out.printf("  %s\n", Utilities.getPlayerName(player1));
                }
                if (t2 > t1)
                {
                    w = 2;
                    System.out.printf("  %s\n", Utilities.getPlayerName(player2));
                }
            }
            match.score1 = t1;
            match.score2 = t2;
            match.winner = w;
            matches[i] = match;
            record1.wins += (w == 1) ? 1 : 0;
            record1.losses += (w == 1) ? 0 : 1;
            record1.points += t1;
            record2.wins += (w == 2) ? 1 : 0;
            record2.losses += (w == 2) ? 0 : 1;
            record2.points += t2;
            
            printStandings();
            Utilities.delay(DELAY3);
        }
    }
    
    public static void playMatch(Player player1, Player player2)
    {   
        t1 = 0;
        t2 = 0;
        gc = 0;
        
        form.clear();

        form.putName(1, Utilities.getPlayerName(player1));
        form.putName(2, Utilities.getPlayerName(player2));

        for (int i = 1; i <= 13; i++)
        {
            List<Rack> racks = playGame(player1, player2);
            show(racks);
        }
    }

    public static List<Rack> playGame(Player player1, Player player2)
    {
        List<Player> players = new LinkedList<Player>();
        players.add(player1);
        players.add(player2);

        Deck deck = new Deck(true);
        Deck pile = new Deck(false);

        deck.shuffle();

        Rack rack1 = new Rack();
        Rack rack2 = new Rack();
        List<Rack> racks = new LinkedList<Rack>();

        racks.add(rack1);
        racks.add(rack2);
        deck.deal(racks);

        player1.beginGame(new Rack(rack1));
        player2.beginGame(new Rack(rack2));

        pile.push(deck.pop());

        for (int p = 1; p <= 2; p++)
        {
            form.setName(p, Utilities.getPlayerName(players.get(p - 1)));
            Rack rack = racks.get(p - 1);
            for (int k = 1; k <= 10; k++)
            {
                Card card = rack.get(k - 1);
                int v = card.value();
                form.setSlot(p, k, v);
            }
        }

        int playerNumber = gc % 2 + 1;
        int counter = 1;

        while (true)
        {
            form.setLabels(playerNumber, counter, pile.peek().value());
            Utilities.delay(DELAY1);

            Rack rack = racks.get(playerNumber - 1);
            Player player = players.get(playerNumber - 1);

            Card card = pile.peek();
            Rack temp = new Rack(rack);
            int k = player.acceptCard(temp, card);
            if (k > 0)
            {
                card = pile.pop();
            } else
            {
                if (deck.isEmpty())
                {
                    pile.shuffle();
                    deck = pile;
                    pile = new Deck(false);
                }
                card = deck.pop();
                k = player.placeCard(temp, card);
            }

            if (k >= 1 && k <= Rack.LEN)
            {
                pile.push(rack.get(k - 1));
                rack.set(k - 1, card);

                int p = playerNumber;
                int v = card.value();
                form.setSlot(p, k, v);
            } else
            {
                pile.push(card);
            }

            form.setLabels(playerNumber, counter, pile.peek().value());

            if (rack.isSorted())
            {
                break;
            }
            playerNumber = (playerNumber % 2) + 1;
            if (playerNumber == 1)
            {
                if (++counter > 128) break;
            }
        }
        Utilities.delay(DELAY2);
        return racks;
    }

    public static void show(List<Rack> racks)
    {
        Rack rack1 = racks.get(0);
        Rack rack2 = racks.get(1);
        int s1 = rack1.score();
        int s2 = rack2.score();
        boolean b1 = rack1.isSorted();
        boolean b2 = rack2.isSorted();
        boolean q1 = rack1.numSequence() > 0;
        boolean q2 = rack2.numSequence() > 0;
        t1 += s1;
        t2 += s2;
        gc += 1;
        
        form.putScore(1, gc, s1, b1, q1);
        form.putScore(2, gc, s2, b2, q2);
        form.putTotal(1, t1);
        form.putTotal(2, t2);
    }
        
    public static List<Player> getTourneyDemo()
    {
        List<Player> players = new LinkedList<Player>();
        
        players.add(new PlayerAmoeba());
        players.add(new PlayerFlatworm());
        players.add(new PlayerFrog());
        players.add(new PlayerTurtle());
        
        return players;
    }
        
    public static List<Player> getTourney2022()
    {
        List<Player> players = new LinkedList<Player>();
        
        players.add(new PlayerAmoeba());
        players.add(new PlayerFlatworm());
        players.add(new PlayerFrog());
        players.add(new PlayerTurtle());
        
        return players;
    }
}
