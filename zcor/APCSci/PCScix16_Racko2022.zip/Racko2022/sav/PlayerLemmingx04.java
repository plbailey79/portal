package racko;

public class PlayerLemmingx04 implements Player
{
    private Item[] items = new Item[10];
    
    public void beginGame(Rack rack)
    {
        for (int i = 0; i < 10; i++)
        {
            items[i] = new Item(i + 1, rack.get(i).value());
        }
        
        checkRack();
    }

    public int acceptCard(Rack rack, Card card) // rack is not used
    {
        int v = card.value();
        int k = getSlot(v);
        return setSlot(k, v);
    }

    public int placeCard(Rack rack, Card card) // rack is not used
    {
        int v = card.value();
        int k = getSlot(v);
        if (k == 0)
        {
            k = improveGaps(v);
        }
        return setSlot(k, v);
    }
    
    public int getSlot(int v)
    {
        int k = 0;
        for (int i = 0; i < 10; i++)
        {
            Item item = items[i];
            if (item.set) continue;
            if (item.min <= v && item.max >= v)
            {
                k = i + 1;
                break;
            }
        }
        return k;
    }
    
    public int setSlot(int k, int v)
    {
        if (k > 0)
        {
            items[k-1].min = v;
            items[k-1].max = v;
            items[k-1].val = v;
            items[k-1].set = true;
            
            if (k >= 2 && !items[k-2].set)
            {
                items[k-2].max = v - 1;
            }
            if (k <= 9 && !items[k].set)
            {
                items[k].min = v + 1;
            }
            do
            {
                smoothRanges();
            }
            while (checkRack());
        }
        return k;
    }
    
    public boolean checkRack()
    {
        boolean success = false;
        for (int i = 0; i < 10; i++)
        {
            int v = items[i].val;
            if (getSlot(v) == i + 1)
            {
                setSlot(i + 1, v);
                success = true;
            }
        }
        return success;
    }
    
    public void smoothRanges()
    {
        int lo = 0;
        int hi = 0;
        
        int i = 0;
        
        while (i < 10)
        {
            if (!items[i].set)
            {
                if (lo == 0) 
                {
                    lo = i + 1;
                    continue;
                }
                else
                {
                    hi = i + 1;
                }
            }
            if (items[i].set || hi == 10)
            {
                if (lo < hi)
                {
                    Item r1 = items[lo - 1];
                    Item r2 = items[hi - 1];
                    
                    int gap = r2.max - r1.min;
                    int dif = hi - lo + 1;
                    
                    int w = gap / dif - 1;
                    int x = gap - dif * (w + 1);
                    
                    for (int j = lo - 1; j < hi - 1; j++)
                    {
                        items[j].max =  items[j].min + w + ((x-- > 0) ? 1 : 0);
                        items[j + 1].min = items[j].max + 1;
                    }
                }
                lo = 0;
                hi = 0;
            }
            i++;
        }
    }
    
    public int improveGaps(int v)
    {
        int j = 0;
       //System.out.printf("improveGaps(%d)\n", v);
        //print(v);
        
        // pullDown
        while (j < 10)
        {
            if (!items[j].set) break;
            if (items[j].val > v) return j + 1;
            j++;
        }
        //pushUp
        j = 9;
        while (j >= 0)
        {
            if (!items[j].set) break;
            if (items[j].val < v) return j + 1;
            j--;
        }
        
        //if (v < items[0].val) k = 1;
        //else if (v > items[9].val) k = 10;
        
        return 0;
    }
    
    public void print(int v)
    {
        System.out.println("Check: " + v);
        for (int i = 0; i < 10; i++)
        {
            System.out.println(items[i]);
        }
        System.out.println();
    }

    class Item
    {
        public int min;
        public int max;
        public int val;
        public boolean set;
        
        public Item(int slot, int v)
        {
            min = (slot - 1) * 6 + 1;
            max = (slot - 1) * 6 + 6;
            val = v;
            set = false;
        }
        
        public int gap()
        {
            return max - min + 1;
        }

        public String toString()
        {
            return String.format("[%2d,%2d%c%2d:%2d]", min, max, set ? '*' : '|', gap(), val);
        }
    }
}