package racko;

public class PlayerLemmingx05 implements Player
{
    private Item[] items = new Item[10];
    
    public void beginGame(Rack rack)
    {
        for (int i = 0; i < 10; i++)
        {
            items[i] = new Item(i + 1, rack.get(i).value());
        }
        
        checkRack();
    }

    public int acceptCard(Rack rack, Card card) // rack is not used
    {
        int v = card.value();
        int k = getSlot(v);
        return setSlot(k, v);
    }

    public int placeCard(Rack rack, Card card) // rack is not used
    {
        int v = card.value();
        int k = getSlot(v);
        if (k == 0)
        {
            k = improveGaps(v);
            if (k > 0)
            {
                //System.out.printf("improvement: %d\n", k);
            }
        }
        return setSlot(k, v);
    }
    
    public int getSlot(int v)
    {
        int k = 0;
        for (int i = 0; i < 10; i++)
        {
            Item item = items[i];
            if (item.set) continue;
            if (item.min <= v && item.max >= v)
            {
                k = i + 1;
                break;
            }
        }
        return k;
    }
    
    public int setSlot(int k, int v)
    {
        if (k > 0)
        {
            items[k-1].min = v;
            items[k-1].max = v;
            items[k-1].val = v;
            items[k-1].set = true;
            
            if (k >= 2 && !items[k-2].set)
            {
                items[k-2].max = v - 1;
            }
            if (k <= 9 && !items[k].set)
            {
                items[k].min = v + 1;
            }
            do
            {
                smoothRanges();
            }
            while (checkRack());
        }
        return k;
    }
    
    public boolean checkRack()
    {
        boolean success = false;
        for (int i = 0; i < 10; i++)
        {
            int v = items[i].val;
            if (getSlot(v) == i + 1)
            {
                setSlot(i + 1, v);
                success = true;
            }
        }
        return success;
    }
    
    public void smoothRanges()
    {
        int lo = 0;
        int hi = 0;
        
        int i = 0;
        
        while (i < 10)
        {
            if (!items[i].set)
            {
                if (lo == 0) 
                {
                    lo = i + 1;
                    continue;
                }
                else
                {
                    hi = i + 1;
                }
            }
            if (items[i].set || hi == 10)
            {
                if (lo < hi)
                {
                    Item r1 = items[lo - 1];
                    Item r2 = items[hi - 1];
                    
                    int gap = r2.max - r1.min;
                    int dif = hi - lo + 1;
                    
                    int w = gap / dif - 1;
                    int x = gap - dif * (w + 1);
                    
                    for (int j = lo - 1; j < hi - 1; j++)
                    {
                        items[j].max =  items[j].min + w + ((x-- > 0) ? 1 : 0);
                        items[j + 1].min = items[j].max + 1;
                    }
                }
                lo = 0;
                hi = 0;
            }
            i++;
        }
    }
    
    // Improve Gap methods
    
    public int findStraight(int v)
    {
        int j = 0;
        while (j < 10)
        {
            if (items[j].set)
            {
                int w = items[j].val;
                if (v == w - 1 && j > 0) return j;
                if (v == w + 1 && j < 9) return j + 2;
            }
            j++;
        }
        return 0;
    }
    
    public int pullDown(int v)
    {
        int j = 0;
        while (j < 10)
        {
            if (!items[j].set) break;
            if (items[j].val > v) return j + 1;
            j++;
        }
        return 0;
    }
    
    public int pushUp(int v)
    {
        int j = 9;
        while (j >= 0)
        {
            if (!items[j].set) break;
            if (items[j].val < v) return j + 1;
            j--;
        }
        return 0;
    }
    
    public int adjustGap(int v)
    {
        int j = 0;
        while (j < 10)
        {
            if (!items[j].set)
            {
                if (items[j].min > v && j > 1 && items[j - 1].set)
                {
                    if (items[j - 2].set)
                    {
                        if (items[j - 1].val > v && items[j - 2].val < v)
                        {
                            return j;
                        }
                    }
                    else
                    {
                        int m = (items[j - 2].min + items[j].max) / 2;
                        int w = items[j - 1].val;
                        if (abs(v - m) < abs(w - m))
                        {
                            return j;
                        }
                    }
                }
                if (items[j].max < v && j < 8 && items[j + 1].set)
                {
                    if (items[j + 2].set)
                    {
                        if (items[j + 1].val < v && items[j + 2].val > v)
                        {
                            return j + 2;
                        }
                    }
                    else
                    {
                        int m = (items[j].max + items[j + 1].min) / 2;
                        int w = items[j + 1].val;
                        if (abs(v - m) < abs(w - m))
                        {
                            return j + 2;
                        }
                    }
                }
            }
            j++;
        }
        return 0;
    }
    
    public int improveGaps(int v)
    {
        int k = 0;
        //System.out.printf("improveGaps(%d)\n", v);
        //print(v);
        
        k = findStraight(v); if (k > 0) return k;
        k = pullDown(v); if (k > 0) return k;
        k = pushUp(v); if (k > 0) return k;
        k = adjustGap(v); if (k > 0) return k;
        
        return 0;
    }
    
    public void print(int v)
    {
        System.out.println("Check: " + v);
        for (int i = 0; i < 10; i++)
        {
            System.out.printf("%2d) %s\n", i + 1, items[i]);
        }
        System.out.println();
    }
    
    public static int abs(int m)
    {
        if (m < 0) m = -m;
        return m;
    }

    class Item
    {
        public int min;
        public int max;
        public int val;
        public boolean set;
        
        public Item(int slot, int v)
        {
            min = (slot - 1) * 6 + 1;
            max = (slot - 1) * 6 + 6;
            val = v;
            set = false;
        }
        
        public int gap()
        {
            return max - min + 1;
        }

        public String toString()
        {
            return String.format("[%2d,%2d%c%2d:%2d]", min, max, set ? '*' : '|', gap(), val);
        }
    }
}