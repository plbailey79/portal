public class Date
{
    public static boolean checkMonth(int m)
    { 
		boolean b = false;
		if (m >= 1 && m <= 12) b = true;
		return b;
	}
    
    public static boolean checkDay(int d)
    { 
		boolean b = false;
		if (d >= 1 && d <= 31) b = true;
		return b;
	}
    
    public static boolean checkYear(int y)
    { 
		boolean b = false;
		if ((y >= 0 && y <= 99) || (y >= 1001 && y <= 2999)) b = true;
		return b;
	}
	
	public static int fixYear(int y)
	{
		if (y >= 0 && y <= 32) y += 2000;
		if (y >= 33 && y <= 99) y += 1900;
		return y;
	}
    
    public static String nameMonth(int m)
    { 
		String t = "";
		switch(m)
		{
			case 1: t = "January"; break;
			case 2: t = "February"; break;
			case 3: t = "March"; break;
			case 4: t = "April"; break;
			case 5: t = "May"; break;
			case 6: t = "June"; break;
			case 7: t = "July"; break;
			case 8: t = "August"; break;
			case 9: t = "September"; break;
			case 10: t = "October"; break;
			case 11: t = "November"; break;
			case 12: t = "December"; break;
		}
		return t;
	}
    
    public static String makeMonth(int m)
    { 
		String t = "";
		if (m == 1) t = "January";
		if (m == 2) t = "February";
		if (m == 3) t = "March";
		if (m == 4) t = "April";
		if (m == 5) t = "May";
		if (m == 6) t = "June";
		if (m == 7) t = "July";
		if (m == 8) t = "August";
		if (m == 9) t = "September";
		if (m == 10) t = "October";
		if (m == 11) t = "November";
		if (m == 12) t = "December";
		return t;
	}
    
    public static String makeDay(int d)
    { 
		String s = "" + d;
		if (d >= 11 && d <= 13) s += "th";
		else if (d % 10 == 1) s+= "st";
		else if (d % 10 == 2) s+= "nd";
		else if (d % 10 == 3) s+= "rd";
		else s+= "th";
		return s;
	}
    
    public static String makeYear(int y)
    { 	
		if (y >= 0 && y <= 32) y += 2000;
		if (y >= 33 && y <= 99) y += 1900;
		return "" + y;
	}
	
	public static boolean isLeapYear(int y)
	{
		return (y % 4 == 0 && (y % 100 > 0 || y % 400 == 0));
	}
    
    public static int monthLength(int m, int y)
    { 
		int a = 0;
		if (m == 1) a = 31;
		if (m == 2) a = 28;
		if (m == 3) a = 31;
		if (m == 4) a = 30;
		if (m == 5) a = 31;
		if (m == 6) a = 30;
		if (m == 7) a = 31;
		if (m == 8) a = 31;
		if (m == 9) a = 30;
		if (m == 10) a = 31;
		if (m == 11) a = 30;
		if (m == 12) a = 31;
		if (m == 2 && isLeapYear(y)) a = 29;
		return a;
	}
	
	public static int internalDate(int m, int d, int y)
	{
		int jdn = Julian.julianDate(y, m, d);
		int jdu = Julian.julianDate(1970, 1, 1);
		return jdn - jdu;
	}
	
	public static String externalDate(int n)
	{
		int jdu = Julian.julianDate(1970, 1, 1);
		int jdn = n + jdu;
		return Julian.gregorianDate(jdn);
	}
	
	public static int currentDate()
	{
		long unixTime = System.currentTimeMillis();
		int jdn = (int)((unixTime / 1000L) / 86400L) - 1;
		return jdn;
	}
	
	public static int getDOW(int n)
	{ 
		return ((n + 4) % 7 + 7) % 7; // 01/01/1970 was Thursday
	}
	
	public static String nameDOW(int w)
	{
		String s = "";
		switch (w)
		{
			case 0: s = "Sunday"; break;
			case 1: s = "Monday"; break;
			case 2: s = "Tuesday"; break;
			case 3: s = "Wednesday"; break;
			case 4: s = "Thursday"; break;
			case 5: s = "Friday"; break;
			case 6: s = "Saturday"; break;
		}
		return s;
	}
}
