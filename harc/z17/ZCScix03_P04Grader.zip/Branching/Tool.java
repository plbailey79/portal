import java.util.Scanner;

public class Tool
{
    private static Scanner scanner = new Scanner(System.in);

    public static String prompt(String p)
    {
        String r = "";
        System.out.print(p);
        return scanner.nextLine();
    }

    public static String piece(String s, String p, int n)
    {
        String r = "";
        String[] t = s.split(p);
        if (t.length >= n) r = t[n-1];
        return r;
    }

    public static int toInt(String s)
    {
        int r = 0;
        try
        {
            r = Integer.parseInt(s);
        }
        catch (Exception ex)
        { }
        return r;
    }
    
    public static int mod(int a, int n)
    {
        return (a % n + n) % n;
    }
    public static int julianDay(int year, int month, int day)
    {
        int a = (14 - month) / 12;
        int y = year + 4800 - a;
        int m = month + 12 * a - 3;
        int jdn = day + ((153 * m + 2)/5) + 365 * y + (y / 4) - (y / 100) + (y / 400) - 32045;
        return jdn;
    }
	
	public static int julianDate(int year, int month, int day)
	{
		return julianDay(year, month, day);
	}
    
	// Converts julian date J into Gregorian (modern American)
    public static String gregorianDate(int J)
    {
        int y = 4716;
        int j = 1401;
        int m = 2;
        int n = 12;
        int r = 4;
        int p = 1461;
        int v = 3;
        int u = 5;
        int s = 153;
        int w = 2;
        int B = 274277;
        int C = -38;
        
        int f = J + j + (((4 * J + B) / 146097) * 3) / 4 + C;
        int e = r * f + v;
        int g = (e % p) / r;
        int h = u * g + w;
        int D = (h % s) / u + 1;
        int M = (h / s + m) % n + 1;
        int Y = (e / p) - y + (n + m - M) / n;
        return String.format("%02d/%02d/%04d", M, D, Y);
    }
    
    public static int currentJulianDate()
    {
        long unixTime = System.currentTimeMillis();
        int jdn = (int)((unixTime / 1000L) / 86400L) + julianDay(1970, 1, 1);
        return jdn;
    }
}
