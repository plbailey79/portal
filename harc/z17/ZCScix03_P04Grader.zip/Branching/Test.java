public class Test
{
	private static int score = 0;
	private static int total = 0;
	private static String input = "";
	
    public static void main(String[] args)
    {
		test("13/33/9999");
		test("12/25/1600");
		test("07/04/1976");
		test("09/16/2017");
		test("01/01/2029");
		
		int grade = (int)((double)(score * 100)/total);
		System.out.printf("\nScore: %d/%d  Grade: %d", score, total, grade);
	}
	
	public static void test(String s)
	{
		input = s;
		
        int km = Tool.toInt(Tool.piece(input, "/", 1));
        int kd = Tool.toInt(Tool.piece(input, "/", 2));
        int ky = Tool.toInt(Tool.piece(input, "/", 3));  

		update(Date.checkMonth(km), Good.checkMonth(km), "checkMonth");
		update(Date.checkDay(kd), Good.checkDay(kd), "checkDay");
		update(Date.checkYear(ky), Good.checkYear(ky), "checkYear");
		
		if (!Good.checkMonth(km) || !Good.checkDay(kd) || !Good.checkYear(ky)) return;
        
		String nm = Date.nameMonth(km);
        String sm = Date.makeMonth(km);
        String sd = Date.makeDay(kd);
        String sy = Date.makeYear(ky);
		
		int di = Date.internalDate(km, kd, ky);
		String de = Date.externalDate(di);
		int dw = Date.getDOW(di);
		
		boolean dl = Date.isLeapYear(ky);
		int dm = Date.monthLength(km, ky);
		String dn = Date.nameDOW(dw);
        
        System.out.println("The " + sd + " day of " + sm + " in the year " + sy + " is " + Date.nameDOW(dw) + ".");
		System.out.println("The internal day of the week is " + dw + ".");
		System.out.println("The internal date is " + di + ".");
		System.out.println("The external date is " + de + ".");
		System.out.println("This " + (Date.isLeapYear(ky) ? "is" : "is not") + " a leap year.");
		System.out.println("This month has " + Date.monthLength(km, ky) + " days.");
		
		update(nm, Good.nameMonth(km), "nameMonth");
		update(sm, Good.makeMonth(km), "makeMonth");
		update(sd, Good.makeDay(kd), "makeDay");
		update(sy, Good.makeYear(ky), "makeYear");
		
		update(di, Good.internalDate(km, kd, ky), "internalDate");
		update(de, Good.externalDate(di), "externalDate");
		update(dw, Good.getDOW(di), "getDOW");
		
		update(dl, Good.isLeapYear(ky), "isLeapYear");
		update(dm, Good.monthLength(km,ky), "monthLength");
		update(dn, Good.nameDOW(dw), "nameDOW");
    }
	
	public static void update(boolean s, boolean g, String desc)
	{
		update(s == g, s+"", g+"", desc);
	}
	
	public static void update(int s, int g, String desc)
	{
		update(s == g, s+"", g+"", desc);
	}
	
	public static void update(String s, String g, String desc)
	{
		update(s.equals(g), s, g, desc);
	}
	
	public static void update(boolean ok, String stud, String good, String desc)
	{
		total++;
		if (ok) score++;
		System.out.printf("%10s  %12s  %12s  %12s  %5s  %d/%d\n", 
			input, desc, stud, good, ok + "", score, total);
	}
}