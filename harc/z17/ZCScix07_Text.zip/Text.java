package edit;

import java.io.File;
import java.io.PrintWriter;
import java.nio.file.Files;
import java.nio.file.Paths;
import javax.swing.JFileChooser;

public class Text
{
    public static String loadFileName()
    {
        String startDirectory = "C:/";
        String s = "";
        JFileChooser fileChooser = new JFileChooser(startDirectory);
        if (fileChooser.showOpenDialog(null) == JFileChooser.APPROVE_OPTION)
        {
            s = fileChooser.getSelectedFile().getAbsolutePath();
        }
        return s;
    }
    
    public static String saveFileName()
    {
        String startDirectory = "C:/";
        String s = "";
        JFileChooser fileChooser = new JFileChooser(startDirectory);
        if (fileChooser.showSaveDialog(null) == JFileChooser.APPROVE_OPTION)
        {
            s = fileChooser.getSelectedFile().getAbsolutePath();
        }
        return s;
    }
    
    public static String loadText(String fileName)
    {
        String content = null;
        try
        {
            content = new String(Files.readAllBytes(Paths.get(fileName)));
        }
        catch (Exception ex)
        {}
        return content;
    }

    public static boolean saveText(String fileName, String content)
    {
        boolean success = false;
        try
        {
            PrintWriter out = new PrintWriter(fileName);
            out.print(content);
            out.close();
            success = true;
        }
        catch (Exception ex)
        {}
        return success;
    }
}
