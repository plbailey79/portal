package H0513;

import java.util.ArrayList;

public class Stats
{
    private ArrayList<ScoreInfo> scoreList;
    
    public Stats()
    {
        scoreList = new ArrayList<ScoreInfo>();
    }
    
    public boolean record(int score)
    {
        int k = 0;
        while (k < scoreList.size())
        {
            ScoreInfo si = scoreList.get(k);
            if (si.getScore() > score) break;
            if (si.getScore() == score)
            {
                si.increment();
                return false;
            }
            k++;
        }
        ScoreInfo sn = new ScoreInfo(score);
        sn.increment();
        scoreList.add(k, sn);
        return true;
    }
    
    public void recordScores(int[] stuScores)
    {
        for (int score : stuScores)
        {
            record(score);
        }
    }
    
    // public double getSeniorPercent(int score)
        // My original response to this was wrong.
        //
        // We need to modify the ScoreInfo class to indicate 
        // whether a student is a senior. 
        // We add a numberOfSeniors instance variable to the ScoreInfo class.  
        // We add an isSenior flag to the constructor, for
        // the first student, and use it to adjust nuumberOfSeniors.
        // We add an isSenior flag as a parameter to the increment method,
        // and use it to adjust the numberOfSeniors.
        // We add a getter method to ScoreInfo for numberOfSeniors.
            
    public static void main(String args[])
    {
        int[] scores = 
            { 90, 90, 80, 80, 80, 85, 82, 87, 99, 72, 33, 62, 88, 
              86, 80, 90, 92, 88, 66, 83, 72, 93, 85, 17, 99, 98 };
        Stats stats = new Stats();
        stats.recordScores(scores);
        
        for (ScoreInfo si : stats.scoreList)
        {
            System.out.printf("score: %d  freq: %d\n", si.getScore(), si.getFrequency());
        }
    }
}
