package gomoku.animals;

import gomoku.Board;
import gomoku.Player;
import gomoku.Position;
import java.util.Random;
import java.util.List;

public class PlayerArtichoke implements Player
{
    private int rng = 0;
    private int min = 4;
    private int cut = 2;
    
    public PlayerArtichoke()
    { }
    
    public PlayerArtichoke(int rng, int min, int cut)
    {
        this.rng = rng;
        this.min = min;
        this.cut = cut;
    }
    
    public Position move(Board board)
    {
        List<Position> positions = board.getEmptyPositions();
        int k = 0;
        while (positions.size() > cut && k < positions.size())
        {
            Position position = positions.get(k);
            int row = position.getRow();
            int col = position.getCol();
            int wid = (int)(Math.random() * rng) + min;
            int size = board.size();
            
            if (row < wid || row + wid > size || col < wid || col + wid > size)
            {
                positions.remove(k);
            }
            else
            {
                k++;
            }
        }
        return board.getRandomPosition(positions);
    }
}
