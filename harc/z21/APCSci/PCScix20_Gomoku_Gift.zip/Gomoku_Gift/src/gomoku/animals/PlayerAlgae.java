package gomoku.animals;

import gomoku.Board;
import gomoku.Player;
import gomoku.Position;

public class PlayerAlgae implements Player
{
    public Position move(Board board)
    {
        return board.getRandomPosition();
    }
}
