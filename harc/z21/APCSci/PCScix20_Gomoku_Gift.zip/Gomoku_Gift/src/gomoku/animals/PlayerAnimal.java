package gomoku.animals;

import gomoku.Board;
import gomoku.Player;
import gomoku.Position;
import java.util.ArrayList;
import java.util.List;

public abstract class PlayerAnimal implements Player
{
    public abstract Position move(Board board);
    
    protected Position linearPosition(Board board, int p, int k)
    {
        return board.getRandomPosition(getLinearPositions(board, p, k));
    }
    
    protected Position centralPosition(Board board)
    {
        return board.getRandomPosition(getCentralPositions(board));
    }
    
    protected Position centralPosition(Board board, int qty)
    {
        return board.getRandomPosition(getCentralPositions(board, qty));
    }
                        
    protected Position randomPosition(Board board)
    {
        return board.getRandomPosition(getCentralPositions(board, 24));
    }
    
    public List<Position> getLinearPositions(Board board, int p, int k)
    {
        List<Position> positions = new ArrayList<Position>();
        int size = board.size();
        int goal = board.goal();
        int c = board.goal() - k;
        if (c < 2) c = 2;
        if (c > goal) c = goal;
        for (int i = 0; i < size; i++)
        {
            for (int j = 0; j < size; j++)
            {
                if (board.get(i, j) == 0)
                {
                    if (board.countNorth(p, i, j) + board.countSouth(p, i, j) + 1 >= c || 
                        board.countEast (p, i, j) + board.countWest(p, i, j) + 1 >= c || 
                        board.countNorthEast(p, i, j) + board.countSouthWest(p, i, j) + 1 >= c ||
                        board.countSouthEast(p, i, j) + board.countNorthWest(p, i, j) + 1 >= c)
                    {
                        positions.add(new Position(i, j));
                    }
                }
            }
        }
        return positions;
    }
    
    public List<Position> getCentralPositions(Board board, int qty)
    {
        List<Position> positions = new ArrayList<Position>();
        int size = board.size();
        int x = (size - 1) / 2;
        int y = 0;
        
        while (positions.size() < qty)
        {
            y += 1;
            for (int r = x - y; r <= x + y; r++)
            {   
                int c = 0;
                c = x - y; if (board.get(r, c) == 0) positions.add(new Position(r, c));
                c = x + y; if (board.get(r, c) == 0) positions.add(new Position(r, c));
            }
            for (int c = x - y + 1; c <= x + y - 1; c++)
            {   
                int r = 0;
                r = x - y; if (board.get(r, c) == 0) positions.add(new Position(r, c));
                r = x + y; if (board.get(r, c) == 0) positions.add(new Position(r, c));
            }
        }
        return positions;
    }
    
    public List<Position> getCentralPositions(Board board)
    {
        List<Position> positions = new ArrayList<Position>();
        int size = board.size();
        for (int wid = size / 2 + 1; wid >= 0; wid--)
        {
            positions = getEmptyPositions(board, wid);
            if (positions.size() > 0) break;
        }
        return positions;
    }

    public List<Position> getEmptyPositions(Board board, int wid)
    {
        List<Position> positions = new ArrayList<Position>();
        int size = board.size();
        
        for (int r = wid; r < size - wid; r++)
        {
            for (int c = wid; c < size - wid; c++)
            {
                if (board.get(r, c) == 0) 
                {
                    positions.add(new Position(r, c));
                }
            }
        }
        return positions;
    }
}
