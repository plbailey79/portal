package gomoku;

import static gomoku.State.BLACK;
import static gomoku.State.WHITE;
import java.util.List;
import java.util.ArrayList;

public class Board
{
    private int size = 0;   // Square grid size X size
    private int goal = 0;   // How many in a row?
    private int actor;      // Current player
    private int[][] grid;
    
    public Board(int size, int targ, int actor)
    {
        this.size = size;
        this.goal = targ;
        this.actor = actor;
        this.grid = new int[size][size];
    }
    
    public Board(Board that)
    {
        this.size = that.size;
        this.goal = that.goal;
        this.actor = that.actor;
        this.grid = new int[size][size];
        for (int row = 0; row < size; row++)
        {
            for (int col = 0; col < size; col++)
            {
                this.grid[row][col] = that.grid[row][col];
            }
        }        
    }
    
    public boolean valid(int row, int col)
    {
        return row >= 0 && row < size && col >= 0 && col < size;
    }
    
    public int get(int row, int col)
    {
        int who = 0;
        if (valid(row, col))
        {
            who = grid[row][col];
        }
        return who;
    }
    
    public boolean set(int row, int col)
    {
        boolean success = false;
        if (valid(row, col) && grid[row][col] == 0)
        {
            grid[row][col] = actor;
            actor = other();
            success = true;
        }
        return success;
    }
    
    public int size()
    {
        return size;
    }
    
    public int goal()
    {
        return goal;
    }
    
    public int actor()
    {
        return actor;
    }
    
    public int other()
    {
        return (other(actor));
    }
    
    public int other(int player)
    {
        return player % 2 + 1;
    }
    
    public List<Position> getEmptyPositions()
    {
        List<Position> positions = new ArrayList<Position>();
        
        for (int r = 0; r < size; r++)
        {
            for (int c = 0; c < size; c++)
            {
                if (grid[r][c] == 0) 
                {
                    positions.add(new Position(r, c));
                }
            }
        }
        return positions;
    }
    
    public Position getRandomPosition(List<Position> positions)
    {
        Position position = null;
        if (positions.size() > 0)
        {
            position = positions.get((int)(Math.random() * positions.size()));
        }
        return position;
    }
    
    public Position getRandomPosition()
    {
        return getRandomPosition(getEmptyPositions());
    }
    
    public int countNorth(int p, int r, int c)
    {
        int k = 0;
        r -= 1;
        while (k < goal && get(r - k, c) == p) ++k;
        return k;
    }
    
    public int countSouth(int p, int r, int c)
    {
        int k = 0;
        r += 1;
        while (k < goal && get(r + k, c) == p) ++k;
        return k;
    }
    
    public int countEast(int p, int r, int c)
    {
        int k = 0;
        c += 1;
        while (k < goal && get(r, c + k) == p) ++k;
        return k;
    }
    
    public int countWest(int p, int r, int c)
    {
        int k = 0;
        c -= 1;
        while (k < goal && get(r, c - k) == p) ++k;
        return k;
    }
    
    public int countNorthEast(int p, int r, int c)
    {
        int k = 0;
        r -= 1;
        c += 1;
        while (k < goal && get(r - k, c + k) == p) ++k;
        return k;
    }
    
    public int countNorthWest(int p, int r, int c)
    {
        int k = 0;
        r -= 1;
        c -= 1;
        while (k < goal && get(r - k, c - k) == p) ++k;
        return k;
    }
    
    public int countSouthEast(int p, int r, int c)
    {
        int k = 0;
        r += 1;
        c += 1;
        while (k < goal && get(r + k, c + k) == p) ++k;
        return k;
    }
    
    public int countSouthWest(int p, int r, int c)
    {
        int k = 0;
        r += 1;
        c -= 1;
        while (k < goal && get(r + k, c - k) == p) ++k;
        return k;
    }
    
    public String toString()
    {
        String s = "";
        for (int r = 0; r < size; r++)
        {
            for (int c = 0; c < size; c++)
            {
                char h = '.';
                if (get(r, c) == 1) h = '*';
                if (get(r, c) == 2) h = 'o';
                s += h;
            }
            s += '\n';
        }
        return s;
    }
}
