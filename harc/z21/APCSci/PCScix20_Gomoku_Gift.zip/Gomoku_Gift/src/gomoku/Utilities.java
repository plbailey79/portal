package gomoku;

import java.awt.Dimension;
import java.awt.Toolkit;
import java.io.PrintWriter;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

public class Utilities
{
    public static boolean delay(int milliseconds)
    {
        boolean success = true;
        try
        {
            Thread.sleep(milliseconds);
        } catch (InterruptedException ex)
        {
            Thread.currentThread().interrupt();
            success = false;
        }
        return success;
    }

    public static boolean saveText(String fileName, String content)
    {
        boolean success = false;
        try
        {
            PrintWriter out = new PrintWriter(fileName);
            out.print(content);
            out.close();
            success = true;
        }
        catch (Exception ex)
        {}
        return success;
    }
    
    public static String getPlayerName(Object o)
    {
        String name = getClassName(o);
        if (name.substring(0, 6).equals("Player"))
        {
            name = name.substring(6);
        }
        int k = name.indexOf("Player");
        if (k >= 0)
        {
            name = name.substring(k + 6);
        }
        return name;
    }
    
    public static String getClassName(Object o)
    {
        String name = o.getClass().getName();
        if (name.contains("."))
        {
            name = name.substring(name.indexOf('.') + 1);
        }
        return name;
    }

    public static String showInputDialog(String message, String title)
    {
        return showInputDialog(message, title, JOptionPane.PLAIN_MESSAGE);
    }

    public static String showInputDialog(String message, String title, int messageType)
    {
        String res = JOptionPane.showInputDialog(
                tempFrame(),
                message,
                title,
                messageType);
        return res;
    }
    public static void showMessageDialog(String message)
    {
        JOptionPane.showMessageDialog(
                null, //tempFrame(),
                message,
                "Message",
                JOptionPane.INFORMATION_MESSAGE);
    }

    private static JFrame tempFrame()
    {
        return new javax.swing.JFrame()
        {
            public boolean isShowing()
            {
                return true;
            }

            public java.awt.Rectangle getBounds()
            {
                Dimension dimension = Toolkit.getDefaultToolkit().getScreenSize();
                int x = (int) ((dimension.getWidth()) / 2);
                int y = (int) ((dimension.getHeight()) / 2);
                return new java.awt.Rectangle(x - 20, y + 280, 0, 0);
            }
        };
    }
}
