package gomoku;

import gomoku.animals.*;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.ArrayList;
import java.util.Date;

public class Tournament
{
    private Record[] records;
    private Match[] matches;
    
    private int matchNumber = 0;
    
    public Tournament()
    {
        List<Player> players = getTourney();
        loadTournament(players);
    }
    
    public List<Player> getTourney()
    {
        List<Player> players = new ArrayList<Player>();

        players.add(new PlayerAlgae());
        players.add(new PlayerArtichoke());
        players.add(new PlayerAsparagus());

        return players;
    }
    
    public boolean more()
    {
        return matchNumber < matches.length;
    }
    
    public Match next()
    {
        return matches[matchNumber++];
    }

    public void loadTournament(List<Player> players)
    {
        int c = 0;
        records = new Record[players.size()];
        for (Player player : players)
        {
            records[c++] = new Record(player);
        }
        
        c = 0;
        matches = new Match[records.length * (records.length - 1) / 2];
        for (int i = 0; i < records.length - 1; i++)
        {
            for (int j = i + 1; j < records.length; j++)
            {
                matches[c++] = new Match(i, j);
            }
        }
        Collections.shuffle(Arrays.asList(matches));
    }
    
    public String getTournament()
    {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < matches.length; i++)
        {
            Match match = matches[i];
            sb.append(String.format("Match# %2d  %-10s v.  %-10s\n",
                    i + 1,
                    Utilities.getPlayerName(records[match.recno1].player),
                    Utilities.getPlayerName(records[match.recno2].player)));
        }
        return sb.toString();
    } 
        
    public String getStandings()
    {
        Record[] stand = records.clone();

        Arrays.sort(stand, Collections.reverseOrder());
        
        StringBuilder sb = new StringBuilder();
        sb.append("           Tournament Standings\r\n\r\n");
        sb.append(String.format("%2s   %-20s  %2s  %2s    [%5s]\r\n\r\n",
                "",
                "Player",
                "W",
                "L",
                " PPG"));

        for (int i = 0; i < stand.length; i++)
        {
            Record record = stand[i];

            sb.append(String.format("%2d)  %-20s  %2d  %2d    [%5.2f]\r\n",
                    i + 1,
                    Utilities.getPlayerName(record.player),
                    record.wins,
                    record.losses,
                    record.ppg()));

        }
        sb.append("\r\n");
        return sb.toString();
    }
    
    public void saveStandings()
    {
        String fileName = fileName = "Tourn" + (new SimpleDateFormat("yyyyMMddHHmmss")).format(new Date()) + ".txt";
        String pathName = System.getProperty("user.home") + "/Desktop/" + fileName;
              
        Utilities.saveText(pathName, getStandings());
    }

    public void printTournament()
    {
        System.out.println(getTournament());
    }   

    public void printStandings()
    {
        System.out.println(getStandings());
    }
    
    class Record implements Comparable<Record>
    {
        public Player player;
        public int wins;
        public int losses;
        public int points;

        public Record(Player player)
        {
            this.player = player;
        }

        public int compareTo(Record that)
        {
            int dif1 = this.wins - this.losses;
            int dif2 = that.wins - that.losses;
                        
            if (dif1 < dif2) return -1;
            if (dif2 < dif1) return 1;
            
            float wpc1 = this.wpc();
            float wpc2 = that.wpc();

            if (wpc1 < wpc2) return -1;
            if (wpc2 < wpc1) return 1;

            float ppg1 = this.ppg();
            float ppg2 = that.ppg();
            
            if (ppg1 < ppg2) return -1;
            if (ppg2 < ppg1) return 1;
            
            return that.name().compareTo(this.name());
        }

        public float wpc()
        {
            int matches = wins + losses;
            if (wins + losses < 1)
            {
                return .5f;
            }
            return ((float)wins) / ((float)matches);
        }
        
        public float ppg()
        {
            int games = (wins + losses)*13;
            if (wins + losses < 1) return 0;
            return ((float)points) / ((float)games);
        }
        
        public String name()
        {
            return Utilities.getPlayerName(player);
        }
    }

    class Match
    {
        private int recno1;
        private int recno2;
        private int score1;
        private int score2;
        private int winner;

        public Match(int r1, int r2)
        {
            recno1 = r1;
            recno2 = r2;
            score1 = 0;
            score2 = 0;
            winner = 0;
        }
        
        public Player getPlayer(int i)
        {
            if (i == 1) return records[recno1].player;
            if (i == 2) return records[recno2].player;
            return null;
        }
        
        public void setScores(int s1, int s2)
        {
            int w = 0;
            if (s1 > s2)
            {
                w = 1;
            }
            if (s2 > s1)
            {
                w = 2;
            }
            
            score1 = s1;
            score2 = s2;
            winner = w;
            
            Record record1 = records[recno1];
            Record record2 = records[recno2];
            record1.wins += (w == 1) ? 1 : 0;
            record1.losses += (w == 1) ? 0 : 1;
            record1.points += s1;
            record2.wins += (w == 2) ? 1 : 0;
            record2.losses += (w == 2) ? 0 : 1;
            record2.points += s2;
        }
    }    
}
