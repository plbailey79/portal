package gomoku;

import javax.swing.JFrame;

public abstract class JFrameAbstract extends JFrame
{
    public abstract void finished(State state);
}
