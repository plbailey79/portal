package gomoku;

import java.util.List;
import java.util.ArrayList;
import java.util.Random;

public class State
{
    public static final int NONE = 0;
    public static final int BLACK = 1;
    public static final int WHITE = 2;
    public static final int TIED = 3;
    
    private Player[] programs;
    
    private int points;
    
    private int starter = NONE;
    private int winner = NONE;
    private List<Position> chain;
    
    private Board board;
    
    public State(Player p1, Player p2, int size, int goal)
    {
        init(p1, p2, size, goal, BLACK);
    }
    
    public State(Player p1, Player p2, int size, int goal, int ps)
    {
        init(p1, p2, size, goal, ps);
    }
    
    private void init(Player p1, Player p2, int size, int goal, int ps)
    {
        this.board = new Board(size, goal, ps);
        this.starter = ps;
        this.programs = new Player[2];
        this.programs[0] = p1;
        this.programs[1] = p2;
        this.points = 100;
        this.chain = new ArrayList<Position>();
    }
    
    public Board getBoard()
    {
        return new Board(board);
    }
    
    public Player getProgram()
    {
        return programs[board.actor() - 1];
    }
    
    public int getPiece(int row, int col)
    {
        return board.get(row, col);
    }
    
    public int getPlayer()
    {
        return board.actor();
    }
    
    public int getOpponent()
    {
        return board.other();
    }
    
    public int getSize()
    {
        return board.size();
    } 
    
    public int getStarter()
    {
        return starter;
    }
    
    public int getWinner()
    {
        return winner;
    }
    
    public int getPoints()
    {
        return points;
    }
    
    public int getScore(int p)
    {
       int score = 0;
       if (winner == TIED) score += 1;
       if (winner == p) score += points;
       return score;
    }
    
    public Position getRandomPosition()
    {
        return board.getRandomPosition();
    }
    
    public List<Position> getChain()
    {
        return chain;
    }
    
    public boolean isValid(Position pos)
    {
        if (pos == null) return false;
        int row = pos.getRow();
        int col = pos.getCol();
        return board.valid(row, col);
    }
    
    public boolean isEmpty(Position pos)
    {
        if (pos == null) return false;
        int row = pos.getRow();
        int col = pos.getCol();
        return board.get(row, col) == NONE;
    }
    
    public boolean playPiece(Position pos)
    {
        if (pos == null) return false;
        int row = pos.getRow();
        int col = pos.getCol();
        boolean b = false;
        if (board.valid(row, col))
        {
            int piece = getPiece(row, col);
            if (piece == NONE)
            {
                board.set(row, col);
                points--;
                findWinner();
                b = true;
            }
        }
        return b;
    }    
    
    public int findWinner()
    {
        int size = board.size();
        int goal = board.goal();
        
        if (points < 2)
        {
            winner = TIED;
            chain = board.getEmptyPositions();
            return TIED;
        }
        for (int i = 0; i < size; i++)
        {
            for (int j = 0; j < size; j++)
            {
                int p = getPiece(i, j);
                if (p > NONE)
                {
                    if (board.countEast(p, i, j) + 1 >= goal)
                    {
                        for (int k = 0; k < goal; k++)
                        {
                            chain.add(new Position(i, j + k));
                        }
                        winner = p;
                        return p;
                    }
                    if (board.countSouth (p, i, j) + 1 >= goal)
                    {
                        for (int k = 0; k < goal; k++)
                        {
                            chain.add(new Position(i + k, j));
                        }
                        winner = p;
                        return p;
                    }
                    if (board.countSouthEast (p, i, j) + 1 >= goal)
                    {
                        for (int k = 0; k < goal; k++)
                        {
                            chain.add(new Position(i + k, j + k));
                        }
                        winner = p;
                        return p;
                    }
                    if (board.countSouthWest (p, i, j) + 1 >= goal)
                    {
                        for (int k = 0; k < goal; k++)
                        {
                            chain.add(new Position(i + k, j - k));
                        }
                        winner = p;
                        return p;
                    }
                }
            }
        }
        return NONE;
    }  
    
    public int isaWinner()
    {
        int size = board.size();
        int goal = board.goal();
        
        for (int i = 0; i < size; i++)
        {
            for (int j = 0; j < size; j++)
            {
                int p = getPiece(i, j);
                if (p > NONE)
                {
                    if (board.countEast(p, i, j) + 1 >= goal ||
                        board.countSouth (p, i, j) + 1 >= goal || 
                        board.countSouthEast (p, i, j) + 1 >= goal || 
                        board.countSouthWest (p, i, j) + 1 >= goal)
                    {
                        return p;
                    }
                }
            }
        }
        return NONE;
    }
    
    public String toString()
    {
        return board.toString();
    }
}
