package gomoku.players;

import gomoku.Board;
import gomoku.Player;
import gomoku.Position;

public class PlayerRandom implements Player
{
    public Position move(Board board)
    {
        return board.getRandomPosition();
    }
}
