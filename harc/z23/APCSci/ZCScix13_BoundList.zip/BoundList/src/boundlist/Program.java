package boundlist;

public class Program
{
    public static void main(String[] argds)
    {
        test6();
    }
    
    public static void test6()
    {
        BoundList bl = BoundList.generate(20, 10, 100);
        bl.insert(5, 201);
        bl.insert(15, 202);
        bl.insert(0, 203);
        bl.insert(12, 204);
        System.out.println(bl);
        
        bl.delete(2);
        bl.delete(0);
        bl.delete(10);
        System.out.println(bl);
    }
    
    public static void test4()
    {
        BoundList bl = BoundList.generate(20, 10, 100);
        System.out.println(bl);
        System.out.printf("min index: %d  min value: %d\n", bl.minimum(), bl.get(bl.minimum()));
        System.out.printf("max index: %d  max value: %d\n", bl.maximum(), bl.get(bl.maximum()));
        
        for (int v = 200; v < 220; v++) bl.add(v);
        System.out.println(bl);
    }
    
    public static void test1()
    {
        int[] x = { 1, 2, 3, 4, 5, 6, 7, 8 };
        BoundList bl = new BoundList(x);
        bl.print();
    }
    
    public static void test0()
    {
        BoundList bl = BoundList.generate(1000, 10, 100);
        System.out.println(bl);
    }
}
