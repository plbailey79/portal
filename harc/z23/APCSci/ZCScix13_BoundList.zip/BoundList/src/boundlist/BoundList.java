package boundlist;

import java.util.Random;

public class BoundList
{
    private int[] a;
    private int n;
    
    public BoundList()
    {
        a = new int[1000];
        n = 0;
    }
    
    public BoundList(int length)
    {
        a = new int[length];
        n = 0;
    }
    
    public BoundList(int[] x)
    {
        copy(x, x.length, x.length);
    }
    
    public BoundList(BoundList bl)
    {
        copy(bl.a, bl.a.length, bl.a.length);
    }
    
    public BoundList(BoundList bl, int length)
    {
        copy(bl.a, bl.a.length, bl.n);
    }
    
    public void copy(int[] x, int length, int size)
    {
        if (length < 1)
        {
            a = new int[0];
            n = 0;
            return;
        }
        a = new int[length];
        if (size > length) size = length;
        for (int i = 0; i < size; i++)
        {
            if (x[i] > 0) a[n++] = x[i];
        }
    }
    
    public String toString()
    {
        StringBuilder sb = new StringBuilder();
        sb.append('[');
        for (int i = 0; i < n; i++)
        {
            if (i > 0) sb.append(", ");
            sb.append(a[i]);
        }
        sb.append(']');
        return sb.toString();
    }
    
    public int length()
    {
        return a.length;
    }
    
    public int size()
    {
        return n;
    }
    
    public int get(int i)
    {
        int v = 0;
        if (i >= 0 && i < n) v = a[i];
        return v;
    }
    
    public boolean set(int i, int v)
    {
        boolean f = false;
        if (i >= 0 && i < n && v > 0)
        {
            a[i] = v;
            f = true;
        }
        return f;
    }
    
    public boolean add(int v)
    {
        boolean f = false;
        if (n < a.length && v > 0)
        {
            a[n++] = v;
            f = true;
        }
        return f;
    }
    
    public boolean insert(int i, int v)
    {
        boolean f = false;
        if (i >= 0 && i <= n && n < a.length && v > 0)
        {
            for (int j = n; j > i; j--)
            {
                a[j] = a[j-1];
            }
            a[i] = v;
            n++;
        }
        return f;
    }
    
    public boolean delete(int i)
    {
        boolean f = false;
        if (i >= 0 && i < n)
        {
            for (int j = i; j < n; j++)
            {
                a[j] = a[j+1];
            }
            a[n-1] = 0;
            n--;
        }
        return f;
        
    }
    
    public void clear()
    {
        a = new int[a.length];
        n = 0;
    }
    
    public int minimum()
    {
        int k = 0;
        for (int i = 1; i < n; i++)
        {
            if (a[i] < a[k]) k = i;
        }
        return k;
    }
    
    public int maximum()
    {
        int k = 0;
        for (int i = 1; i < n; i++)
        {
            if (a[i] > a[k]) k = i;
        }
        return k;
    }
    
    public void print()
    {
        for (int i = 0; i < n; i++)
        {
            System.out.printf("%2d] %d\n", i, a[i]);
        }
        System.out.printf("Size: %d  Length: %d\n", n, a.length);
    }
    
    public static BoundList generate(int length, int size, int max)
    {
        BoundList bl = new BoundList(length);
        bl.n = size;
        Random random = new Random();
        for (int i = 0; i < size; i++)
        {
            bl.a[i] = random.nextInt(max) + 1;
        }
        return bl;
    }
}
