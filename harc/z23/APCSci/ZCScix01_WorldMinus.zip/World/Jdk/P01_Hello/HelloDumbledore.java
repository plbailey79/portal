public class HelloDumbledore
{
	public static void main(String[] args)
	{
		String name = "Dumbledore";
		System.out.println("Hello, " + name);
	}
}