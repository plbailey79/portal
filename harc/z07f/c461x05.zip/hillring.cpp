// hillring.cpp : Defines the entry point for the console application.
//

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "c:\crypt\rig\Sirius\Sirius\Matrix.h"

#pragma warning(disable: 4996)  // Disable (nonstandard) "deprecated" warning
#pragma warning(disable: 4267)  // Disable (nonstandard) int len=strlen(str) warning

/* To use Byor, edit top of Matrix.h, use matrix MOR, recompile
   To use Byte, edit top of Matrix.h, use matrix MTE, recompile */

void matvec(Matrix& M,Matrix& v,Matrix& w)
{ w = M * v; }

bool getvec(FILE* ori,Matrix& v)
{ int chr;
  int k=0;
  v.Put(1,1,0);
  v.Put(2,1,0);
  v.Put(3,1,0);
  while (k<3)
  { chr = fgetc(ori);
    if (chr == EOF)
    { return k?true:false; }
    v.Put(++k,1,chr); } 
  return true; }  

void putvec(FILE* trg,Matrix& w)
{ fputc(w.Get(1,1).byt,trg);
  fputc(w.Get(2,1).byt,trg);
  fputc(w.Get(3,1).byt,trg); }

NUM MOR[] =
{   0, 255, 164,
  255,   1,   0,
   71,   0, 255 };

void hillring(FILE *ori,FILE *trg)
{ int ctr=0;
  Matrix M,v,w;
  M.Load(3,3,MOR);
  v.Make(3,1);
  w.Make(3,1);
  // M.Invert(); // Decrypt
  while (getvec(ori,v))
  { matvec(M,v,w);
    putvec(trg,w); } }

void test(void)
{ Matrix A,B;
  A.Load(3,3,MOR);
  A.Print();
  B=A.Inverse();
  B.Print();
  (A*B).Print();
 }

int main(int argc, char* argv[])
{ FILE *ori,*trg;

  if (argc<3)
  { printf("HILLRING <ori file> <targ file>\n");
    return 0; }

  ori = fopen(argv[1],"rb");
  if (!ori)
  { printf("Unable to open ori file %s\n",argv[1]);
    return 1; }

  trg = fopen(argv[2],"wb");
  if (!trg)
  { printf("Unable to open trg file %s\n",argv[2]);
    fclose(ori);
    return 2; }

  hillring(ori,trg);

  fclose(trg);
  fclose(ori);
  return 0; }
