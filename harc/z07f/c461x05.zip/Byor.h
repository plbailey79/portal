#pragma once

#include "Vizard.h"

class Byor
{
public:
  BYT byt;

public:
  Byor(void)      { byt=0; }
  Byor(Byor& B)   { byt=B.byt; }
  Byor(BYT b)     { byt=b; }

  void Negate(void)   { byt = bytneg(byt); }
  void Invert(void)   { byt = bytinv(byt); }

  Byor Negative(void) { return bytneg(byt); }
  Byor Inverse(void)  { return bytinv(byt); }

  bool IsZer(void)    { return byt == bytzer(); }
  bool IsOne(void)    { return byt == bytone(); }
  bool IsTru(void)    { return byt != bytzer(); }

  static Byor Zer(void)      { return bytzer(); }
  static Byor One(void)      { return bytone(); }

  Byor operator-(void) { return bytneg(byt); }
  Byor operator~(void) { return bytinv(byt); }

  Byor operator+(Byor& B) { return bytadd(byt,B.byt); }
  Byor operator-(Byor& B) { return bytsub(byt,B.byt); }
  Byor operator*(Byor& B) { return bytmul(byt,B.byt); }
  Byor operator/(Byor& B) { return bytdiv(byt,B.byt); }

  bool operator==(Byor& B) { return byt == B.byt; }
  bool operator==(BYT b)   { return byt == b; }

// static functions

  static BYT bytadd(BYT a,BYT b);
  static BYT bytsub(BYT a,BYT b);
  static BYT bytmul(BYT a,BYT b);
  static BYT bytdiv(BYT a,BYT b);
  static BYT bytneg(BYT a);
  static BYT bytinv(BYT a);
  static BYT bytzer(void);
  static BYT bytone(void);
};
