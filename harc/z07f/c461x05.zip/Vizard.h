///////////////////////////////////////////////////////////////////////
// Vizard.h - Universal Type Mask

#pragma once

typedef unsigned  __int8  UN3;
typedef unsigned  __int16 UN4;
typedef unsigned  __int32 UN5;
typedef unsigned  __int64 UN6;

typedef signed    __int8  IN3;
typedef signed    __int16 IN4;
typedef signed    __int32 IN5;
typedef signed    __int64 IN6;

typedef UN4 UNG;
typedef UN5 UNT;    // typical 32-bit unsigned integer
typedef UN6 UNX;    // extra long overflow handler
typedef IN4 ING;
typedef IN5 INT;
typedef IN6 INX;

// Functionality specified integer types

typedef UN3 BIT;    // Bit:       0 or 1
typedef UN3 BYT;    // Byte
typedef UN4 SYL;    // Syllable
typedef UN4 LEN;    // Length
typedef UN5 WRD;    // Word
typedef UN6 BIG;    // Big Integer

typedef char  CHR;
typedef char* STR;
typedef void* PTR;
