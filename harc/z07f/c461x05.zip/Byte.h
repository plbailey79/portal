///////////////////////////////////////////////////////////////////////
// Byte.h of Byte Class - the zero monoid on { 0, 1, ..., 255 }

#pragma once

#include "Vizard.h"

class Byte
{
public:
  BYT byt;

public:
  Byte(void)    { byt = 0; }
  Byte(Byte& B) { byt = B.byt; }
  Byte(BYT b)   { byt = b; }

  void Negate(void)   { byt = bytneg(byt); }
  void Invert(void)   { byt = bytinv(byt); }

  Byte Negative(void) { return bytneg(byt); }
  Byte Inverse(void)  { return bytinv(byt); }

  bool IsZer(void)    { return byt == bytzer(); }
  bool IsOne(void)    { return byt == bytone(); }
  bool IsTru(void)    { return byt != bytzer(); }

  static Byte Zer(void)      { return bytzer(); }
  static Byte One(void)      { return bytone(); }

  Byte operator-(void) { return bytneg(byt); }
  Byte operator~(void) { return bytinv(byt); }

  Byte operator+(Byte& B) { return bytadd(byt,B.byt); }
  Byte operator-(Byte& B) { return bytsub(byt,B.byt); }
  Byte operator*(Byte& B) { return bytmul(byt,B.byt); }
  Byte operator/(Byte& B) { return bytdiv(byt,B.byt); }

  bool operator==(Byte& B) { return byt == B.byt; }
  bool operator==(BYT b)   { return byt == b; }

// static arithmetic functions

  static SYL syleuc(SYL a,SYL b,SYL& x,SYL& y);
  static BYT sylbyt(SYL a);

  static BYT bytadd(BYT a,BYT b);
  static BYT bytsub(BYT a,BYT b);
  static BYT bytmul(BYT a,BYT b);
  static BYT bytdiv(BYT a,BYT b);
  static BYT bytneg(BYT a);
  static BYT bytinv(BYT a);
  static BYT bytzer(void);
  static BYT bytone(void);

// static nonarithmetic functions

  static void bytshw(BYT a);
  static BYT  bytrev(BYT a);
  static BIT  bytpar(BYT a);
  static BYT  bytrot(BYT a,int k);

  static BYT  hexbyt(STR str);
  static BYT  hexdig(CHR chr);
};
