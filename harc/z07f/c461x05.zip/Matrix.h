#pragma once

#include "Byte.h"
#include "Byor.h"

#define NUM Byor

class Matrix
{ 
private:
  int row;
  int col;
  NUM *arr;

public:
  Matrix(void);
  Matrix(Matrix &A);
  ~Matrix(void);

  void Clear(void);
  void Copy(Matrix& M);
  void Make(int m,int n);
  void Load(int m,int n,NUM* a);
  void Print(void);

  NUM  Get(int i,int j);
  void Put(int i,int j,NUM c);

  bool Check(int i,int j);
  int  Index(int i,int j);

  void Zero(int m,int n);
  void Iden(int n);

  NUM OprE(int i,int k,NUM c);
  NUM OprP(int i,int k);
  NUM OprD(int i,NUM c);

  NUM GelFrw(Matrix& A);
  NUM GelBkw(Matrix& A);

  NUM Determinant(void);

  void Negate(void);
  void Invert(void);

  Matrix Negative(void);
  Matrix Inverse(void);

  Matrix operator+(Matrix &A);
  Matrix operator-(Matrix &A);
  Matrix operator*(Matrix &A);

  Matrix operator*(NUM c);

  // static void functions

  static void matadd(Matrix& A,Matrix& B,Matrix& C);
  static void matsub(Matrix& A,Matrix& B,Matrix& C);
  static void matmul(Matrix& A,Matrix& B,Matrix& C);
  static void matmul(Matrix& A,NUM& b,Matrix& C);
  static void matneg(Matrix& A,Matrix& B);
  static NUM  matinv(Matrix& A,Matrix& B);
  static NUM  matdet(Matrix& A);

  static NUM  matopE(Matrix& A,int i,int k,NUM c);
  static NUM  matopP(Matrix& A,int i,int k);
  static NUM  matopD(Matrix& A,int i,NUM c);

  static NUM  matfrw(Matrix& A,Matrix& B);
  static NUM  matbkw(Matrix& A,Matrix& B);

  static void materr(char* str);
};
