///////////////////////////////////////////////////////////////////////
// Byte.cpp of Byte Class - the ring Z_{256}

#include <stdio.h>

#include "Byte.h"

SYL Byte::syleuc(SYL a,SYL b,SYL& x,SYL& y)
{ SYL q,r,t,d;
  x=1; y=0;
  q=b/a;
  r=b%a;
  if (r==0) return a;
  // printf("%d = (%d)(%d) + %d\n",a,b,q,r);
  d=syleuc(r,a,x,y);
  t=x; x=y-(q*x); y=t;
  // printf("%d = (%d)(%d) + (%d)(%d)\n",d,x,a,y,b);
  return d; }

BYT Byte::sylbyt(SYL a)
{ return BYT(a); }

// Arithmetic ring functions


// Nonarithmetic byte functions

void Byte::bytshw(BYT a)
{ int k;
  printf("[%03d %02X ",a,a);
  for (k=0; k<=7; k++)
  { printf("%u",(a&128)>>7);
    a<<=1; } 
  printf("]"); }

BYT Byte::bytrev(BYT a)
{ int k;
  BYT b=0;
  for (k=0; k<=7; k++)
  { b <<= 1;
    b |= BIT(a&BIT(1));
    a >>= 1; }
  return b; }

BIT Byte::bytpar(BYT a)
{ BIT b=0;
  //bytshw(a);
  while (a) 
  { b ^= a&1; a>>=1; }
  //printf("  bytpar: %u\n",b);
  return b; }

BYT Byte::bytrot(BYT a,int k)
{ k%=8;
  if (k<0) k+=8;
  return (a<<k) | (a>>(8-k)); }

BYT Byte::hexbyt(STR str)
{ BYT b=0;
  if (str)
  { if (str[0])
    { b=hexdig(str[0]);
      if (str[1])
      { b<<=4;
        b^=hexdig(str[1]); } } }
  return b; }

BYT Byte::hexdig(CHR chr)
{ if (chr>='0' && chr<='9') return chr-'0';
  if (chr>='A' && chr<='F') return chr-'A'+10;
  if (chr>='a' && chr<='f') return chr-'a'+10;
  return 0; }
