/*===================================================================*\
  Matrix.cpp    Paul L. Bailey    October 15, 2007
\*===================================================================*/

#include <stdio.h>
#include <stdlib.h>
#include <memory.h>

#include "Matrix.h"

Matrix::Matrix(void)
{ row=0;
  col=0;
  arr=NULL; }

Matrix::Matrix(Matrix &M)
{ arr=NULL;
  Copy(M); }

Matrix::~Matrix(void)
{ Clear(); }

void Matrix::Clear(void)
{ row=0;
  col=0;
  arr=NULL; }

void Matrix::Make(int m,int n)
{ Clear();
  row = m;
  col = n;
  arr = new NUM[row*col]; }

void Matrix::Copy(Matrix& M)
{ int i,j;
  Make(M.row,M.col);
  for (i=1; i<=row; i++)
  { for (j=1; j<=col; j++)
    { Put(i,j,M.Get(i,j)); } } }

void Matrix::Load(int m,int n,NUM* a)
{ int i,j,k=0;
  Make(m,n);
  for (i=1; i<=m; i++)
  { for (j=1; j<=n; j++)
    { Put(i,j,a[k++]); } } }

void Matrix::Print(void)
{ int m=row,n=col;
  int i=0,j=0;
  for (i=1; i<=m; i++)
  { for (j=1; j<=n; j++)
    { printf("%u ",Get(i,j).byt); }
    printf("\n"); } 
  printf("----------------------------------\n"); }

NUM Matrix::Get(int i,int j)
{ if (Check(i,j)) return arr[Index(i,j)];
  return NUM::Zer(); }

void Matrix::Put(int i,int j,NUM c)
{ if (Check(i,j)) arr[Index(i,j)] = c; }

bool Matrix::Check(int i,int j)
{ return (1 <= i && 1 <= j && i <= row && j <= col); }

int Matrix::Index(int i,int j)
{ if (Check(i,j))
  { return (i-1)*col+j-1; }
  materr("Index out of range");
  return 0; }

void Matrix::Zero(int m,int n)
{ Make(m,n); }

void Matrix::Iden(int n)
{ int k;
  Make(n,n);
  for (k=1; k<=n; k++)
  { Put(k,k,NUM::One()); } }

Matrix Matrix::operator+(Matrix &B)
{ Matrix C;
  matadd(*this,B,C);
  return C; }

Matrix Matrix::operator-(Matrix &B)
{ Matrix C;
  matsub(*this,B,C);
  return C; }

Matrix Matrix::operator*(Matrix &B)
{ Matrix C;
  matmul(*this,B,C);
  return C; }

Matrix Matrix::operator*(NUM b)
{ Matrix C;
  matmul(*this,b,C);
  return C; }

NUM Matrix::OprE(int i,int k,NUM c)
{ return matopE(*this,i,k,c); }

NUM Matrix::OprP(int i,int k)
{ return matopP(*this,i,k); }

NUM Matrix::OprD(int i,NUM c)
{ return matopD(*this,i,c); }

NUM Matrix::GelFrw(Matrix& B)
{ return matfrw(*this,B); }

NUM Matrix::GelBkw(Matrix& B)
{ return matbkw(*this,B); }

NUM Matrix::Determinant(void)
{ NUM d=NUM::Zer();
  if (row==col)
  { Matrix B,E;
    int k=0;
    B.Copy(*this);
    E.Iden(row);
    d=B.GelFrw(E);
    for (k=1; k<=row; k++)
    { d = d * B.Get(k,k); } }
  return d; }

Matrix Matrix::Inverse(void)
{ Matrix E;
  matinv(*this,E);
  return E; }

void Matrix::Invert(void)
{ Matrix B;
  B.Copy(*this);
  matinv(B,*this); }

////////////////////////////////////////////////

void Matrix::matadd(Matrix& A,Matrix& B,Matrix& C)
{ int i,j;
  if (A.row != B.row || A.col != B.col)
  { materr("matadd dim mismatch"); }
  C.Make(A.row,A.col);
  for (i=1; i<=C.row; i++)
  { for (j=1; j<=C.col; j++)
    { C.Put(i,j,A.Get(i,j)+B.Get(i,j)); } } }

void Matrix::matsub(Matrix& A,Matrix& B,Matrix& C)
{ int i,j;
  if (A.row != B.row || A.col != B.col)
  { materr("matadd dim mismatch"); }
  C.Make(A.row,A.col);
  for (i=1; i<=C.row; i++)
  { for (j=1; j<=C.col; j++)
    { C.Put(i,j,A.Get(i,j)-B.Get(i,j)); } } }

void Matrix::matmul(Matrix& A,Matrix& B,Matrix& C)
{ int i,j,k;
  NUM c;
  if (A.col != B.row)
  { materr("matmul dim mismatch"); }
  C.Make(A.row,B.col);
  for (i=1; i<=C.row; i++)
  { for (j=1; j<=C.col; j++)
    { c=0;
      for (k=1; k<=A.col; k++)
      { c = c + A.Get(i,k) * B.Get(k,j); }
      C.Put(i,j,c); } } }

void Matrix::matmul(Matrix& A,NUM& b,Matrix& C)
{ int i,j;
  C.Make(A.row,A.col);
  for (i=1; i<=C.row; i++)
  { for (j=1; j<=C.col; j++)
    { C.Put(i,j,b * A.Get(i,j)); } } }

NUM Matrix::matinv(Matrix& A,Matrix& B)
{ Matrix C;
  NUM d;
  if (A.row != A.col)
  { materr("matinv nonsquare"); }
  C.Copy(A);
  B.Iden(C.row);
  return matbkw(C,B); }

NUM Matrix::matdet(Matrix& A)
{ Matrix B,E;
  NUM d=NUM::Zer();
  int k;
  if (A.row!=A.col)
  { materr("matdet nonsquare"); }
  B.Copy(A);
  d=B.GelFrw(E);
  for (k=1; k<=B.row; k++)
  { d = d * B.Get(k,k); }
  return d; }

NUM Matrix::matopE(Matrix& A,int i,int k,NUM c)
{ int j;
  //printf("OprE(%d,%d,%u)\n",i,k,c.byt);
  if (i<1 || k<1 || i>A.row || k>A.row) return NUM::One();
  if (i==k) return NUM::One();
  for (j=1; j<=A.col; j++)
  { A.Put(i,j,A.Get(i,j) + A.Get(k,j)*c); }
  //A.Print();
  return NUM::One(); }

NUM Matrix::matopP(Matrix& A,int i,int k)
{ int j;
  NUM x;
  //printf("OprP(%d,%d)\n",i,k);
  if (i<1 || k<1 || i>A.row || k>A.row) return NUM::One();
  if (i==k) return NUM::One();
  for (j=1; j<=A.col; j++)
  { x = A.Get(i,j);
    A.Put(i,j,A.Get(k,j));
    A.Put(k,j,x); }
  //A.Print();
  return -NUM::One(); }

NUM Matrix::matopD(Matrix& A,int i,NUM c)
{ int j;
  //printf("OprD(%d,%u)\n",i,c.byt);
  if (i<1 || i>A.row) return NUM::One();
  if (c.IsOne()) return NUM::One();
  for (j=1; j<=A.col; j++)
  { A.Put(i,j,A.Get(i,j)*c); }
  //A.Print();
  return c; }

NUM Matrix::matfrw(Matrix& A,Matrix& B)
{ int i=0,j=0,k=0,l=0;
  NUM d=NUM::One(),a=0,b=0,x=0;
  k = 1;
  for (l=1; l<=A.col; l++)
  { a = A.Get(k,l);
    b = a.Inverse();
    if (b.IsZer())
    { i = k+1;
      while (i<=A.row)
      { a = A.Get(i,l);
        b = a.Inverse();
        if (b.IsTru()) break;
        i++; }
      if (b.IsTru())
      { d = -d;
        A.OprP(i,k);
        B.OprP(i,k); } }
    if (b.IsZer()) continue;
    for (i=k+1; i<=A.row; i++)
    { x = A.Get(i,l);
      if (x.IsTru())
      { x = -(x*b);
        A.OprE(i,k,x);
        B.OprE(i,k,x); } } 
    k++; }
  return d; }

NUM Matrix::matbkw(Matrix &A,Matrix& B)
{ int i=0,j=0,k=0,l=0;
  NUM a=0,b=0,x=0,d;
  d = matfrw(A,B);
  //printf("In matbkw:\n"); A.Print();
  for (k=1; k<=A.row; k++)
  { for (l=k; l<=A.col; l++)
    { a = A.Get(k,l);
      b = a.Inverse();
      if (b.IsTru())
      { x = b;
        d = d * a;
        A.OprD(k,x);
        B.OprD(k,x);
        for (i=k-1; i>=1; i--)
        { a = A.Get(i,l);
          b = a.Negative();
          //printf(" (%d,%d) -%u=%u ",i,l,a.byt,b.byt);
          if (b.IsTru())
          { x = b;
            A.OprE(i,k,x);
            B.OprE(i,k,x); } }
        break; } } }
  return d; }

void Matrix::materr(char* str)
{ fprintf(stderr,"Matrix error: %s\n",str);
  exit(1); }
