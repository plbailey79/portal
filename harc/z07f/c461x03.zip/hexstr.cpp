
BYT hexdig(char chr)
{ if (chr>='0' && chr<='9') return chr-'0';
  if (chr>='A' && chr<='F') return chr-'A'+10;
  if (chr>='a' && chr<='f') return chr-'a'+10;
  return 0; }

WRD hexwrd(char *str)
{ WRD wrd=0;
  BYT byt=0;
  int ctr=0;
  while (*str && ctr<16)
  { byt=hexdig(*str++);
    wrd=(wrd<<4)+byt; }
  return wrd; }