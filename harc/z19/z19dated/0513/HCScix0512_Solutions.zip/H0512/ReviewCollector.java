package H0512;

import java.util.ArrayList;

public class ReviewCollector
{
    private ArrayList<ProductReview> reviewList;
    private ArrayList<String> productList;
    
    public ReviewCollector()
    {
        reviewList = new ArrayList<ProductReview>();
        productList = new ArrayList<String>();
    }
    
    // Part (a)
    public void addReview(ProductReview prodReview)
    {
        boolean add = true;
        for (String s : productList)
        {
            if (s.equals(prodReview.getName()))
            {
                add = false;
                break;
            }
        }
        if (add)
        {
            productList.add(prodReview.getName());
        }
        reviewList.add(prodReview);
    }
    
    // Part (b)
    public int getNumGoodReviews(String prodName)
    {
        int k = 0;
        for (ProductReview pr : reviewList)
        {
            if (pr.getName().equals(prodName))
            {
                if (pr.getReview().contains("best"))
                {
                    k++;
                }
            }
        }
        return k;
    }
    
    // Part (c)
    /* Instructions to create getBestReviewsByProduct
        The method header should be
            public ArrayList<ProductReview> getBestReviewsByProduct(String.prodName)
        Copy the code of getNumGoodReviews, and change it as follows.
        Instead of creating the variable k, create an ArrayList<ProductReview>.
        Then change k++ to adding the review to the list.
        Instead of returning k, return the list.
    */
    
    // Test
    public static void main(String[] args)
    {
        ReviewCollector rc = new ReviewCollector();
        rc.addReview(new ProductReview("Cadillac", "NOT the best car I have seen."));
        rc.addReview(new ProductReview("Cadillac", "Loved it!"));
        rc.addReview(new ProductReview("Ford", "Found on road dead."));
        rc.addReview(new ProductReview("Big Honkin' Redneck Truck", "Fills the air with asbestos."));
        
        System.out.printf("Number of good reviews: %d\n", rc.getNumGoodReviews("Cadillac"));
    }
}
