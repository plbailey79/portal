package H0512;

public class Hailstone
{
    public static int hailstoneLength(int n)
    { 
        int k = 1;
        while (n > 1)
        {
            if (n % 2 == 1)
            {
                n = 3 * n + 1;
            }
            else
            {
                n = n / 2;
            }
            k++;
        }
        return k;
    }
    
    public static boolean isLongSeq(int n)
    {
        return hailstoneLength(n) > n;
    }
    
    public static double propLong(int n)
    {
        // Initialize a variable to count the long sequences
        // Loop through the numbers from 1 to n
        // For each of these numbers, increment the counter if isLongSeq
        // is true;
        // Return the ratio of the counter with n, since n is the number
        // of sequences considered.
        return 0;
    }
    
    public static void main(String[] args)
    {
        System.out.printf("hailstoneLength(%d) = %d\n", 5, hailstoneLength(5));
        System.out.printf("hailstoneLength(%d) = %d\n", 8, hailstoneLength(8));
        System.out.printf("hailstoneLength(%d) = %d\n", 1001, hailstoneLength(1001));
        for (int n = 1; n < 100; n++)
        {
            System.out.printf("hailstoneLength(%d) = %d\n", n, hailstoneLength(n));
        }
    }
}
