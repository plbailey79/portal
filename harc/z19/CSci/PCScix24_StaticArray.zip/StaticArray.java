public class StaticArray
{
	public static int minimum(int[] a)
	{
		int k = -1;
		if (a.length > 0)
		{
			k = 0;
		}
		for (int i = 1; i < a.length; i++)
		{
			if (a[i] < a[k]) k = i;
		}
		return k;
	}
	
	public static int maximum(int[] a)
	{
		int k = -1;
		if (a.length > 0)
		{
			k = 0;
		}
		for (int i = 1; i < a.length; i++)
		{
			if (a[i] > a[k]) k = i;
		}
		return k;
	}
	
	public static boolean insert(int[] a, int i, int v) // Last is Lost
	{
		boolean b = false;
		if (i >= 0 && i < a.length)
		{
			for (int j = a.length - 1; j > i; j--)
			{
				a[j] = a[j - 1];
			}
			a[i] = v;
			b = true;
		}
		return b;
	}
	
	public static boolean delete(int[] a, int i) // Last becomes Zero
	{
		boolean b = false;
		if (i >= 0 && i < a.length)
		{
			for (int j = i; j < a.length - 1; j++)
			{
				a[j] = a[j + 1];
			}
			a[a.length - 1] = 0;
			b = true;
		}
		return b;
	}
	
	public static int sequentialSearch(int[] a, int v)
	{
		int k = -1;
		for (int i = 0; i < a.length; i++)
		{
			if (a[i] == v)
			{
				k = i;
				break;
			}
		}
		return k;
	}
	
	public static int binarySearch(int[] a, int v)
	{
		int lo = 0;
		int hi = a.length - 1;
		if (a[lo] > v) return -1;
		if (a[hi] < v) return -1;
		if (a[lo] == v) return lo;
		if (a[hi] == v) return hi;
		while (lo < hi)
		{
			int av = (lo + hi) / 2;
			if (a[av] == v) return av;
			if (lo == av)
			{
				if (a[hi] == v) return hi;
				break;
			}
			if (a[av] < v)
			{
				lo = av;
			}
			if (a[av] > v)
			{
				hi = av;
			}
		}
		return -1;
	}
	
	public static void selectionSort(int[] a)
	{
		for (int i = 0; i < a.length - 1; i++)
		{
			int k = i;
			for (int j = i + 1; j < a.length; j++)
			{
				if (a[j] < a[k]) k = j;
			}
			if (k > i)
			{
				int t = a[i];
				a[i] = a[k];
				a[k] = t;
			}
		}
	}
	
	public static void insertionSort(int[] a)
	{
		for (int i = 1; i < a.length; i++)
		{
			int t = a[i];
			int j = i - 1;
			while (j >= 0 && a[j] > t)
			{
				a[j + 1] = a[j];
				j--;
			}
			a[j + 1] = t;
		}
	}
	
	public static int[] mergeSort(int[] a)
	{
		return mergeSort(a, 0, a.length);
	}

	private static int[] mergeSort(int[] x, int lo, int hi)
	{
		int[] y = new int[0];
		if (lo + 1 >= hi) 
		{
			y = new int[1];
			y[0] = x[lo];
		}
		else
		{
			int av = (lo + hi) / 2;
			int[] a = mergeSort(x, lo, av);
			int[] b = mergeSort(x, av, hi);
			y = new int[a.length + b.length];

			int i = 0;
			int j = 0;
			int k = 0;
			while (k < y.length)
			{
				if (i < a.length && j < b.length)
				{
					if (a[i] <= b[j])
					{
						y[k++] = a[i++];
					}
					else
					{
						y[k++] = b[j++];
					}
				}
				else if (i < a.length)
				{
					y[k++] = a[i++];
				}
				else
				{
					y[k++] = b[j++];
				}
			}
		}
		return y;
	}
	
	public static String string(int[] a)
	{
		String s = "[";
		for (int i = 0; i < a.length; i++)
		{
			if (i > 0) s += ',';
			s += a[i];
		}
		s += ']';
		return s;
	}
	
	public static void main(String[] args)
	{
		int[] a = { 1, 4, 7, 2, 8, 2, 4, 9, 2 };
		
		System.out.println(string(a));
		
		insert(a, 3, 11);
		insert(a, 21, 12);
		insert(a, 0, 13);
		System.out.println(string(a));
		delete(a, 4);
		delete(a, 0);
		delete(a, -3);
		System.out.println(string(a));
		
		System.out.printf("Find %d: %d\n", 2, sequentialSearch(a, 2));
		System.out.printf("Find %d: %d\n", 5, sequentialSearch(a, 5));
		System.out.printf("Find %d: %d\n", 7, sequentialSearch(a, 7));
		insertionSort(a);
		System.out.println(string(a));
		System.out.printf("Find %d: %d\n", 2, binarySearch(a, 2));
		System.out.printf("Find %d: %d\n", 5, binarySearch(a, 5));
		System.out.printf("Find %d: %d\n", 7, binarySearch(a, 7));
		
	}
	
	
}