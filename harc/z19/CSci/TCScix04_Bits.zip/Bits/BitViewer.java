import java.lang.Float;

public class BitViewer
{
	// Floating Point Conventions
	//		x = Actual floating point number (float or double)
	// 		w = Total number of bits
	// 		1 = Number of sign bits
	// 		q = Number of mantissa bits
	// 		p = Number of exponent bits
	//		b = Bias ( = 2^(o - 1) - 1)
	// We have z = 1 + n + o
	// 		s = Sign = +- 1
	//		e = Exponent
	//		f = Mantissa
	// So x = s * m * 2^e
	//      u = Raw Exponent
	//		v = Raw Mantissa
	// So e = u - b and m = 1 + v/(2^n)
	
	private long value;
	private int length;
	private boolean isint;
	private String inval;
	
	public long getValue() { return value; }
	public int getLength() { return length; }
	public boolean getisint() { return isint; }
	public String getInval() { return inval; }
	
	public BitViewer(byte x)
	{
		value = x;
		length = 8;
		isint = true;
		inval = x + "";
	}
	
	public BitViewer(short x)
	{
		value = x;
		length = 16;
		isint = true;
		inval = x + "";
	}
	
	public BitViewer(int x)
	{
		value = x;
		length = 32;
		isint = true;
		inval = x + "";
	}
	
	public BitViewer(long x)
	{
		value = x;
		length = 32;
		isint = true;
		inval = x + "";
	}
	
	public BitViewer(float x)
	{
		value = Float.floatToRawIntBits(x) & 0xFFFFFFFFL;
		length = 32;
		isint = false;
		inval = x + "";
	}
	
	public BitViewer(double x)
	{
		value = Double.doubleToRawLongBits(x);
		length = 64;
		isint = false;
		inval = x + "";
	}
	
	public String toString()
	{
		return inval;
	}
	
	public String asLong()
	{
		String s = "";
		long x = value;
		for (int i = 0; i < length; i++)
		{
			s = (x & 1L) + s;
			x >>>= 1;
		}
		return s;
	}
	
	public String asFloat()
	{
		int p = 0, q = 0, w = length;
		switch (w)
		{
			case  8 : p = 3; q = 4; break;
			case 16 : p = 5; q = 10; break;
			case 32 : p = 8; q = 23; break;
			case 64 : p = 11; q = 52; break;
		}
		
		String s = "";
		long x = value;
		for (int i = 0; i < w; i++)
		{
			s = (x & 1L) + s;
			x >>>= 1;
			if (i == w - 2) s = " " + s;
			if (i == w - p - 2) s = " " + s;
		}
		return s + "*";
	}
}
