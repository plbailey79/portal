public class Program
{
	public static void printFloat(float x)
	{
		BitViewer s = new BitViewer(x);
		System.out.printf("x: %-20s  %s\n", s.getInval(), s.asFloat());
	}
	
	public static void testFloat()
	{
		float m = 1F / (1 << 30);
		
		printFloat(0f);
		printFloat(1f);
		printFloat(1.125f);
		printFloat(2f);
		printFloat(0.1f);
		printFloat(m);
		printFloat(m * m);
		printFloat(m * m * m * m / 64); // Normal
		printFloat(m * m * m * m / 128); // Subnormal
		printFloat(1f/0f); // + Infinity
		printFloat(0f/0f); // NaN
	}
	
	public static void testByte()
	{
		printByte((byte)100);
		printByte((byte)-57);
	}
	
	public static void printByte(byte x)
	{
		BitViewer s = new BitViewer(x);
		System.out.printf("x: %-20s  %s\n", s.getInval(), s.asLong());
	}	
	
	public static void testShort()
	{
		printShort((short)(513));
		printShort((short)-513);
	}
	
	public static void printShort(short x)
	{
		BitViewer s = new BitViewer(x);
		System.out.printf("x: %-20s  %s\n", s.getInval(), s.asLong());
	}	
	
	public static void main(String[] args)
	{
		testFloat();
	}
}