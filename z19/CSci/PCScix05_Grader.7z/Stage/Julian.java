public class Julian
{
	public static int julianDate(int M, int D, int Y)
	{
		int J = (1461 * (Y + 4800 + (M - 14) / 12)) / 4
			+ (367 * (M - 2 - 12 * ((M - 14) / 12))) / 12
			- (3 * ((Y + 4900 + (M - 14) / 12) / 100)) / 4
			+ D - 32075;
		return J;
	}

	public static String gregorianDate(int J)
	{
		int y = 4716;
		int j = 1401;
		int m = 2;
		int n = 12;
		int r = 4;
		int p = 1461;
		int v = 3;
		int u = 5;
		int s = 153;
		int w = 2;
		int B = 274277;
		int C = -38;
		int f = J + j + (((4 * J + B) / 146097) * 3) / 4 + C;
		int e = r * f + v;
		int g = (e % p) / r;
		int h = u * g + w;
		int D = (h % s) / u + 1;
		int M = ((h / s + m) % n) + 1;
		int Y = (e / p) - y + (n + m - M) / n;
		return formatDate(M, D, Y);
	}
    
	public static int bobianDate(int month, int day, int year)
    {
        int a = (14 - month) / 12;
        int y = year + 4800 - a;
        int m = month + 12 * a - 3;
        int jdn = day + ((153 * m + 2)/5) + 365 * y + (y / 4) - (y / 100) + (y / 400) - 32045;
        return jdn;
    }
	
	public static int currentJulianDate()
	{
		long unixTime = System.currentTimeMillis();
		int jdn = (int)((unixTime / 1000L) / 86400L) + julianDate(1, 1, 1970);
		return jdn;
	}
	
	public static String formatDate(int M, int D, int Y)
	{
		return String.format("%02d/%02d/%04d", M, D, Y);
	}
}
