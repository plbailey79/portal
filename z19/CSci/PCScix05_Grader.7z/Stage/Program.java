public class Program
{
    public static void main(String[] args)
    {
        String input = Tool.prompt("Enter a date in the format MM/DD/YYYY: ");
        int km = Tool.toInt(Tool.piece(input, "/", 1));
        int kd = Tool.toInt(Tool.piece(input, "/", 2));
        int ky = Tool.toInt(Tool.piece(input, "/", 3));
        
        if (!Date.checkMonth(km))
        {
            System.out.println("Invalid month");
            return;
        }
        if (!Date.checkDay(kd))
        {
            System.out.println("Invalid day");
            return;
        }
        if (!Date.checkYear(ky))
        {
            System.out.println("Invalid year");
            return;
        }
		
		ky = Date.fixYear(ky);
        
        String sm = Date.nameMonth(km);
        String sd = Date.makeDay(kd);
        String sy = Date.makeYear(ky);
		
		int jdn = Julian.julianDate(ky, km, kd);
		int jdc = Julian.currentJulianDate();
		int di = Date.internalDate(km, kd, ky);
		int dc = Date.currentDate();
		String de = Date.externalDate(di);
		int dw = Date.getDOW(di);
		
		String tense = " is ";
		if (di > dc) tense = " will be ";
		if (di < dc) tense = " was ";
        
        System.out.println("The " + sd + " day of " + sm + " in the year " + sy + tense + Date.nameDOW(dw) + ".");
		System.out.println("The internal day of the week is " + dw + ".");
		System.out.println("The internal date is " + di + ".");
		System.out.println("The external date is " + de + ".");
		System.out.println("This " + (Date.isLeapYear(ky) ? "is" : "is not") + " a leap year.");
		System.out.println("This month has " + Date.monthLength(km, ky) + " days.");
		System.out.println("The julian date is " + jdn + ".");
		System.out.println("The current julian date is " + jdc + ".");
		System.out.println("The current internal date is " + dc + ".");
    }
}
