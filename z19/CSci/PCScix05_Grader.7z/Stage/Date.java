public class Date
{
	public static boolean checkMonth(int m);
	{ return true; }
	public static boolean checkDay(int d);
	{ return true; }
	public static boolean checkYear(int y);
	{ return true; }
	public static String makeMonth(int m);
	{ return "Mocktober"; }
	public static String makeDay(int d);
	{ return "99th"; }
	public static String makeYear(int y);
	{ return "1492"; }
}
{
   if (y > MAX_VALID_YR ||  
        y < MIN_VALID_YR) 
    return false; 
    if (m < 1 || m > 12) 
    return false; 
    if (d < 1 || d > 31) 
    return false; 
  
    if (m == 2) 
    { 
        if (isLeap(y)) 
        return (d <= 29); 
        else
        return (d <= 28); 
    } 

    if (m == 4 || m == 6 || 
        m == 9 || m == 11) 
        return (d <= 30); 
  
    return true; 
} 

{public static int day(int month, int day, int year) 
	{
        int y = y - (14 - m) / 12;
        int x = y + y/4 - y/100 + y/400;
        int m = m + 12 * ((14 - m) / 12) - 2;
        int d = (d + x + (31*m)/12) % 7;
        return d;
    }

    public static boolean isLeapYear(int year) 
	{
        if  ((year % 4 == 0) && (year % 100 != 0)) return true;
        if  (year % 400 == 0) return true;
        return false;
    }

    public static void main(String[] args) 
	{
        
        String[] months = 
		{
            int january = 1 
			int febuary = 2
			int march = 3 
			int april = 4 
			int may = 5 
			int june = 6 
			int july = 7 
			int august = 8
			int september = 9 
			int october = 10
			int november = 11 
			int december = 12
        }  
        int[] days = 
		{
            0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31
        };
        if (month == 2 && isLeapYear(year)) days[month] = 29;
        int d = day(month, 1, year);
    }
}