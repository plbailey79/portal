
    public static boolean checkMonth(int m)
    { 
		boolean b = false;
		return b;
	}
    
    public static boolean checkDay(int d)
    { 
		boolean b = false;
		return b;
	}
    
    public static boolean checkYear(int y)
    { 
		boolean b = false;
		return b;
	}
    
    public static String nameMonth(int m)
    { 
		String t = "";
		return t;
	}
    
    public static String makeMonth(int m)
    { 
		String t = "";
		return t;
	}
    
    public static String makeDay(int d)
    { 
		String s = "";
		return s;
	}
    
    public static String makeYear(int y)
    { 	
		return "";
	}
	
	public static boolean isLeapYear(int y)
	{
		return false;
	}
    
    public static int monthLength(int m, int y)
    { 
		int a = 0;
		return a;
	}
	
	public static int internalDate(int m, int d, int y)
	{
		return 0;
	}
	
	public static String externalDate(int n)
	{
		return "";
	}
	
	public static int getDOW(int n)
	{ 
		return 0;
	}
	
	public static String nameDOW(int w)
	{
		String s = "";
		return s;
	}

