import java.util.Random;

public class BoundList
{
	private static final int INITIAL = 1000;
	
	private int[] a;	// Array
	private int n;		// Number Occupied
	
	public BoundList()
	{
		a = new int[INITIAL];
		n = 0;
	}
	
	public BoundList(int length)
	{
		a = new int[length];
		n = 0;
	}
	
	public BoundList(int[] x)
	{
		a = new int[x.length + 10];
		n = x.length;
		for (int i = 0; i < n; i++)
		{
			a[i] = x[i];
		}
	}
	
	public BoundList(BoundList bl)
	{
		a = new int[bl.a.length];
		n = bl.n;
		for (int i = 0; i < n; i++)
		{
			a[i] = bl.a[i];
		}
	}
	
	public BoundList(BoundList bl, int length)
	{
		a = new int[length];
		n = bl.n < length ? bl.n : length;
		for (int i = 0; i < n; i++)
		{
			a[i] = bl.a[i];
		}
	}
	
	public BoundList(BoundList bl, int length, int size)
	{
		a = new int[length];
		if (size > length) size = length;
		n = bl.n < size ? bl.n : size;
		for (int i = 0; i < n; i++)
		{
			a[i] = bl.a[i];
		}
	}
	
	public String toString()
	{
		String s = "";
		if (n > 20)
		{
			s = "BoundList[" + n + "]";
		}
		else
		{
			int k = 0;
			s = "[";
			while (k < n)
			{
				if (k > 0) s += ",";
				s += a[k++];
			}
			s += "]";
		}
		return s;
	}
	
	public int length()
	{
		return a.length;
	}
	
	public int size()
	{
		return n;
	}
	
	public void clear()
	{
		n = 0;
	}
	
	public boolean isIndex(int i)
	{
		return (i >= 0 && i < n);
	}
	
	public int get(int i)
	{
		int v = 0;
		if (isIndex(i)) v = a[i];
		return v;
	}

	public boolean set(int i, int v)
	{
		boolean b = false;
		if (isIndex(i)) 
		{
			a[i] = v;
			b = true;
		}
		return b;
	}
	
	public void print()
	{
		for (int i = 0; i < n; i++)
		{
			System.out.printf("[%3d] %3d\n", i, a[i]);
		}
	}
	
	public int minimum()
	{
		if (n < 1) return 0;
		int v = a[0];
		int k = 0;
		for (int i = 1; i < n; i++)
		{
			if (a[i] < v) 
			{
				k = i;
				v = a[k];
			}
		}
		return k;
	}
	
	public int maximum()
	{
		if (n < 1) return 0;
		int v = a[0];
		int k = 0;
		for (int i = 1; i < n; i++)
		{
			if (a[i] > v) 
			{
				k = i;
				v = a[k];
			}
		}
		return k;
	}
	
	public boolean add(int v)
	{
		if (v <= 0 || n + 1 > a.length) return false;
		a[n++] = v;
		return true;
	}
	
	public boolean insert(int i, int v)
	{
		if (v <= 0 || n + 1 > a.length) return false;
		if (i != n && !isIndex(i)) return false;
		for (int j = n; j > i; j--)
		{
			a[j] = a[j-1];
		}
		a[i] = v;
		n++;
		return true;
	}
	
	public boolean delete(int i)
	{
		if (!isIndex(i)) return false;
		for (int j = i; j + 1 < n; j++)
		{
			a[j] = a[j+1];
		}
		n--;
		return true;
	}
	
	public static BoundList generate(int length, int size, int max)
	{
		if (length < 0 || length > 10000) length = INITIAL;
		if (size > length) size = length;
		
		BoundList bl = new BoundList(length);
		
		bl.n = size;
		Random random = new Random();
		for (int i = 0; i < size; i++)
		{
			bl.a[i] = random.nextInt(max) + 1;
		}
		return bl;
	}
}