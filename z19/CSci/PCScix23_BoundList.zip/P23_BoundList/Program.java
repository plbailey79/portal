class Program
{
	public static void main(String[] args)
	{
		test1();
	}
	
	public static void test1()
	{
		int[] a = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };
		BoundList bl = new BoundList(a);
		System.out.println(bl);
		System.out.printf("add(11)       %-5s  %s\n", bl.add(11), bl);
		System.out.printf("insert(3, 13) %-5s  %s\n", bl.insert(3, 13), bl);
		System.out.printf("insert(2, 14) %-5s  %s\n", bl.insert(2, 14), bl);
		System.out.printf("delete(0)     %-5s  %s\n", bl.delete(0), bl);
		System.out.printf("delete last   %-5s  %s\n", bl.delete(bl.size()-1), bl);
		System.out.println(bl);
		
	}
	
	public static void test0()
	{
		BoundList bl1 = BoundList.generate(100, 100, 100);
		bl1.print();
		BoundList bl2 = new BoundList(bl1, 50, 20);
		bl2.print();
	}
}