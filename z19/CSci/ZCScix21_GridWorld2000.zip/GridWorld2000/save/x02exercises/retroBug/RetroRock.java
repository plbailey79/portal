import java.util.List;

import info.gridworld.actor.Actor;
import info.gridworld.actor.Flower;
import info.gridworld.actor.Rock;
import info.gridworld.actor.Bug;
import info.gridworld.grid.Grid;
import info.gridworld.grid.Location;

public class RetroRock extends Rock
{
	private Location oldLocation;
	private int oldDirection;
	private int steps;
	
	public void act()
	{
		steps++;
		if (steps % 5 == 0)
		{
			Grid<Actor> grid = getGrid();
			if (grid != null)
			{
				List<Location> locations = grid.getOccupiedLocations();
				for (Location location : locations)
				{
					Actor actor = grid.get(location);
					if (actor instanceof RetroBug)
					{
						((RetroBug)actor).restore();
						System.out.println("Restored: " + steps);
					}
				}
			}
		}
		super.act();
	}
}