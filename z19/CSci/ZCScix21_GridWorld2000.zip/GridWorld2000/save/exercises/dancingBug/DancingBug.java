package exercises.dancingBug;

import info.gridworld.grid.Location;
import info.gridworld.actor.Bug;

public class DancingBug extends Bug
{
    private int[] list;
    private int idx;
    
    public DancingBug(int[] xlist)
    {
        list = xlist;
        idx = 0;
    }

    public void act()
    {
        int turns = list[idx++ % list.length];
        for (int i = 1; i <= turns; i++) turn();
        if (canMove())
        {
            move();
        }
    }
}
