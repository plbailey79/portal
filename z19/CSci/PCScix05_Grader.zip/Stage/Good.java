public class Good
{
	public static int fixYear(int y)
	{
		if (y >= 0 && y <= 32) y += 2000;
		if (y >= 33 && y <= 99) y += 1900;
		return y;
	}
	
    public static boolean checkMonth(int m)
    { 
		return m >= 1 && m <= 12; 
	}

    public static boolean checkDay(int d)
    { 
		return d >= 1 && d <= 31;
	}

    public static boolean checkYear(int y)
    { 
		return y >= 1001 && y <= 2999;
	}

    public static String makeMonth(int m)
    { 
		if (m == 1) return "January";
		if (m == 2) return "February";
		if (m == 3) return "March";
		if (m == 4) return "April";
		if (m == 5) return "May";
		if (m == 6) return "June";
		if (m == 7) return "July";
		if (m == 8) return "August";
		if (m == 9) return "September";
		if (m == 10) return "October";
		if (m == 11) return "November";
		if (m == 12) return "December";
		return "Mocktober"; 
	}

    public static String nameMonth(int m)
    { 
		switch (m)
		{
			case 1: return "January";
			case 2: return "February";
			case 3: return "March";
			case 4: return "April";
			case 5: return "May";
			case 6: return "June";
			case 7: return "July";
			case 8: return "August";
			case 9: return "September";
			case 10: return "October";
			case 11: return "November";
			case 12: return "December";
			default: return "Mocktober"; 
		}
	}

    public static String makeDay(int d)
    { 
		if (d == 11) return "11th";
		if (d == 12) return "12th";
		if (d == 13) return "13th";
		if (d % 10 == 1) return d + "st";
		if (d % 10 == 2) return d + "nd";
		if (d % 10 == 3) return d + "rd";
		return d + "th";
	}

    public static String makeYear(int y)
    { 
		if (y >= 0 && y <= 32) y = y + 2000;
		if (y >= 0 && y <= 99) y = y + 1900;
		return y + "";
	}
	
	public static boolean isLeapYear(int y)
	{
		return (y % 4 == 0 && (y % 100 != 0 || y % 400 == 0));
	}
	
	public static int monthLength(int m, int y)
	{
		switch (m)
		{
			case  2 : return (isLeapYear(y) ? 29 : 28);
			case  4 :
			case  6 :
			case  9 :
			case 11 : return 30;
			case  1 :
			case  3 :
			case  5 :
			case  7 :
			case  8 :
			case 10 :
			case 12 : return 31;
			default : return 0;
		}
	}
	
	public static int internalDate(int m, int d, int y)
	{
		return Julian.julianDate(m, d, y) - Julian.julianDate(1, 1, 1970);
	}
	
	public static String externalDate(int id)
	{
		return Julian.gregorianDate(id + Julian.julianDate(1, 1, 1970));
	}
	
	public static int currentInternalDate()
	{
		return Julian.currentJulianDate() - Julian.julianDate(1, 1, 1970);
	}
	
	public static int getDOW(int n)
	{
		// January 1, 1970 was a Thursday
		return Tool.mod(n + 3, 7);
	}
	
	public static String nameDOW(int n)
	{
		switch (Tool.mod(n, 7))
		{
			case 0 : return "Sunday";
			case 1 : return "Monday";
			case 2 : return "Tuesday";
			case 3 : return "Wednesday";
			case 4 : return "Thursday";
			case 5 : return "Friday";
			case 6 : return "Saturday";
			default : return "Grunsday";
		}
	}
}