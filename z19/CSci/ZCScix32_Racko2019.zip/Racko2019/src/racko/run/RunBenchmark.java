package racko.run;

import java.lang.Math;
import java.util.List;
import racko.Card;
import racko.Deck;
import racko.Player;
import racko.Rack;
import racko.Utilities;
import racko.player.PlayerFrog;

public class RunBenchmark
{
    private static boolean show = true;

    public static void main(String[] args)
    {
        test2();
    }
    
    public static void test1()
    {
        Player player = new PlayerFrog();
        drive(player, 1000000);
    }
    
    public static void test2()
    {
        show = false;
        
        List<Player> players = RunTournament.getTourneyDemo();
        
        for (Player player : players)
        {
            drive(player);
        }
    }
    
    public static void drive(Player player)
    {
        drive(player, 100000);
    }
    
    public static void drive(Player player, int top)
    {
        String p = Utilities.getPlayerName(player);
        double s = 0;
        double t = 0;
        double u = 0;
        double q = 0;
        double x = 0;
        for (int n = 1; n <= top; n++)
        {
            play(player);
            x += 1;
            s += turns * turns;
            t += turns;
            u += points;
            if (x % 10000 == 0 && show)
            {
                q = Math.sqrt((s/n) - (t/n) * (t/n));
                System.out.printf("Game %6d: %s %3d turns[%3.3f, %3.3f]  %3d points[%3.3f]\n", n, p, turns, t / n, q, points, u / n);
            }
        }
        
        q = Math.sqrt((s/x) - (t/x) * (t/x));
        //System.out.printf("%-20s turns[%3.3f, %3.3f]  points[%3.3f]\n", p, t / x, q, u / x);
        System.out.printf("%-20s\t%3.3f\t%3.3f\t%3.3f\t\r\n", p, t / x, q, u / x);
    }

    private static int points = 0;
    private static int turns = 0;

    public static void play(Player player)
    {
        points = 0;
        turns = 1;

        Deck deck = new Deck(true);
        Deck pile = new Deck(false);
        Rack rack = new Rack();

        deck.shuffle();
        deck.deal(rack);

        player.beginGame(new Rack(rack));

        while (true)
        {
            if (deck.isEmpty())
            {
                pile.shuffle();
                deck = pile;
                pile = new Deck(false);
            }

            pile.push(deck.pop());

            Card card = pile.peek();
            Rack temp = new Rack(rack);
            int k = player.acceptCard(temp, card);
            if (k > 0)
            {
                card = pile.pop();
            } else
            {
                if (deck.isEmpty())
                {
                    pile.shuffle();
                    deck = pile;
                    pile = new Deck(false);
                }
                card = deck.pop();
                k = player.placeCard(temp, card);
            }

            if (k >= 1 && k <= Rack.LEN)
            {
                pile.push(rack.get(k - 1));
                rack.set(k - 1, card);
            } else
            {
                pile.push(card);
            }

            if (rack.isSorted())
            {
                points = rack.score();
                break;
            }
            if (++turns > 256)
            {
                // System.out.println("OH NO A LOOP!");
                points = 0;
                return;
            }
        }
    }
}
