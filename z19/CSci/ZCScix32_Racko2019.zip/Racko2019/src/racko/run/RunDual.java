package racko.run;

import racko.gui.JFrameDual;
import java.util.List;
import java.util.LinkedList;
import racko.Card;
import racko.Deck;
import racko.Player;
import racko.player.PlayerFrog;
import racko.player.PlayerTurtle;
import racko.Rack;
import racko.Utilities;

public class RunDual
{
    public static final int DELAY1 = 128;
    public static final int DELAY2 = 1024;
    public static int winner;

    public static void main(String[] args)
    {
        Player player1 = new PlayerFrog();
        Player player2 = new PlayerTurtle();
        
        LinkedList<Player> players = new LinkedList<Player>();
        players.add(player1);
        players.add(player2);
        
        double t = 0;
        for (int n = 1; n <= 1000; n++)
        {
            int c = play(players);
            t += c;
            String p = Utilities.getPlayerName(players.get(winner - 1));
            System.out.printf("Game %6d: %20s %3d turns  average: %3.3f\n", n, p, c, t / n);
        }
    }

    public static int play(List<Player> players)
    {
        Deck deck = new Deck(true);
        Deck pile = new Deck(false);

        deck.shuffle();

        Rack rack1 = new Rack();
        Rack rack2 = new Rack();
        List<Rack> racks = new LinkedList<Rack>();

        racks.add(rack1);
        racks.add(rack2);
        deck.deal(racks);

        players.get(0).beginGame(new Rack(rack1));
        players.get(1).beginGame(new Rack(rack2));

        pile.push(deck.pop());

        JFrameDual form = new JFrameDual();

        for (int p = 1; p <= 2; p++)
        {
            form.setName(p, Utilities.getPlayerName(players.get(p - 1)));
            Rack rack = racks.get(p - 1);
            for (int k = 1; k <= 10; k++)
            {
                Card card = rack.get(k - 1);
                int v = card.value();
                form.setSlot(p, k, v);
            }
        }

        int playerNumber = 1;
        int counter = 1;

        while (true)
        {
            form.setLabels(playerNumber, counter, pile.peek().value());
            Utilities.delay(DELAY1);

            Rack rack = racks.get(playerNumber - 1);
            Player player = players.get(playerNumber - 1);

            Card card = pile.peek();
            Rack temp = new Rack(rack);
            int k = player.acceptCard(temp, card);
            if (k > 0)
            {
                card = pile.pop();
            } else
            {
                if (deck.isEmpty())
                {
                    pile.shuffle();
                    deck = pile;
                    pile = new Deck(false);
                }
                card = deck.pop();
                k = player.placeCard(temp, card);
            }

            if (k >= 1 && k <= Rack.LEN)
            {
                pile.push(rack.get(k - 1));
                rack.set(k - 1, card);

                int p = playerNumber;
                int v = card.value();
                form.setSlot(p, k, v);
            } else
            {
                pile.push(card);
            }

            form.setLabels(playerNumber, counter, pile.peek().value());

            if (rack.isSorted())
            {
                winner = playerNumber;
                Utilities.delay(DELAY2);
                break;
            }

            playerNumber = (playerNumber % 2) + 1;
            if (playerNumber == 1)
            {
                ++counter;
            }
        }
        form.close();
        return counter;
    }
}
