package racko.run;

import racko.Card;
import racko.Deck;
import racko.Player;
import racko.Rack;
import racko.Utilities;
import racko.player.PlayerTurtle;
import racko.gui.JFrameSolo;

public class RunSolo
{
    public static final int DELAY1 = 256;
    public static final int DELAY2 = 1024;
    //public static final int DELAY1 = 16;
    //public static final int DELAY2 = 256;

    public static void main(String[] args)
    {
        Player player = new PlayerTurtle();
        double t = 0;
        String p = Utilities.getPlayerName(player);
        for (int n = 1; n <= 1000; n++)
        {
            int c = play(player);
            t += c;
            System.out.printf("Game %6d: %s %3d turns  average: %3.3f\n", n, p, c, t / n);
        }
    }

    public static int play(Player player)
    {
        Deck deck = new Deck(true);
        Deck pile = new Deck(false);
        Rack rack = new Rack();

        deck.shuffle();
        deck.deal(rack);

        player.beginGame(new Rack(rack));

        JFrameSolo form = new JFrameSolo();
        form.setName(Utilities.getPlayerName(player));

        for (int k = 1; k <= 10; k++)
        {
            Card card = rack.get(k - 1);
            int v = card.value();
            form.setSlot(k, v);
        }

        int counter = 1;

        while (true)
        {
            if (deck.isEmpty())
            {
                pile.shuffle();
                deck = pile;
                pile = new Deck(false);
            }

            pile.push(deck.pop());
            form.setLabels(counter, pile.peek().value());
            Utilities.delay(DELAY1);

            Card card = pile.peek();
            Rack temp = new Rack(rack);
            int k = player.acceptCard(temp, card);
            if (k > 0)
            {
                card = pile.pop();
            } else
            {
                if (deck.isEmpty())
                {
                    pile.shuffle();
                    deck = pile;
                    pile = new Deck(false);
                }
                card = deck.pop();
                k = player.placeCard(temp, card);
            }

            if (k >= 1 && k <= Rack.LEN)
            {
                pile.push(rack.get(k - 1));
                rack.set(k - 1, card);

                int v = card.value();
                form.setSlot(k, v);
            } else
            {
                pile.push(card);
            }

            form.setLabels(counter, pile.peek().value());

            if (rack.isSorted())
            {
                Utilities.delay(DELAY2);
                break;
            }
            ++counter;
        }
        form.close();
        return counter;
    }
}
