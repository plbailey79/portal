package racko.gui;

import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import javax.swing.BorderFactory;
import javax.swing.border.EtchedBorder;

public class JPanelRack extends JPanel
{  
    private JLabel[] slotLabels;
    
    public JPanelRack()
    {
        slotLabels = new JLabel[10];

        setBorder(BorderFactory.createTitledBorder("Rack"));
        setLayout(null);
        setLocation(5, 10);
        setSize(280, 400);

        for (int k = 1; k <= 10; k++)
        {
            JLabel nLabel = new JLabel();
            nLabel.setText("" + k);
            nLabel.setForeground(Color.red);
            nLabel.setHorizontalAlignment(SwingConstants.CENTER);
            nLabel.setLocation(5, 35 * (10 - k) + 33);
            nLabel.setSize(30, 30);
            nLabel.setBorder(BorderFactory.createEtchedBorder(EtchedBorder.RAISED));
            add(nLabel);

            JLabel sLabel = new JLabel();
            sLabel.setLocation(40, 35 * (10 - k) + 30);
            sLabel.setSize(220, 36);
            sLabel.setBorder(BorderFactory.createLoweredBevelBorder());
            add(sLabel);

            JLabel cLabel = new JLabel();
            add(cLabel);
            slotLabels[k - 1] = cLabel;
        }
    }

    public void setName(String name)
    {
        setBorder(BorderFactory.createTitledBorder(name));
    }

    public void setSlot(int k, int v)
    {
        if (k >= 1 && k <= 10 && v >= 1 && v <= 60)
        {
            JLabel cLabel = slotLabels[k - 1];
            cLabel.setText("" + v);
            cLabel.setForeground(Color.blue);
            cLabel.setHorizontalAlignment(SwingConstants.CENTER);
            cLabel.setLocation(3 * v + 43, 35 * (10 - k) + 33);
            cLabel.setSize(30, 30);
            cLabel.setBorder(BorderFactory.createLineBorder(Color.black));
        }
    }
}
