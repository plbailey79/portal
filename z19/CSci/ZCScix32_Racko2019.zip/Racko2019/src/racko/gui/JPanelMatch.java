package racko.gui;

import java.awt.Color;
import javax.swing.BorderFactory;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import javax.swing.border.EtchedBorder;

public class JPanelMatch extends JPanel
{
    JPanel scorePanel = new JPanel();
    JLabel[] nameLabels;
    JLabel[] gameLabels;
    JLabel[][] scoreLabels;

    public JPanelMatch()
    {
        setLayout(null);

        scorePanel = new JPanel();
        scorePanel.setLayout(null);
        scorePanel.setLocation(2, 2);
        scorePanel.setSize(800, 200);

        gameLabels = new JLabel[14];

        for (int k = 1; k <= 14; k++)
        {
            int lx = 38 * k + 90;
            int ly = 10;
            int sx = 36;
            int sy = 30;

            String text = "" + k;

            if (k == 14)
            {
                lx += 20;
                text = "Total";
            }

            JLabel gLabel = new JLabel();
            gLabel.setText(text);
            gLabel.setForeground(Color.black);
            gLabel.setHorizontalAlignment(SwingConstants.CENTER);
            gLabel.setLocation(lx, ly);
            gLabel.setSize(sx, sy);
            // gLabel.setBorder(BorderFactory.createEtchedBorder(EtchedBorder.RAISED));
            scorePanel.add(gLabel);
        }

        nameLabels = new JLabel[2];
        scoreLabels = new JLabel[2][14];

        for (int p = 1; p <= 2; p++)
        {
            int lx = 10;
            int ly = 32 * p + 10;
            int sx = 100;
            int sy = 30;

            String text = "*";

            JLabel pName = new JLabel();
            pName.setText(text);
            pName.setForeground(Color.blue);
            pName.setHorizontalAlignment(SwingConstants.LEFT);
            pName.setLocation(lx, ly);
            pName.setSize(sx, sy);
            pName.setBorder(BorderFactory.createEtchedBorder(EtchedBorder.LOWERED));
            nameLabels[p - 1] = pName;
            scorePanel.add(pName);

            for (int k = 1; k <= 14; k++)
            {
                lx = 38 * k + 90; // was 32
                sx = 36; // was 30
                sy = 30;

                text = "__  ";

                if (k == 14)
                {
                    lx += 20;
                    sx += 10;
                    text = "0  ";
                }

                JLabel sLabel = new JLabel();
                sLabel.setText(text);
                sLabel.setForeground(Color.blue);
                sLabel.setBackground(Color.white);
                sLabel.setOpaque(true);
                sLabel.setHorizontalAlignment(SwingConstants.RIGHT);
                sLabel.setLocation(lx, ly);
                sLabel.setSize(sx, sy);
                sLabel.setBorder(BorderFactory.createEtchedBorder(EtchedBorder.RAISED));
                scoreLabels[p - 1][k - 1] = sLabel;
                scorePanel.add(sLabel);
            }
            add(scorePanel);
        }
        setOpaque(true);
    }

    public void putName(int p, String name)
    {
        nameLabels[p - 1].setText(name);
    }

    public void putTotal(int p, int s)
    {
        scoreLabels[p - 1][13].setText(s + "  ");
    }

    public void putScore(int p, int k, int s, boolean w, boolean q)
    {
        scoreLabels[p - 1][k - 1].setForeground(w ? Color.green : Color.red);
        scoreLabels[p - 1][k - 1].setBackground(q ? Color.yellow : Color.white);
        scoreLabels[p - 1][k - 1].setText(s + "  ");
    }
    
    public void clear()
    {
        for (int p = 1; p <= 2; p++)
        {
            nameLabels[p - 1].setText("");
        
            for (int k = 1; k <= 14; k++)
            {
                scoreLabels[p - 1][k - 1].setForeground(Color.blue);
                scoreLabels[p - 1][k - 1].setBackground(Color.white);
                scoreLabels[p - 1][k - 1].setText("");
                scoreLabels[p - 1][k - 1].setText("");
            }
        }
    }
}
