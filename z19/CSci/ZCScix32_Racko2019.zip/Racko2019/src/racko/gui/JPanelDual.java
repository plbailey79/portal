package racko.gui;

import java.awt.Color;
import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.SwingConstants;
import javax.swing.BorderFactory;
import javax.swing.border.EtchedBorder;

public class JPanelDual extends JPanel
{
    private JPanelRack[] rackPanels;
    private JLabel playerLabel;
    private JLabel counterLabel;
    private JLabel discardLabel;
    
    public JPanelDual()
    {
        setLayout(null);

        rackPanels = new JPanelRack[2];

        for (int p = 1; p <= 2; p++)
        {
            JPanelRack rackPanel = new JPanelRack();

            rackPanel.setBorder(BorderFactory.createTitledBorder("Rack " + p));
            rackPanel.setLocation((p - 1) * 290 + 5, 10);
            rackPanels[p - 1] = rackPanel;

            add(rackPanel);
        }

        playerLabel = new JLabel();
        playerLabel.setLocation(100, 415);
        playerLabel.setSize(100, 20);

        counterLabel = new JLabel();
        counterLabel.setLocation(100, 435);
        counterLabel.setSize(100, 20);

        discardLabel = new JLabel();
        discardLabel.setForeground(Color.magenta);
        discardLabel.setHorizontalAlignment(SwingConstants.CENTER);
        discardLabel.setLocation(290, 420);
        discardLabel.setSize(30, 30);
        discardLabel.setBorder(BorderFactory.createEtchedBorder(EtchedBorder.LOWERED));

        add(playerLabel);
        add(counterLabel);
        add(discardLabel);
        setOpaque(true);
    }

    public void setName(int p, String name)
    {
        rackPanels[p - 1].setName(name);
    }
    
    public void setSlot(int p, int k, int v)
    {
        rackPanels[p - 1].setSlot(k, v);
    }

    public void setLabels(int p, int c, int v)
    {
        if (p >= 1 && p <= 2)
        {
            playerLabel.setText("Player: " + p);
        }
        if (c >= 1)
        {
            counterLabel.setText("Counter: " + c);
        }
        if (v >= 1 && v <= 60)
        {
            discardLabel.setText("" + v);
        }
    }
}
