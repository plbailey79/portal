package racko;

import java.util.List;
import java.util.LinkedList;
import java.util.Collections;

public class Deck extends LinkedList<Card>
{
    public Deck()
    { }

    public Deck(boolean fill)
    {
        if (fill)
        {
            fill();
        }
    }

    public void fill()
    {
        clear();
        int min = Card.MIN;
        int max = Card.MAX;
        for (int k = min; k <= max; k++)
        {
            add(new Card(k));
        }
    }

    public void shuffle()
    {
        Collections.shuffle(this);
    }

    public void deal(Rack rack)
    {
        if (Rack.LEN < size())
        {
            rack.clear();

            for (int i = 0; i < Rack.LEN; i++)
            {
                rack.add(pop());
            }
        }
    }

    public void deal(List<Rack> racks)
    {
        if (racks.size() * Rack.LEN < size())
        {
            for (Rack rack : racks)
            {
                rack.clear();
            }
            for (int i = 0; i < Rack.LEN; i++)
            {
                for (Rack rack : racks)
                {
                    rack.add(pop());
                }
            }
        }
    }
}
