package racko.player;

import java.util.Random;
import racko.Card;
import racko.Player;
import racko.Rack;

public class PlayerFrog implements Player
{
    Random random = new Random();

    public void beginGame(Rack rack)
    {
    }

    public int acceptCard(Rack rack, Card card)
    {
        int k = getSlot(rack, card);
        return k;
    }

    public int placeCard(Rack rack, Card card)
    {
        int k = getSlot(rack, card);
        return k;
    }

    public static int getSlot(Rack rack, Card card)
    {
        int k = firstSlot(rack, card);
        if (k == 0)
        {
            k = lastSlot(rack, card);
        }
        return k;
    }

    public static int firstSlot(Rack rack, Card card)
    {
        int v = card.value();
        int k = 0;
        for (int i = 1; i <= Rack.LEN; i++)
        {
            int w = rack.value(i);
            if (v < w)
            {
                k = i;
                break;
            }
        }
        return k;
    }

    public static int lastSlot(Rack rack, Card card)
    {
        int v = card.value();
        int k = 0;
        for (int i = Rack.LEN; i >= 1; i--)
        {
            int w = rack.value(i);
            if (v > w)
            {
                k = i;
                break;
            }
        }
        return k;
    }
}
