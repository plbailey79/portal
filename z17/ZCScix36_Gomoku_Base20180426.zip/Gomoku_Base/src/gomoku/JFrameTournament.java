package gomoku;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.Timer;
import javax.swing.JSlider;

public class JFrameTournament extends JFrameAbstract
{
    private Player p1;
    private Player p2;
    private int size = 19;
    private int goal = 5;
    private int delay1 = 1;
    private int delay2 = 4;
    private int delay3 = 16;
    private int delay4 = 64;
    private int delay = 16;
    
    private int t1 = 0;
    private int t2 = 0;
    private int gc = 0;
    
    private Tournament tournament;
    private Tournament.Match match;
    private Timer timer;
    
    private boolean tied = false;
    
    public JFrameTournament()
    {
        initComponents();
        tournament = new Tournament();
        jLabelDelay.setText("Delay: " + delay);   
        jTextArea.setText(tournament.getTournament());
        setLocationRelativeTo(null);
        attachTimer();
    }
    
    public void attachTimer()
    {
        ActionListener actionListener = new ActionListener()
        {
            public void actionPerformed(ActionEvent evt)
            {
                timerFired();
            }
        };
        timer = new Timer(delay1, actionListener);
    }
    
    public void timerFired()
    {
        timer.stop();
        if (tied)
        {
            tied = false;
            playAgain();
        }
        if (tournament.more())
        {
            playMatch();
        }
    }
    
    public void playTournament()
    {
        jTextArea.setText(tournament.getStandings());
        
        timer.start();
    }
    
    public void playMatch()
    {
        match = tournament.next();

        p1 = match.getPlayer(1);
        p2 = match.getPlayer(2);
            
        t1 = 0;
        t2 = 0;
        gc = 0;
       
        jPanelScore.clear();
        jPanelScore.putName(1, Utilities.getPlayerName(p1));
        jPanelScore.putName(2, Utilities.getPlayerName(p2));

        playGame();
    }
    
    public void playAgain()
    {
        p1 = match.getPlayer(1);
        p2 = match.getPlayer(2);
            
        t1 = 0;
        t2 = 0;
        gc = 0;
       
        jPanelScore.clear();
        jPanelScore.putName(1, Utilities.getPlayerName(p1));
        jPanelScore.putName(2, Utilities.getPlayerName(p2));

        playGame();
    }
    
    public void playGame()
    {
        int ps = (gc + 1) % 2 + 1;
        jPanelBoard.go(p1, p2, size, goal, ps, delay1, delay2 * delay, delay3 * delay);
    }
    
    public void finished(State state)
    {
        show(state);
        javax.swing.SwingUtilities.invokeLater(new Runnable() {
            public void run() 
            {
                Utilities.delay(delay3 * delay);  
                if (gc < 13) playGame();
                else finishedMatch();
            }
        });
    }
    
    public void finishedMatch()
    {
        if (t1 == t2)
        {
            System.out.println("TIED!");
            tied = true;
        }
        else
        {
            match.setScores(t1, t2);
            tied = false;
        }
        String msg = String.format("Final Score\nPlayer 1: %d (%s)\nPlayer 2: %d (%s)\n",
            t1,
            Utilities.getPlayerName(p1),
            t2,
            Utilities.getPlayerName(p2));
        System.out.println(msg);
        jTextArea.setText(tournament.getStandings());
        System.out.println(jTextArea.getText());
        jTextArea.invalidate();
        jTextArea.repaint();
        revalidate();
        repaint();
        javax.swing.SwingUtilities.invokeLater(new Runnable() 
        {
            public void run() 
            {
                Utilities.delay(delay4 * delay);   
                if (tournament.more()) timer.start();
            }
        });
    }

    public void show(State state)
    {
        int s1 = state.getScore(State.BLACK);
        int s2 = state.getScore(State.WHITE);
        boolean b1 = state.getWinner() == State.BLACK;
        boolean b2 = state.getWinner() == State.WHITE;
        boolean q1 = false;
        boolean q2 = false;
        t1 += s1;
        t2 += s2;
        gc += 1;

        jPanelScore.putScore(1, gc, s1, b1, q1);
        jPanelScore.putScore(2, gc, s2, b2, q2);
        jPanelScore.putTotal(1, t1);
        jPanelScore.putTotal(2, t2);
        jPanelScore.invalidate();
        jPanelScore.repaint();
        revalidate();
        repaint();
        System.out.printf("Game: %d  %s: %d   %s: %d\n", gc, Utilities.getPlayerName(p1), t1, Utilities.getPlayerName(p2), t2);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents()
    {

        jPanelScore = new gomoku.JPanelScore();
        jPanelBoard = new gomoku.JPanelBoard();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTextArea = new javax.swing.JTextArea();
        jButtonGo = new javax.swing.JButton();
        jSlider = new javax.swing.JSlider();
        jLabelDelay = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        javax.swing.GroupLayout jPanelBoardLayout = new javax.swing.GroupLayout(jPanelBoard);
        jPanelBoard.setLayout(jPanelBoardLayout);
        jPanelBoardLayout.setHorizontalGroup(
            jPanelBoardLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        jPanelBoardLayout.setVerticalGroup(
            jPanelBoardLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 532, Short.MAX_VALUE)
        );

        jTextArea.setBackground(new java.awt.Color(0, 0, 153));
        jTextArea.setColumns(20);
        jTextArea.setFont(new java.awt.Font("Courier New", 1, 12)); // NOI18N
        jTextArea.setForeground(new java.awt.Color(255, 255, 0));
        jTextArea.setRows(5);
        jTextArea.setText("Tournament Information");
        jScrollPane1.setViewportView(jTextArea);

        jButtonGo.setForeground(new java.awt.Color(0, 204, 0));
        jButtonGo.setText("Go");
        jButtonGo.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                jButtonGoActionPerformed(evt);
            }
        });

        jSlider.addChangeListener(new javax.swing.event.ChangeListener()
        {
            public void stateChanged(javax.swing.event.ChangeEvent evt)
            {
                jSliderStateChanged(evt);
            }
        });

        jLabelDelay.setText("Delay");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jPanelScore, javax.swing.GroupLayout.PREFERRED_SIZE, 700, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jSlider, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jButtonGo, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabelDelay))
                                .addGap(0, 0, Short.MAX_VALUE))))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jPanelBoard, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGap(11, 11, 11)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 298, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jPanelScore, javax.swing.GroupLayout.PREFERRED_SIZE, 116, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabelDelay)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jSlider, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jButtonGo)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanelBoard, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jScrollPane1))
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButtonGoActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_jButtonGoActionPerformed
    {//GEN-HEADEREND:event_jButtonGoActionPerformed
        playTournament();
    }//GEN-LAST:event_jButtonGoActionPerformed

    private void jSliderStateChanged(javax.swing.event.ChangeEvent evt)//GEN-FIRST:event_jSliderStateChanged
    {//GEN-HEADEREND:event_jSliderStateChanged
       
        JSlider source = (JSlider)evt.getSource();
        if (source.getValueIsAdjusting()) return;
        int fps = (int)source.getValue();
        delay = (int)((100 - fps) * 32 / 100);
        jLabelDelay.setText("Delay: " + delay);   
        timer.setDelay(delay1 * delay);
        
    }//GEN-LAST:event_jSliderStateChanged

    /**
     * @param args the command line arguments
     */
    public static void main(String args[])
    {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try
        {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels())
            {
                if ("Nimbus".equals(info.getName()))
                {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        }
        catch (ClassNotFoundException ex)
        {
            java.util.logging.Logger.getLogger(JFrameTournament.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        catch (InstantiationException ex)
        {
            java.util.logging.Logger.getLogger(JFrameTournament.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        catch (IllegalAccessException ex)
        {
            java.util.logging.Logger.getLogger(JFrameTournament.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        catch (javax.swing.UnsupportedLookAndFeelException ex)
        {
            java.util.logging.Logger.getLogger(JFrameTournament.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable()
        {
            public void run()
            {
                new JFrameTournament().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButtonGo;
    private javax.swing.JLabel jLabelDelay;
    private gomoku.JPanelBoard jPanelBoard;
    private gomoku.JPanelScore jPanelScore;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JSlider jSlider;
    private javax.swing.JTextArea jTextArea;
    // End of variables declaration//GEN-END:variables
}
