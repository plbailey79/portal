package gomoku;

import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.ArrayList;
import java.util.Date;

public class Tournament
{
    private Record[] records;
    private Match[] matches;
    
    private int matchNumber = 0;
    
    public Tournament()
    {
        List<Player> players = getTourney();
        loadTournament(players);
    }
    
    public boolean more()
    {
        return matchNumber < matches.length;
    }
    
    public Match next()
    {
        return matches[matchNumber++];
    }

    public void loadTournament(List<Player> players)
    {
        int c = 0;
        records = new Record[players.size()];
        for (Player player : players)
        {
            records[c++] = new Record(player);
        }
        
        c = 0;
        matches = new Match[records.length * (records.length - 1) / 2];
        for (int i = 0; i < records.length - 1; i++)
        {
            for (int j = i + 1; j < records.length; j++)
            {
                matches[c++] = new Match(i, j);
            }
        }
        Collections.shuffle(Arrays.asList(matches));
    }
    
    public String getTournament()
    {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < matches.length; i++)
        {
            Match match = matches[i];
            sb.append(String.format("Match# %2d  %-10s v.  %-10s\n",
                    i + 1,
                    Utilities.getPlayerName(records[match.recno1].player),
                    Utilities.getPlayerName(records[match.recno2].player)));
        }
        return sb.toString();
    }

    public void printTournament()
    {
        System.out.println(getTournament());
    }    
        
    public String getStandings()
    {
        Record[] stand = records.clone();

        Arrays.sort(stand, Collections.reverseOrder());
        
        StringBuilder sb = new StringBuilder();
        sb.append("           Tournament Standings\r\n\r\n");
        sb.append(String.format("%-20s  %2s  %2s    [%5s]\r\n\r\n",
                "Player",
                "W",
                "L",
                "Pnts"));

        for (int i = 0; i < stand.length; i++)
        {
            Record record = stand[i];

            sb.append(String.format("%-20s  %2d  %2d    [%5d]\r\n",
                    Utilities.getPlayerName(record.player),
                    record.wins,
                    record.losses,
                    record.points));

        }
        sb.append("\r\n");
        return sb.toString();
    }

    public void printStandings()
    {
        System.out.println(getStandings());
    }
    
    public void saveStandings()
    {
        String fileName = fileName = "Tourn" + (new SimpleDateFormat("yyyyMMddHHmmss")).format(new Date()) + ".txt";
        String pathName = System.getProperty("user.home") + "/Desktop/" + fileName;
              
        Utilities.saveText(pathName, getStandings());
    }

    public String labelStandings()
    {
        return String.format("<html><pre>%s</pre></html>", getStandings());
    }
    
    public List<Player> getTourney()
    {
        List<Player> players = new ArrayList<Player>();

        players.add(new PlayerBug());
        players.add(new PlayerCrab());
        players.add(new PlayerSlug());
        players.add(new PlayerSpider());

        return players;
    }
    
    class Record implements Comparable<Record>
    {
        public Player player;
        public int wins;
        public int losses;
        public int points;

        public Record(Player player)
        {
            this.player = player;
        }

        public int compareTo(Record that)
        {
            float wp1 = this.percentage();
            float wp2 = that.percentage();

            if (wp1 < wp2)
            {
                return -1;
           }
            if (wp2 < wp1)
            {
                return 1;
            }
            if (wp1 == wp2)
            {
                if (this.points < that.points)
                {
                    return -1;
                }
                if (that.points < this.points)
                {
                    return 1;
                }
                return 0;
            }
            return 0;
        }

        public float percentage()
        {
            if (wins + losses < 1)
            {
                return .5f;
            }
            return ((float)wins) / (((float)wins) + ((float)losses));
        }
    }

    class Match
    {
        private int recno1;
        private int recno2;
        private int score1;
        private int score2;
        private int winner;

        public Match(int r1, int r2)
        {
            recno1 = r1;
            recno2 = r2;
            score1 = 0;
            score2 = 0;
            winner = 0;
        }
        
        public Player getPlayer(int i)
        {
            if (i == 1) return records[recno1].player;
            if (i == 2) return records[recno2].player;
            return null;
        }
        
        public void setScores(int s1, int s2)
        {
            int w = 0;
            if (s1 > s2)
            {
                w = 1;
            }
            if (s2 > s1)
            {
                w = 2;
            }
            
            score1 = s1;
            score2 = s2;
            winner = w;
            
            Record record1 = records[recno1];
            Record record2 = records[recno2];
            record1.wins += (w == 1) ? 1 : 0;
            record1.losses += (w == 1) ? 0 : 1;
            record1.points += s1;
            record2.wins += (w == 2) ? 1 : 0;
            record2.losses += (w == 2) ? 0 : 1;
            record2.points += s2;
        }
    }    
}
