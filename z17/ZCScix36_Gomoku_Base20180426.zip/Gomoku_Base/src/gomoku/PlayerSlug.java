package gomoku;

import java.util.Random;
import java.util.List;

public class PlayerSlug implements Player
{
    public Position move(Board board)
    {
        return board.getRandomPosition();
    }
}
