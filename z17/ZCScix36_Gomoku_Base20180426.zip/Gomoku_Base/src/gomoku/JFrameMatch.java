package gomoku;

public class JFrameMatch extends JFrameAbstract
{
    private Player p1 = new PlayerSpider();
    private Player p2 = new PlayerCrab();
    private int size = 19;
    private int goal = 5;
    private int delay1 = 16;
    private int delay2 = 32;
    private int delay3 = 128;
    
    private int t1 = 0;
    private int t2 = 0;
    private int gc = 0;

    public JFrameMatch()
    {
        initComponents();
        jPanelScore.putName(1, Utilities.getPlayerName(p1));
        jPanelScore.putName(2, Utilities.getPlayerName(p2));
        setLocationRelativeTo(null);
    }
    
    public void playMatch()
    {
        t1 = 0;
        t2 = 0;
        gc = 0;
       
        jPanelScore.clear();
        jPanelScore.putName(1, Utilities.getPlayerName(p1));
        jPanelScore.putName(2, Utilities.getPlayerName(p2));

        playGame();
    }
    
    public void playGame()
    {
        int ps = (gc + 1) % 2 + 1;

        System.out.printf("Game: %d\n", gc);
        jPanelBoard.go(p1, p2, size, goal, ps, delay1, delay2, delay3);
    }
    
    public void finished(State state)
    {
        show(state);
        Utilities.delay(delay3);
        if (gc < 13) playGame();
        String msg = String.format("Final Score\nPlayer 1: %d (%s)\nPlayer 2: %d (%s)\n",
                t1,
                Utilities.getPlayerName(p1),
                t2,
                Utilities.getPlayerName(p2));
        System.out.println(msg);
    }

    public void show(State state)
    {
        int s1 = state.getScore(State.BLACK);
        int s2 = state.getScore(State.WHITE);
        boolean b1 = state.getWinner() == State.BLACK;
        boolean b2 = state.getWinner() == State.WHITE;
        boolean q1 = false; //rack1.numSequence() > 0;
        boolean q2 = false; // rack2.numSequence() > 0;
        t1 += s1;
        t2 += s2;
        gc += 1;

        jPanelScore.putScore(1, gc, s1, b1, q1);
        jPanelScore.putScore(2, gc, s2, b2, q2);
        jPanelScore.putTotal(1, t1);
        jPanelScore.putTotal(2, t2);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents()
    {

        jPanelScore = new gomoku.JPanelScore();
        jPanelBoard = new gomoku.JPanelBoard();
        jButtonGo = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setFont(new java.awt.Font("Courier New", 1, 12)); // NOI18N

        jPanelScore.setFont(new java.awt.Font("Courier New", 1, 12)); // NOI18N

        javax.swing.GroupLayout jPanelBoardLayout = new javax.swing.GroupLayout(jPanelBoard);
        jPanelBoard.setLayout(jPanelBoardLayout);
        jPanelBoardLayout.setHorizontalGroup(
            jPanelBoardLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 615, Short.MAX_VALUE)
        );
        jPanelBoardLayout.setVerticalGroup(
            jPanelBoardLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 521, Short.MAX_VALUE)
        );

        jButtonGo.setText("Go");
        jButtonGo.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                jButtonGoActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jPanelBoard, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jButtonGo, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addComponent(jPanelScore, javax.swing.GroupLayout.PREFERRED_SIZE, 698, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanelScore, javax.swing.GroupLayout.PREFERRED_SIZE, 129, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jButtonGo)
                    .addComponent(jPanelBoard, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButtonGoActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_jButtonGoActionPerformed
    {//GEN-HEADEREND:event_jButtonGoActionPerformed
        playMatch();
    }//GEN-LAST:event_jButtonGoActionPerformed

    public static void main(String args[])
    {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try
        {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels())
            {
                if ("Nimbus".equals(info.getName()))
                {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex)
        {
            java.util.logging.Logger.getLogger(JFrameMatch.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex)
        {
            java.util.logging.Logger.getLogger(JFrameMatch.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex)
        {
            java.util.logging.Logger.getLogger(JFrameMatch.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex)
        {
            java.util.logging.Logger.getLogger(JFrameMatch.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable()
        {
            public void run()
            {
                new JFrameMatch().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButtonGo;
    private gomoku.JPanelBoard jPanelBoard;
    private gomoku.JPanelScore jPanelScore;
    // End of variables declaration//GEN-END:variables
}
