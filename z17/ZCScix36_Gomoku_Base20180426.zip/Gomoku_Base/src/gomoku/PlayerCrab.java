package gomoku;

import java.util.ArrayList;
import java.util.Random;
import java.util.List;

public class PlayerCrab implements Player
{   
    public Position move(Board board)
    {
        return board.getRandomPosition(getCentralPositions(board));
    }
    
    public List<Position> getCentralPositions(Board board)
    {
        List<Position> positions = new ArrayList<Position>();
        int size = board.size();
        for (int wid = size / 2 + 1; wid >= 0; wid--)
        {
            positions = getEmptyPositions(board, wid);
            if (positions.size() > 0) break;
        }
        return positions;
    }
    
    public List<Position> getEmptyPositions(Board board, int wid)
    {
        List<Position> positions = new ArrayList<Position>();
        int size = board.size();
        
        for (int r = wid; r < size - wid; r++)
        {
            for (int c = wid; c < size - wid; c++)
            {
                if (board.get(r, c) == 0) 
                {
                    positions.add(new Position(r, c));
                }
            }
        }
        return positions;
    }
}
