import java.util.Arrays;
import java.util.Random;

public class BoundList
{
    private int[] a;        // Fixed Length Array
    private int n;          // Number of Occupied Slots

    public BoundList()
    {
        a = new int[1000];
        n = 0;
    }

    public BoundList(int length)
    {
        a = new int[length];
        n = 0;
    }
	
	public BoundList(int[] x)
	{
		copy(x, x.length, x.length);
	}
	
	public BoundList(BoundList bl)
	{
		copy(bl.a, bl.length(), bl.size());
	}
	
	public BoundList(BoundList bl, int length)
	{
		copy(bl.a, length, bl.size());
	}
	
	public BoundList(BoundList bl, int length, int size)
	{
		copy(bl.a, length, size);
	}
	
	public void copy(int[] x, int length, int size)
	{
		if (length < 0) length = 0;
		if (size < 0) size = 0;
		if (size > length) size = length;
		
		a = new int[length];
		n = 0;
		
		for (int i = 0; i < size; i++)
		{
			if (x[i] > 0)
			{
				a[n++] = x[i];
			}
		}
	}
	
	public String toString()
	{ 
		String s = "[";
		for (int i = 0; i < n; i++)
		{
			if (i > 0) s += ", ";
			s += a[i];
		}
		s += "]";
		return s;
	}
	
	public int length()
	{
		return a.length;
	}
	
	public int size()
	{
		return n;
	}
	
	public int get(int i)
	{
		int v = 0;
		if (i >= 0 && i < n)
		{
			v = a[i];
		}
		return v;
	}
	
	public boolean set(int i, int v)
	{
		boolean b = false;
		if (i >= 0 && i <= n && i < a.length)
		{
			a[i] = v;
			b = true;
		}
		return b;
	}
	
	public void print()
	{
		for (int i = 0; i < n; i++)
		{
			System.out.printf("a[%03d] = %d\n", i, a[i]);
		}
	}
	
	public int minimum()
	{
		int v = -1;
		if (n > 0)
		{
			v = 0;
		}
		for (int i = 1; i < n; i++)
		{
			if (a[i] < a[v]) v = i;
		}
		return v;
	}
	
	public int maximum()
	{
		int v = -1;
		if (n > 0)
		{
			v = 0;
		}
		for (int i = 1; i < n; i++)
		{
			if (a[i] > a[v]) v = i;
		}
		return v;
	}
	
	public boolean insert(int i, int v)
	{
		boolean b = false;
		if (i >= 0 && i <= n && n < a.length && v > 0)
		{
			for (int j = n; j > i; j--)
			{
				a[j] = a[j - 1];
			}
			a[i] = v;
			n++;
			b = true;
		}
		return b;
	}
	
	public boolean delete(int i)
	{
		boolean b = false;
		if (i >= 0 && i < n)
		{
			for (int j = i; j < n-1; j++)
			{
				a[j] = a[j + 1];
			}
			b = true;
			n--;
		}
		return b;
	}
	
    public static BoundList generate(int length, int size, int max)
    {
        BoundList bl = new BoundList(length);
        bl.n = size;
        Random random = new Random();
        for (int i = 0; i < size; i++)
        {
            bl.a[i] = random.nextInt(max) + 1;
        }
		return bl;
    }
}