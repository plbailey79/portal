package gomoku;

public interface Player
{
    public Position move(Board board);
}
