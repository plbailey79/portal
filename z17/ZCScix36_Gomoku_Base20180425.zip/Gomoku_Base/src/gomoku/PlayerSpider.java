package gomoku;

import java.util.Random;
import java.util.List;

public class PlayerSpider implements Player
{
    private int rng = 3;
    private int min = 3;
    
    public PlayerSpider()
    { }
    
    public PlayerSpider(int rng, int min)
    {
        this.min = min;
    }
    
    public Position move(Board board)
    {
        List<Position> positions = board.getEmptyPositions();
        int k = 0;
        while (positions.size() > 20 && k < positions.size())
        {
            Position position = positions.get(k);
            int row = position.getRow();
            int col = position.getCol();
            int wid = (int)(Math.random() * rng) + min;
            int size = board.size();
            
            if (row < wid || row + wid > size || col < wid || col + wid > size)
            {
                positions.remove(k);
            }
            else
            {
                k++;
            }
        }
        return board.getRandomPosition(positions);
    }
}
