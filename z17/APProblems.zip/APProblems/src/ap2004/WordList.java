package ap2004;

import java.util.ArrayList;

public class WordList 
{
    private ArrayList myList;
    
    /* We added the constructor, the add method, and the toString method,
       so that we can create an adquate testing framework to be called
       from the class Prob1
    */
    
    public WordList()
    {
        myList = new ArrayList();
    }
    
    public boolean add(String w)
    {
        return myList.add(w);
    }
    
    public String toString()
    {
        return myList.toString();
    }
    
    /*  numWordsOfLength(int len) returns an integer
            Initialize a counter k
            For each object o in myList
                Cast o into a String w (short for word)
                if the length of w is len, increment the counter k
            return the counter k
    */
    
    public int numWordsOfLength(int len)
    {
        int k = 0;
        for (Object o : myList)
        {
            String w = (String)o;
            if (w.length() == len) k++;
        }
        return k;
    }
    
    public void removeWordsOfLength(int len)
    {
        int k = 0;
        while (k < myList.size())
        {
            String w = (String)myList.get(k);
            if (w.length() == len)
            {
                myList.remove(k); 
                // Don't increment k if you removed a word.
            }
            else
            {
                k++;
            }
        }
    }
    
    // This didn't work ... Oops.  Why not?
    
    public void removeWordsOfLengthOops(int len)
    {
        for (Object o : myList)
        {
            String w = (String)o;
            if (w.length() == len)
            {
                myList.remove(o);
            }
        }
    }
}
