package ap2004;

public class Prob1 
{
    /*  Problem 1 asks us to construct two methods in a class called WordList.
        In the spirit of the problem, we create WordList as a separate class,
        complete with constructor and toString methods.  This allows us to see
        the requested methods in context.
    */
    
    public static void main(String[] args)
    {
        prob1a();
        prob1b();
    }
            
    public static void prob1a()
    {
        WordList wl = new WordList();
        wl.add("cat");
        wl.add("mouse");
        wl.add("frog");
        wl.add("dog");
        wl.add("dog");
        
        System.out.printf("WordList wl: %s\n", wl);
        
        for (int i = 0; i <= 7; i++)
        {
            System.out.printf("Number of words of length %d = %d\n", 
                    i, 
                    wl.numWordsOfLength(i));
        }
    }
    
    public static void prob1b()
    {
        for (int i = 2; i <= 6; i++)
        {
            WordList wl = new WordList();
            wl.add("cat");
            wl.add("mouse");
            wl.add("frog");
            wl.add("dog");
            wl.add("dog");
            wl.removeWordsOfLength(i);
            System.out.printf("removeWordsOfLength(%d): %s\n", i, wl);
        }
    }
}
