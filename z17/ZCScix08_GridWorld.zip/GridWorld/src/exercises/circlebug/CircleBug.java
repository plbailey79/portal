package exercises.circlebug;

import info.gridworld.actor.Bug;
import java.awt.Color;

public class CircleBug extends Bug
{
    private int steps;
    private int sideLength;

   public CircleBug(int length)
    {
        steps = 0;
        sideLength = length;
    }
   
   public CircleBug(Color color)
   {
       setColor(color);
   }

    public void act()
    {
        super.act(); // Replace this
    }
}
