package exercises.zbug;

import info.gridworld.actor.Bug;
import info.gridworld.grid.Location;

public class ZBug extends Bug
{
    public ZBug(int length)
    {
        // To Do
    }

    public void act()
    {
        super.act(); // Temporary
        // To Do
    }
}
