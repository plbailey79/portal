package exercises.spiralBug;

import info.gridworld.actor.Bug;

public class SpiralBug extends Bug
{
    private int steps;
    private int sideLength;
    private int expand;

    public SpiralBug(int length)
    {
        steps = 0;
	expand = 1;
        sideLength = length;
    }

    public void act()
    {
        if (steps < sideLength && canMove())
        {
            move();
            steps++;
        }
        else
        {
            turn();
            turn();
            sideLength += expand;
            if (sideLength < 1 || sideLength > 20) expand = -expand;
            steps = 0;
        }
    }
}
