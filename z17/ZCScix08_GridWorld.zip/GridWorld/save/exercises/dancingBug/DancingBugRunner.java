package exercises.dancingBug;

import info.gridworld.actor.Actor;
import info.gridworld.actor.ActorWorld;
import info.gridworld.grid.Location;
import info.gridworld.grid.UnboundedGrid;

import java.awt.Color;

public class DancingBugRunner
{
    public static void main(String[] args)
    {
        ActorWorld world = new ActorWorld();
	world.setGrid(new UnboundedGrid<Actor>());
        int[] list = { 1, 0, 2, 0, 3, 0, 4, 0, 3, 0, 2, 0, 1, 0 };
        DancingBug alice = new DancingBug(list);
        alice.setColor(Color.ORANGE);
        world.add(new Location(10,10), alice);
        world.show();
    }
}