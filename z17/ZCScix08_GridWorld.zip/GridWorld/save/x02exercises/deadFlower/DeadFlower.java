import info.gridworld.grid.Grid;
import info.gridworld.grid.Location;
import info.gridworld.actor.Actor;
import info.gridworld.actor.Bug;
import info.gridworld.actor.Flower;
import java.awt.Color;

public class DeadFlower extends Flower
{
    private static final Color DEFAULT_COLOR = Color.PINK;
	private static final int MAXSTEPS = 8;
	private int steps = 0;
	
    public DeadFlower()
    {
        setColor(DEFAULT_COLOR);
    }
	
    public DeadFlower(Color initialColor)
    {
        setColor(initialColor);
    }
	
	public void act()
	{
		super.act();
		if (steps++ > MAXSTEPS)
		{
			removeSelfFromGrid();
		}
	}
}