import info.gridworld.actor.Actor;
import info.gridworld.actor.Flower;
import info.gridworld.actor.Bug;
import info.gridworld.grid.Grid;
import info.gridworld.grid.Location;

public class RetroBug extends Bug
{
	private Location oldLocation;
	private int oldDirection;
	private int steps;
	
	public void act()
	{
		steps++;
		oldLocation = getLocation();
		oldDirection = getDirection();
		super.act();
	}
	
	public void restore()
	{
		if (steps > 0)
		{
			setDirection(oldDirection);
			Grid<Actor> grid = getGrid();
			if (grid == null) return;
			if (!grid.isValid(oldLocation)) return;
			Actor neighbor = grid.get(oldLocation);
			if (neighbor == null || neighbor instanceof Flower)
			{
				//System.out.println("Moving backwards from" + getLocation() + " to " + oldLocation);
				moveTo(oldLocation);
			}
		}
	}
}