package racko;

import java.awt.Color;
import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.SwingConstants;
import javax.swing.BorderFactory;
import javax.swing.border.EtchedBorder;

public class JPanelSolo extends JPanel
{
    private JPanelRack rackPanel;
    private JLabel counterLabel;
    private JLabel discardLabel;
    
    public JPanelSolo()
    {
        setLayout(null);

        rackPanel = new JPanelRack();
        rackPanel.setLocation(5, 10);

        add(rackPanel);

        counterLabel = new JLabel();
        counterLabel.setLocation(50, 435);
        counterLabel.setSize(80, 20);

        discardLabel = new JLabel();
        discardLabel.setForeground(Color.magenta);
        discardLabel.setHorizontalAlignment(SwingConstants.CENTER);
        discardLabel.setLocation(150, 420);
        discardLabel.setSize(30, 30);
        discardLabel.setBorder(BorderFactory.createEtchedBorder(EtchedBorder.LOWERED));

        add(counterLabel);
        add(discardLabel);
        setOpaque(true);
    }

    public void setName(String name)
    {
        rackPanel.setName(name);
    }

    public void setSlot(int k, int v)
    {
        rackPanel.setSlot(k, v);
    }

    public void setLabels(int c, int v)
    {
        if (c >= 1)
        {
            counterLabel.setText("Counter: " + c);
        }
        if (v >= 1 && v <= 60)
        {
            discardLabel.setText("" + v);
        }
    }
}
