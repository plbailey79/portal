package racko;

import java.awt.Dimension;
import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import javax.swing.BoxLayout;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class JFrameMatch extends JFrame
{
    JPanelMatch jPanelMatch;
    JPanelDual jPanelDual;
    
    public JFrameMatch()
    {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setTitle("Racko Match");
        setSize(720, 640);
        setLocationRelativeTo(null);
        
        JPanel content = new JPanel();
        jPanelMatch = new JPanelMatch();
        jPanelDual = new JPanelDual();
        
        jPanelMatch.setPreferredSize(new Dimension(700, 120));
        jPanelDual.setPreferredSize(new Dimension(600, 600));
        
        content.add(jPanelMatch, BorderLayout.PAGE_START);
        content.add(jPanelDual, BorderLayout.PAGE_END);
        
        add(content);
        setVisible(true);
    }

    public void close()
    {
        setVisible(false);
        dispose();
    }

    public void putName(int p, String name)
    {
        jPanelMatch.putName(p, name);
    }

    public void putTotal(int p, int s)
    {
        jPanelMatch.putTotal(p, s);
    }

    public void putScore(int p, int k, int s, boolean w, boolean q)
    {
        jPanelMatch.putScore(p, k, s, w, q);
    }
    
    public void setName(int p, String name)
    {
        jPanelDual.setName(p, name);
    }
    
    public void setSlot(int p, int k, int v)
    {
        jPanelDual.setSlot(p, k, v);
    }

    public void setLabels(int p, int c, int v)
    {
        jPanelDual.setLabels(p, c, v);
    }
}
