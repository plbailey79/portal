package racko;

import javax.swing.JFrame;

public class JFrameDual extends JFrame
{
    JPanelDual jPanelDual;

    public JFrameDual()
    {
        jPanelDual = new JPanelDual();

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setTitle("Racko");
        setSize(600, 500);
        setLocationRelativeTo(null);
        add(jPanelDual);
        setVisible(true);
    }

    public void close()
    {
        // dispatchEvent(new WindowEvent(this, WindowEvent.WINDOW_CLOSING));
        setVisible(false);
        dispose();
    }

    public void setName(int p, String name)
    {
        jPanelDual.setName(p, name);
    }
    
    public void setSlot(int p, int k, int v)
    {
        jPanelDual.setSlot(p, k, v);
    }

    public void setLabels(int p, int c, int v)
    {
        jPanelDual.setLabels(p, c, v);
    }
}
