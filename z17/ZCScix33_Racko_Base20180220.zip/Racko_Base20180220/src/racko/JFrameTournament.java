package racko;

import java.awt.Dimension;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import javax.swing.BoxLayout;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextArea;

public class JFrameTournament extends JFrame
{
    JPanelMatch jPanelMatch;
    JPanelDual jPanelDual;
    JTextArea jTextArea;
    
    public JFrameTournament()
    {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setTitle("Racko Match");
        setSize(960, 640);
        setLocationRelativeTo(null);
        
        JPanel content = new JPanel();
        jPanelMatch = new JPanelMatch();
        jPanelDual = new JPanelDual();
        jTextArea = new JTextArea();
        jTextArea.setFont(new Font("Courier New", Font.BOLD, 12)); 
        jTextArea.setForeground(Color.yellow);
        jTextArea.setBackground(Color.blue);
        jTextArea.setCaretColor(Color.blue);
        
        jPanelMatch.setPreferredSize(new Dimension(700, 120));
        jPanelDual.setPreferredSize(new Dimension(600, 480));
        jTextArea.setPreferredSize(new Dimension(280, 420));
        
        content.add(jPanelMatch, BorderLayout.PAGE_START);
        content.add(jPanelDual, BorderLayout.PAGE_END);
        content.add(jTextArea, BorderLayout.LINE_END);
        
        add(content);
        setVisible(true);
    }

    public void close()
    {
        setVisible(false);
        dispose();
    }

    public void putName(int p, String name)
    {
        jPanelMatch.putName(p, name);
    }

    public void putTotal(int p, int s)
    {
        jPanelMatch.putTotal(p, s);
    }

    public void putScore(int p, int k, int s, boolean w, boolean q)
    {
        jPanelMatch.putScore(p, k, s, w, q);
    }
    
    public void setName(int p, String name)
    {
        jPanelDual.setName(p, name);
    }
    
    public void setSlot(int p, int k, int v)
    {
        jPanelDual.setSlot(p, k, v);
    }

    public void setLabels(int p, int c, int v)
    {
        jPanelDual.setLabels(p, c, v);
    }
    
    public void clear()
    {
        jPanelMatch.clear();
    }
}
