#include <stdio.h>
#include <stdlib.h>

void clone(FILE *ori,FILE *trg)
{ 
	int chr;
	while (1)
	{ 
		chr = fgetc(ori);
		if (chr == EOF) break;
		fputc(chr, trg);
	}
}

void help(void)
{
	printf("Syntax: clone <ori file> <targ file>\n");
}

int main(int argc, char* argv[])
{ 
	FILE *ori, *trg;
	
	if (argc < 3)
	{
		help();
		return 0;
	}
	ori = fopen(argv[1],"rb");
	if (!ori)
	{ 
		printf("Unable to open ori file %s\n",argv[1]);
		return 1;
	}
	trg = fopen(argv[2],"wb");
	if (!trg)
	{
		printf("Unable to open trg file %s\n",argv[2]);
		fclose(ori);
		return 2;
	}
	
	clone(ori,trg);
	fclose(trg);
	fclose(ori);
	return 0;
}
