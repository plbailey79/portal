package graphtheory;

import java.util.List;
import java.util.ArrayList;

public class Program
{
    public static void main(String[] args)
    {
        testGraph();
    }
    public static void testGraph()
    {
        Graph G = new Graph();
        
        G.add(new Edge(1,2));
        G.add(new Edge(1,2));
        
        System.out.println(G.sizeE());
        
        G.add(new Edge(1,3));
        G.add(new Edge(2,3));
        G.add(new Edge(3,4));
        G.add(new Edge(4,5));
        G.add(new Edge(5,1));
        G.add(new Edge(6,7));
        G.add(new Vertex(8));
        
        G.print();   
    }
    
    /* Problem Tester
    public static void testProblems()
    {
        Graph G = new Graph();
        
        G.add(new Edge(1,2));
        G.add(new Edge(1,2));
        
        System.out.println(G.sizeE());
        
        G.add(new Edge(1,3));
        G.add(new Edge(2,3));
        G.add(new Edge(3,4));
        G.add(new Edge(4,5));
        G.add(new Edge(5,1));
        G.add(new Edge(6,7));
        G.add(new Vertex(8));
        
        G.print();   
        
        Vertex v = new Vertex(1);
        
        List<Vertex> neighbors = G.adjacents(v);
        
        System.out.println("Neighbors of " + v + ": " + neighbors);
        
        List<Vertex> associates = G.associates(v);
        
        System.out.println("Associates of " + v + ": " + associates);
        
        System.out.println("Is connected: " + G.isConnected());
        
        List<Graph> components = G.components();
        
        System.out.println("Components: ");
        for (Graph C : components)
        {
            System.out.println(C + " " + C.isConnected() + " " + C.isTree());
        }
        
        System.out.println("Is tree: " + G.isTree());
        
        List<Graph> trees = G.trees();
        
        System.out.println("Trees: ");
        for (Graph T : trees)
        {
            System.out.println(T + " " + T.isTree());
        }
    }
    
    */
    
    /* Walk Tester
    
    public static void testWalk()
    {
        Graph G = new Graph();
        
        G.add(1,2);
        G.add(1,3);
        G.add(2,3);
        G.add(3,4);
        G.add(4,5);
        G.add(5,1);
        G.add(3,6);
        G.add(6,7);
        G.add(7,9);
        G.add(9,2); 
       
        G.print();   
        
        Walk W = new Walk(G);
        
        W.append(1);
        W.append(2);
        W.append(3);
        W.append(1);
        W.append(5);
        W.append(4);
        
        
        System.out.println(W);
        System.out.println("IsTrail: " + W.isTrail());
        System.out.println("IsPath: " + W.isTrail());
        
        W.append(6); // fails
        W.append(4);
        W.append(3);
        W.append(6);
        
        System.out.println(W);
        System.out.println("IsTrail: " + W.isTrail());
        
        System.out.println("Shortest Paths");
        
        for (int i = 1; i < 9; i++)
        {
            for (int j = i + 1; j <= 9; j++)
            {
                Walk P = G.shortestPath(i, j);
                int d = G.distance(i, j);
                System.out.printf("(%d,%d)[%3d] %s\n", i, j, d, "" + P);
                
            }
        } 
        
        System.out.println("Eulerian: " + G.admitsEulerianPath());
    }
    
    */
}
