package graphtheory;

public class Edge
{
    private Vertex v;
    private Vertex w;
    
    public Edge(Vertex v, Vertex w)
    {
        initialize(v.id(), w.id());
    }
    
    public Edge(int a, int b)
    {
        initialize(a, b);
    }
    
    private void initialize(int a, int b)
    {
        if (a > b)
        {
            int t = a;
            a = b;
            b = t;
        }
        if (a <= 0 || b <= a)
        {
            a = 0;
            b = 0;
        }
        
        if (0 < a && a < b)
        {
            this.v = new Vertex(a);
            this.w = new Vertex(b);
        }
    }
    
    public Vertex v()
    {
        return v;
    }
    
    public Vertex w()
    {
        return w;
    }
    
    public boolean involves(Vertex u)
    {
        return (v.equals(u) || w.equals(u));
    }
    
    public Vertex other(Vertex u)
    {
        Vertex t = null;
        if (v.equals(u)) t = w;
        if (w.equals(u)) t = v;
        return t;
    }
    
    public String toString()
    {
        return "{" + v + "," + w + "}";
    }
    
    public boolean equals(Object o)
    {
        boolean b = false;
        if (o instanceof Edge)
        {
            Edge that = (Edge)o;
            b = (this.v.equals(that.v) && this.w.equals(that.w));
        }
        return b;
    }
    
    public int hashCode()
    {
        return v.id() + w.id();
    }
}
