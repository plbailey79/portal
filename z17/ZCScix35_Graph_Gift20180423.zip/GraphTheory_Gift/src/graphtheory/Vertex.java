package graphtheory;

public class Vertex
{
    private int id;
    
    public Vertex(int a)
    {
        if (a < 0) a = 0;
        id = a;
    }
    
    public int id()
    {
        return id;
    }
    
    public String toString()
    {
        return "" + id;
    }
    
    public boolean equals(Object o)
    {
        boolean b = false;
        if (o instanceof Vertex)
        {
            Vertex that = (Vertex)o;
            b = (this.id == that.id);
        }
        return b;
    }
    
    public int hashCode()
    {
        return id;
    }
}
