package gomoku;

import java.util.Random;
import java.util.List;

public class PlayerBug implements Player
{   
    public Position move(Board board)
    {
        List<Position> positions = board.getEmptyPositions();
        int k = 0;
        while (positions.size() > 2 && k < positions.size())
        {
            Position position = positions.get(k);
            int row = position.getRow();
            int col = position.getCol();
            int wid = 4;
            int size = board.size();
            
            if (row < wid || row + wid > size || col < wid || col + wid > size)
            {
                positions.remove(k);
            }
            else
            {
                k++;
            }
        }
        return board.getRandomPosition(positions);
    }
}
