package gomoku;

public interface IFrameGomoku
{
    public void finished(State state);
}
