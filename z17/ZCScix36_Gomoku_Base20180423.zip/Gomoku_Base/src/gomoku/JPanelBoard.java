package gomoku;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Line2D;
import java.awt.geom.Rectangle2D;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.Timer;

public class JPanelBoard extends JPanel
{
    private final int MARGIN = 5;
    private final double PIECE_FRAC = 0.9;
    
    private Player p1;
    private Player p2 = new PlayerSlug();
    private int size = 19;
    private int goal = 5;

    private State state;
    private int delay1 = 32;
    private int delay2 = 128;
    private int delay3 = 1024;
    
    private Timer timer;
    
    public JPanelBoard()
    {
	super();
        
        if (p1 == null || p2 == null)
        {
            attachListener();
        }
        attachTimer();
        
        go();
    } 
    
    public void go()
    {
        timer.stop();
        state = new State(p1, p2, size, goal);
        repaint();
        timer.start();
    }
    
    public void go(Player p1, Player p2, int size, int goal, 
                   int ps, int delay1, int delay2, int delay3)
    {
        timer.stop();
        this.p1 = p1;
        this.p2 = p2;
        this.size = size;
        this.goal = goal;
        this.delay1 = delay1;
        this.delay2 = delay2;
        this.delay3 = delay3;
        state = new State(p1, p2, size, goal, ps);
        repaint();
        timer.start();
    }
    
    public void attachTimer()
    {
        ActionListener actionListener = new ActionListener()
        {
            public void actionPerformed(ActionEvent evt)
            {
                timerFired();
            }
        };
        timer = new Timer(delay1, actionListener);
    }
    
    
    public void attachListener()
    {
	addMouseListener(new JPanelBoard.GomokuListener());
    }
    
    public void timerFired()
    {
        if (state.getWinner() != State.NONE)
        {
            repaint();

            timer.stop();

            JFrame frame = (JFrame)this.getRootPane().getParent();
            frame.revalidate();
            Utilities.delay(delay3);
            ((IFrameGomoku)frame).finished(state);

        }
        if (state.getProgram() != null)
        {
            Player program = state.getProgram();
            Position position = program.move(state.getBoard());
            play(position);
            Utilities.delay(delay2);
        }       
    }
    
    public boolean play(Position position)
    {
        boolean did = false;
        int size = state.getSize();
        
        if (state.getWinner() == State.NONE)
        {
            if (!state.isValid(position) || !state.isEmpty(position))
            {
                position = state.getRandomPosition();
            }
        
            state.playPiece(position);
            repaint();
            did = true;
        }
        return did;
    }
   
    class GomokuListener extends MouseAdapter 
    {
	public void mouseReleased(MouseEvent e) 
	{
            int size = state.getSize();
	    double panelWidth = getWidth();
	    double panelHeight = getHeight();
	    double boardWidth = Math.min(panelWidth, panelHeight) - 2 * MARGIN;
	    double squareWidth = boardWidth / size;
	    double xLeft = (panelWidth - boardWidth) / 2 + MARGIN;
	    double yTop = (panelHeight - boardWidth) / 2 + MARGIN;
	    int col = (int) Math.round((e.getX() - xLeft) / squareWidth - 0.5);
	    int row = (int) Math.round((e.getY() - yTop) / squareWidth - 0.5);
            if (state.getProgram() == null)
            {
                play(new Position(row, col));
            }
	}    
    }
    
    public void paintComponent(Graphics g) 
    {
        int size = state.getSize();
	Graphics2D g2d = (Graphics2D) g;
	g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
			    RenderingHints.VALUE_ANTIALIAS_ON);
	
	double panelWidth = getWidth();
	double panelHeight = getHeight();

	g2d.setColor(new Color(0.925f, 0.670f, 0.34f)); // light wood
	g2d.fill(new Rectangle2D.Double(0, 0, panelWidth, panelHeight));
        
	double boardWidth = Math.min(panelWidth, panelHeight) - 2 * MARGIN;
	double squareWidth = boardWidth / size;
	double gridWidth = (size - 1) * squareWidth;
	double pieceDiameter = PIECE_FRAC * squareWidth;
	boardWidth -= pieceDiameter;
	double xLeft = (panelWidth - boardWidth) / 2 + MARGIN;
	double yTop = (panelHeight - boardWidth) / 2 + MARGIN;
        
        g2d.setColor(Color.BLUE);
        g2d.drawString("Points: " + state.getPoints(), 32, 16);
        
        drawStone(g2d, 16, 64, pieceDiameter, 2, makeColor(state.getStarter()));
        drawStone(g2d, 16, 128, pieceDiameter, 2, makeColor(state.getWinner()));

	g2d.setColor(Color.BLACK);
	for (int i = 0; i < size; i++)
        {
	    double offset = i * squareWidth;
	    g2d.draw(new Line2D.Double(
                xLeft, 
                yTop + offset, 
		xLeft + gridWidth, 
                yTop + offset));
	    g2d.draw(new Line2D.Double(
                xLeft + offset, 
                yTop,
		xLeft + offset, 
                yTop + gridWidth));
	}
	
	for (int row = 0; row < size; row++) 
        {
	    for (int col = 0; col < size; col++) 
            {
		int piece = state.getPiece(row, col);
		if (piece != State.NONE) 
                {
		    double xCenter = xLeft + col * squareWidth;
		    double yCenter = yTop + row * squareWidth;
                    int factor = 1;
		    Color color = 
                        (piece == State.BLACK) ? 
                        Color.BLACK : 
                        Color.WHITE;
                    drawStone(g2d, xCenter, yCenter, pieceDiameter, factor, color);
		}
	    }
        }
        
        if (state.getWinner() != State.NONE)
        {
            for (Position position : state.getChain())
            {
                int row = position.getRow();
                int col = position.getCol();
                
                double xCenter = xLeft + col * squareWidth;
                double yCenter = yTop + row * squareWidth;
                int factor = 2;
                Color color = Color.GRAY;
                
                drawStone(g2d, xCenter, yCenter, pieceDiameter, factor, color);
            }
        }
    }
    
    public void drawStone(Graphics2D g2d, double x, double y, double d, double f, Color c)
    {
        d = d / f;
        g2d.setColor(c);
        Ellipse2D.Double circle = new Ellipse2D.Double(
            x - d / 2,
            y - d / 2,
            d,
            d);
        g2d.fill(circle);
        g2d.setColor(Color.BLACK);
        g2d.draw(circle);
    }
    
    public Color makeColor(int player)
    {
        Color color = Color.PINK;
        switch (player)
        {
            case State.NONE : color = Color.ORANGE; break;
            case State.BLACK : color = Color.BLACK; break;
            case State.WHITE : color = Color.WHITE; break;
            case State.TIED : color = Color.GRAY; break;
        }
        return color;
    }
}
