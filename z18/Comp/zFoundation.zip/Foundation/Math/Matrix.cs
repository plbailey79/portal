﻿using System;
using System.Collections.Generic;

namespace Math
{
    public class Matrix
    {
        private Element[,] arr;

        public int Rows { get { return arr.GetLength(0); } }
        public int Cols { get { return arr.GetLength(1); } }
        public bool IsSquare { get { return Rows == Cols; } }

        public Matrix()
        {
            arr = new Element[1, 1];
            arr[0, 0] = new Element();
        }

        public Matrix(params Vector[] vectors)
        {
            arr = new Element[vectors[0].Length, vectors.Length];

            for (int j = 0; j < Cols; j++)
            {
                for (int i = 0; i < Rows; i++)
                {
                    if (i < vectors[j].Length) arr[i, j] = vectors[j][i];
                }
            }
        }

        public Matrix(Element[,] arx)
        {
            Load(arx);
        }

        public Matrix(Matrix M)
        {
            Load(M.arr);
        }

        private void Load(Element[,] arx)
        {
            int m = arx.GetLength(0);
            int n = arx.GetLength(1);
            arr = new Element[m, n];
            for (int i = 0; i < m; i++)
            {
                for (int j = 0; j < n; j++)
                {
                    arr[i, j] = new Element(arx[i, j]);
                }
            }
        }

        public override string ToString()
        {
            string s = "[";

            for (int i = 0; i < Rows; i++)
            {
                if (i > 0) s += "|";
                for (int j = 0; j < Cols; j++)
                {
                    if (j > 0) s += ",";
                    s += arr[i, j];
                }
            }
            s += "]";
            return s;
        }

        public Matrix Comatrix(int i, int j)
        {
            Matrix M = new Matrix();
            if (Rows > 1 && Cols > 1 && i >= 0 && i < Rows && j >= 0 && j < Cols)
            {
                Element[,] arx = new Element[Rows - 1, Cols - 1];
                for (int x = 0; x < Rows - 1; x++)
                {
                    for (int y = 0; y < Cols - 1; y++)
                    {
                        arx[x, y] = new Element(arr[x >= i ? x+1 : x, y >= j ? y+1 : y]);
                    }
                }
                M = new Matrix(arx);
            }
            return M;
        }

        public Element Determinant()
        {
            if (!IsSquare) return new Element();

            if (Rows == 1) return arr[0, 0];

            Element d = new Element();
            for (int j = 0; j < Cols; j++)
            {
                Matrix C = Comatrix(0, j);
                Element e = arr[0, j];
                Element c = C.Determinant();
                if (j % 2 == 1) e = -e;
                d += e * c;
            }
            return d;
        }

        public Matrix Adjugate()
        {
            if (!IsSquare) return new Matrix();
            Element[,] arx = new Element[Rows, Cols];
            for (int i = 0; i < Rows; i++)
            {
                for (int j = 0; j < Cols; j++)
                {
                    Matrix C = Comatrix(i, j);
                    Element d = C.Determinant();
                    if ((i + j) % 2 == 1) d = -d;
                    arx[j, i] = d;
                }
            }
            return new Matrix(arx);
        }

        public Matrix Inverse()
        {
            Matrix A = Adjugate();
            Element d = Determinant();
            return ~d * A;
        }

        public Vector RowToVector(int i)
        {
            Element[] a = new Element[Cols];
            for (int j = 0; j < Cols; j++)
            {
                a[j] = arr[i, j];
            }
            return new Vector(a);
        }

        public Element Det2D()
        {
            Element e = new Element();
            if (Rows == 2 && Cols == 2)
            {
                return arr[0, 0] * arr[1, 1] - arr[0, 1] * arr[1, 0];
            }
            return e;
        }

        public Matrix Inv2D()
        {
            Matrix A = new Matrix();
            if (Rows == 2 && Cols == 2)
            {
                Element d = Det2D();
                if (d.IsInvertible)
                {
                    Element[,] arx = new Element[2, 2];
                    Element v = ~d;
                    arx[0, 0] = v * arr[1, 1];
                    arx[1, 1] = v * arr[0, 0];
                    arx[0, 1] = - v * arr[0, 1];
                    arx[1, 0] = - v * arr[1, 0];
                    A = new Matrix(arx);
                }
            }
            return A;
        }

        public static Matrix operator *(Matrix A, Matrix B)
        {
            if (A.Cols != B.Rows) return new Matrix();
            Element[,] arx = new Element[A.Rows, B.Cols];
            for (int i = 0; i < A.Rows; i++)
            {
                for (int k = 0; k < B.Cols; k++)
                {
                    Element c = new Element();
                    for (int j = 0; j < A.Cols; j++)
                    {
                        c += A.arr[i, j] * B.arr[j, k];
                    }
                    arx[i, k] = c;
                }
            }
            return new Matrix(arx);
        }

        public static Vector operator *(Matrix A, Vector v)
        {
            if (A.Cols != v.Length) return new Vector();
            Element[] a = new Element[A.Rows];
            for (int i = 0; i < A.Rows; i++)
            {
                Vector w = A.RowToVector(i);
                a[i] = v * w;
            }
            return new Vector(a);
        }

        public static Matrix operator *(Element a, Matrix A)
        {
            Element[,] arx = new Element[A.Rows, A.Cols];
            for (int i = 0; i < A.Rows; i++)
            {
                for (int j = 0; j < A.Cols; j++)
                {
                    arx[i, j] = a * A.arr[i, j];
                }
            }
            return new Matrix(arx);
        }
    }
}
