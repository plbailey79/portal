﻿using System;

namespace Math
{
    public class Vector
    {
        private Element[] arr;

        public int Length
        {
            get { return arr.Length; }
        }

        public Element this[int i]
        {
            get
            {
                return arr[i];
            }
        }

        public Vector(params Element[] arr)
        {
            this.arr = new Element[arr.Length];
            for (int i = 0; i < arr.Length; i++)
            {
                this.arr[i] = new Element(arr[i]);
            }
        }

        public override string ToString()
        {
            string s = "[";
            for (int i = 0; i < arr.Length; i++)
            {
                if (i > 0) s += ",";
                s += arr[i];
            }
            s += "]";
            return s;
        }

        public static Element operator *(Vector v, Vector w)
        {
            Element e = new Element();
            if (v.Length > 0 && v.Length == w.Length)
            {
                e = new Element(0, v[0].N);
                for (int i = 0; i < v.Length; i++)
                {
                    e = e + v[i] * w[i];
                }
            }
            return e;
        }
    }
}
