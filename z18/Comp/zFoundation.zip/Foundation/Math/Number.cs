﻿using System;
using System.Collections.Generic;

namespace Math
{
    public static class Number
    {
        public static int Mod(int a, int n)
        {
            if (n == 0) return a;
            if (n < 0) n = -n;
            a = a % n;
            if (a < 0) a = a + n;
            return a;
        }

        public static int Gcd(int m, int n)
        {
            if (m < 0) m = -m;
            if (n < 0) n = -n;
            if (m == 0) return n;
            if (n == 0) return m;
            int r = n % m;
            if (r > 0) return Gcd(r, m);
            return m;
        }

        public static int Euc(int m, int n, ref int x, ref int y)
        {
            if (m == 0) return 0;
            if (n == 0) return 0;
            if (m < 0) m = -m;
            if (n < 0) n = -n;
            int q = n / m;
            int r = n % m;
            int d = m;
            x = 0;
            y = 1;
            Console.WriteLine("{0} = {1}({2}) + {3}", n, m, q, r);
            if (r > 0) d = Euc(r, m, ref x, ref y);
            int t = y;
            y = x;
            x = t - q * x;
            Console.WriteLine("{0}({1}) + {2}({3}) = {4}", m, x, n, y, d);
            return d;
        }

        public static int Inv(int m, int n)
        {
            if (n == 0)
            {
                if (m == 1) return 1;
                if (m == -1) return -1;
                return 0;
            }
            int x = 0;
            int y = 0;
            int d = Euc(m, n, ref x, ref y);
            if (d > 1)
            {
                x = 0;
            }
            if (x < 0) x = n - (-x % n);
            return x % n;
        }

        public static List<int> Primes(int n)
        {
            List<int> primes = new List<int>();

            int k = 2;
            while (n > 1)
            {
                if (n % k == 0)
                {
                    primes.Add(k);
                }
                while (n % k == 0)
                {
                    n /= k;
                }
                k++;
            }
            return primes;
        }

        public static List<int> Factors(int n)
        {
            List<int> primes = new List<int>();

            int k = 2;
            while (n > 1)
            {
                while (n % k == 0)
                {
                    primes.Add(k);
                    n /= k;
                }
                k++;
            }
            return primes;
        }

        public static int Phi(int n)
        {
            List<int> primes = Primes(n);
            foreach (int p in primes)
            {
                n /= p;
            }
            foreach (int p in primes)
            {
                n *= (p - 1);
            }
            return n;
        }

        public static int Pow(int a, int e)
        {
            int p = 1;
            while (e > 0)
            {
                if ((e & 1) > 0) p *= a;
                a *= a;
                e >>= 1;
            }
            return p;
        }

        public static int Pow(int a, int e, int n) // Modular Exp
        {
            int p = 1;
            int h = Phi(n);

            e = e % h;

            while (e > 0)
            {
                if ((e & 1) > 0)
                {
                    p *= a;
                    p %= n;
                }
                a *= a;
                e >>= 1;
            }
            return p;
        }
    }
}

