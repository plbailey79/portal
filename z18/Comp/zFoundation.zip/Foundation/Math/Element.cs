﻿using System;
using System.Collections.Generic;

namespace Math
{
    public class Element
    {
        private int v = 0;
        private int n = 0;

        public int V { get { return v; } }
        public int N { get { return n; } }

        public bool IsInvertible { get { return Number.Gcd(v, n) == 1; } }

        public Element()
        { }

        public Element(int v, int n)
        {
            if (n > 0)
            {
                if (v < 0) v = n - (-v % n);
                this.v = v % n;
                this.n = n;
            }
            else if (n == 0)
            {
                this.v = v;
                this.n = 0;
            }
        }

        public Element(Element that)
        {
            this.v = that.v;
            this.n = that.n;
        }

        public override string ToString()
        {
            return v.ToString();
        }

        public static Element operator -(Element a)
        {
            return new Element(-a.v, a.n);
        }

        public static Element operator ~(Element a)
        {
            return new Element(Number.Inv(a.v, a.n), a.n);
        }

        public static Element operator +(Element a, Element b)
        {
            int n = Number.Gcd(a.n, b.n);
            return new Element(a.v + b.v, n);
        }

        public static Element operator -(Element a, Element b)
        {
            int n = Number.Gcd(a.n, b.n);
            return new Element(a.v - b.v, n);
        }

        public static Element operator *(Element a, Element b)
        {
            int n = Number.Gcd(a.n, b.n);
            return new Element(a.v * b.v, n);
        }
    }
}
