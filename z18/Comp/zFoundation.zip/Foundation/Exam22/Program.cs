﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exam22
{
    class Program
    {
        static void Main(string[] args)
        {
            //ProbHill.Go();
            //ProbCRT.Go();
            ProbRSA.Go();
            //ProbPoly.Go();
            //ProbPrimes.Go();
            //ProbSieve.Go();
            //ProbPyramid.Go();

        }
    }
}
