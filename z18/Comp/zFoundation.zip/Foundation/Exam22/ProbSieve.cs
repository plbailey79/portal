﻿using System;
using System.Collections.Generic;
using System.Numerics;
using Algebra;

namespace Exam22
{
    class ProbSieve
    {
        public static void Go()
        {
            int n = 100000000;
            Sieve sieve = new Sieve(n);
            List<int> primes = sieve.Primes;

            Console.WriteLine("Number of primes less than {0} is {1}", n, primes.Count);

            ShowCount(primes, 1000, 3);
            ShowCount(primes, 5000000, 1);
            ShowCount(primes, 5000000, 3);
            ShowCount(primes, 5000000, 7);
            ShowCount(primes, 5000000, 9);


            ShowProd(primes, 8);
            ShowProd(primes, 5000000);
            ShowProd2(primes, 5000000);

            ShowDebt();
        }

        public static void ShowCount(List<int> primes, int n, int d)
        {
            int c = 0;
            foreach (int p in primes)
            {
                if (p >= n) break;
                if (p % 10 == d) c++;
            }
            Console.WriteLine("Count n: {0}  d: {1}  c: {2}", n, d, c);
        }

        public static void ShowProd(List<int> primes, int k)
        {
            BigInteger t = 1;
            int i = 0;
            foreach (int p in primes)
            {

                if (++i > k) break;
                t = (t * ((BigInteger)p % 10000)) % 10000;
            }
            Console.WriteLine("Prod  k: {0}  t: {1}", k, t);
        }

        public static void ShowProd2(List<int> primes, int k)
        {
            BigInteger t = 1;
            foreach (int p in primes)
            {
                if (p >= k) break;
                t = (t * (p % 10000)) % 10000;
            }
            Console.WriteLine("Prod  k: {0}  t: {1}", k, t);
        }

        public static void ShowDebt()
        {
            //double debt = 21931330000000;
            double debt = 21933000000000;
            double umass = 11.34;
            double uthik = 2.15;
            double mthik = 384400;
            Console.WriteLine("Total Height: {0} kilometers", 2 * debt * uthik / 1000000);
            Console.WriteLine("Total Mass:   {0} kilograms", 2 * debt * umass / 1000);
            Console.WriteLine("Orbits: {0}", (2 * debt * uthik / 1000000) / mthik);
        }
    }
}
