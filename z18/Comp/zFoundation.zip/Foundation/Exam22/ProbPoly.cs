﻿using System;
using Algebra;

namespace Exam22
{
    class ProbPoly
    {
        public static void Go()
        {
            Table tf = new Table();
            tf.Add(new Point(0, -10));
            tf.Add(new Point(1, 0));
            tf.Add(new Point(2, 126));
            tf.Add(new Point(3, 704));
            tf.Add(new Point(5, 6480));
            tf.Add(new Point(7, 29376));

            Table tg = new Table();
            tg.Add(new Point(0, -12));
            tg.Add(new Point(1, 0));
            tg.Add(new Point(2, 120));
            tg.Add(new Point(3, 660));
            tg.Add(new Point(5, 6048));
            tg.Add(new Point(7, 27540));

            Polynomial f = tf.LaGrange();
            Polynomial g = tg.LaGrange();
            Polynomial d = Polynomial.Gcd(f, g);

            Console.WriteLine("f: {0}", f);
            Console.WriteLine("g: {0}", g);
            Console.WriteLine("d: {0}", d);

            int v = 0;
            v = 0; Console.WriteLine("f({0}) = {1}", v, f.Value(v));
            v = 1; Console.WriteLine("f({0}) = {1}", v, f.Value(v));
            v = 2; Console.WriteLine("f({0}) = {1}", v, f.Value(v));
            v = 3; Console.WriteLine("f({0}) = {1}", v, f.Value(v));
            v = 5; Console.WriteLine("f({0}) = {1}", v, f.Value(v));
            v = 7; Console.WriteLine("f({0}) = {1}", v, f.Value(v));

            v = 0; Console.WriteLine("g({0}) = {1}", v, g.Value(v));
            v = 1; Console.WriteLine("f({0}) = {1}", v, g.Value(v));
            v = 2; Console.WriteLine("g({0}) = {1}", v, g.Value(v));
            v = 3; Console.WriteLine("g({0}) = {1}", v, g.Value(v));
            v = 5; Console.WriteLine("g({0}) = {1}", v, g.Value(v));
            v = 7; Console.WriteLine("g({0}) = {1}", v, g.Value(v));
        }

        public static void Build()
        {
            Polynomial f1 = new Polynomial(5, 1);
            Polynomial f3 = new Polynomial(1, 1);
            Polynomial f2 = new Polynomial(-1, 1);
            Polynomial f4 = new Polynomial(2, 0, 1);
            Polynomial f = f1 * f2 * f3 * f4;

            Polynomial g1 = new Polynomial(2, 1);
            Polynomial g4 = new Polynomial(3, 1);
            Polynomial g2 = new Polynomial(-1, 1);
            Polynomial g3 = new Polynomial(2, 0, 1);
            Polynomial g = g1 * g2 * g3 * g4;

            Console.WriteLine("f: {0}", f);
            Console.WriteLine("g: {0}", g);
            Console.WriteLine("gcd(f,g): {0}", Polynomial.Gcd(f, g));

            int v = 0;
            v = 0; Console.WriteLine("f({0}) = {1}", v, f.Value(v));
            v = 1; Console.WriteLine("f({0}) = {1}", v, f.Value(v));
            v = 2; Console.WriteLine("f({0}) = {1}", v, f.Value(v));
            v = 3; Console.WriteLine("f({0}) = {1}", v, f.Value(v));
            v = 5; Console.WriteLine("f({0}) = {1}", v, f.Value(v));
            v = 7; Console.WriteLine("f({0}) = {1}", v, f.Value(v));

            v = 0; Console.WriteLine("g({0}) = {1}", v, g.Value(v));
            v = 1; Console.WriteLine("f({0}) = {1}", v, g.Value(v));
            v = 2; Console.WriteLine("g({0}) = {1}", v, g.Value(v));
            v = 3; Console.WriteLine("g({0}) = {1}", v, g.Value(v));
            v = 5; Console.WriteLine("g({0}) = {1}", v, g.Value(v));
            v = 7; Console.WriteLine("g({0}) = {1}", v, g.Value(v));
        }
    }
}
