﻿using System;
using Math;

namespace Exam22
{
    public class Hill
    {
        public static string Encrypt(string s, Matrix M)
        {
            if (!M.IsSquare) return "";
            string r = "";
            int n = M.Rows;
            int k = 0;
            s = Util.Strip(s);
            while (k < s.Length)
            {
                Element[] e = new Element[n];
                int i = 0;
                while (i < n)
                {
                    int b = 0;
                    if (k < s.Length)
                    {
                        b = Util.ctoi(s[k++]);
 
                    }
                    e[i++] = new Element(b, 27);
                }
                Vector v = new Vector(e);
                Vector w = M * v;
                for (i = 0; i < n; i++)
                {
                    r += Util.itoc(w[i].V);
                }
            }
            return r;
        }

        public static Matrix InvKey(Matrix M)
        {
            return M.Inverse();
        }
    }
}
