﻿using System;
using System.Collections.Generic;
using System.Numerics;
using Algebra;

namespace Exam22
{
    class ProbPrimes
    {
        public static void Go()
        {
            Go1();
            //Go2();
        }

        public static void Go1()
        {
            List<int> primes = GetPrimes(100000);

            Console.WriteLine("100th prime: {0}", primes[99]);
            Console.WriteLine("500th prime: {0}", primes[499]);

            ShowCount(primes, 1000, 3);
            ShowCount(primes, 10000, 1);
            ShowCount(primes, 10000, 3);
            ShowCount(primes, 10000, 7);
            ShowCount(primes, 10000, 9);

            ShowSum(primes, 100);
            ShowSum(primes, 10000);
            ShowProd(primes, 8);
            ShowProd(primes, 20);
        }

        public static void Go2()
        {
            Sieve sieve = new Sieve(100000);
            List<int> primes = sieve.Primes;

            Console.WriteLine("100th prime: {0}", primes[99]);
            Console.WriteLine("500th prime: {0}", primes[499]);

            ShowCount(primes, 1000, 3);
            ShowCount(primes, 10000, 1);
            ShowCount(primes, 10000, 3);
            ShowCount(primes, 10000, 7);
            ShowCount(primes, 10000, 9);

            ShowSum(primes, 100);
            ShowSum(primes, 10000);
            ShowProd(primes, 8);
            ShowProd(primes, 20);
        }

        public static void ShowCount(List<int> primes, int n, int d)
        {
            int c = 0;
            foreach (int p in primes)
            {
                if (p >= n) break;
                if (p % 10 == d) c++;
            }
            Console.WriteLine("Count  n: {0}  d: {1}  c: {2}", n, d, c);
        }

        public static void ShowSum(List<int> primes, int n)
        {
            BigInteger t = 0;
            foreach (int p in primes)
            {
                if (p >= n) break;
                t += p;
            }
            Console.WriteLine("Sum  n: {0}  t: {1}", n, t);
        }

        public static void ShowProd(List<int> primes, int k)
        {
            BigInteger t = 1;
            int i = 0;
            foreach (int p in primes)
            {
                if (++i > k) break;
                t*= p;
            }
            Console.WriteLine("Prod  k: {0}  t: {1}", k, t);
        }

        public static List<int> GetPrimes(int n)
        {
            List<int> primes = new List<int>();
            int k = 1;
            while (++k < n)
            {
                bool isPrime = true;
                foreach (int p in primes)
                {
                    if (k % p == 0)
                    {
                        isPrime = false;
                        break;
                    }
                }
                if (isPrime)
                {
                    primes.Add(k);
                }
            }
            return primes;
        }
    }
}
