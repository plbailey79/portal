﻿using System;
using System.Text;

namespace Exam22
{
    public class Util
    {
        public static char itoc(int i)
        {
            char c = ' ';
            if (i >= 1 && i <= 26) c = (char)(i + '@');
            return c;
        }

        public static int ctoi(char c)
        {
            int i = -1;
            if (Char.IsLetter(c)) i = (int)(Char.ToUpper(c)) - 'A' + 1;
            else if (c == ' ') i = 0;
            return i;
        }

        public static string Strip(string s)
        {
            StringBuilder sb = new StringBuilder();
            int k = 0;
            int j = 0;
            while (k < s.Length)
            {
                char c = Char.ToUpper(s[k++]);
                int i = ctoi(c);
                // if (i == 0 && i == j) continue;
                if (i >= 0) j = i;
                if (i >= 0) sb.Append(itoc(i));
            }
            return sb.ToString();
        }

        public static string Clean(string s)
        {
            StringBuilder sb = new StringBuilder();
            int k = 0;
            int j = 0;
            while (k < s.Length)
            {
                char c = Char.ToUpper(s[k++]);
                int i = ctoi(c);
                if (i == 0 && i == j) continue;
                if (i >= 0) j = i;
                if (i >= 0) sb.Append(itoc(i));
            }
            return sb.ToString();
        }
    }
}