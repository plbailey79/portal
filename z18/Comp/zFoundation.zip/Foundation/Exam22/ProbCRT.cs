﻿using System;
using System.Numerics;
using Algebra;

namespace Exam22
{
    class ProbCRT
    {
        public static void Go()
        {
            BigInteger m = 224699;
            BigInteger n = 746743;
            BigInteger z = m * n;
            BigInteger x = 0;
            BigInteger y = 0;
            BigInteger d = Number.Euc(m, n, ref x, ref y);
            BigInteger a = 28372;
            BigInteger b = 77362;
            BigInteger c = Number.Crt(a, b, m, n);

            Console.WriteLine("z: {0}", z);
            Console.WriteLine("d: {0}", d);
            Console.WriteLine("x: {0}", x);
            Console.WriteLine("y: {0}", y);
            Console.WriteLine("c: {0}", c);
        }

        public static void Test()
        {
            Build();
        }

        public static void Build()
        {
            BigInteger m = 224699;
            BigInteger n = 746743;
            BigInteger p = m * n;
            BigInteger d = Number.Gcd(m, n);

            BigInteger a = 28372;
            BigInteger b = 77362;

            BigInteger c = Number.Crt(a, b, m, n);
            Console.WriteLine("m: {0}", m);
            Console.WriteLine("n: {0}", n);
            Console.WriteLine("p: {0}", p);
            Console.WriteLine("d: {0}", d);
            Console.WriteLine("a: {0}", a);
            Console.WriteLine("b: {0}", b);
            Console.WriteLine("c: {0}", c);
        }
    }
}
