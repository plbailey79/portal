﻿using System;
using System.Numerics;
using Algebra;
using Rivest;

namespace Exam22
{
    class ProbRSA
    {
        public static void Test()
        {
            Go();
        }

        public static void Go()
        {
            BigInteger n = Number.Parse("3999619760794527582571");
            BigInteger e = Number.Parse("1345678987654321");
            string s = "CFUFDYYYJPQJCERSQIRKKCO L TT NG WPCAFQAQMWIGJPWDE CNNMRS UIHA";

            BigInteger p = Factor.Rho(n);
            BigInteger q = n / p;
            BigInteger h = (p - 1) * (q - 1);
            BigInteger d = Number.Inv(e, h);

            string t = Message.EncryptString(s, n, d);
            Console.WriteLine("n: {0}", n);
            Console.WriteLine("e: {0}", e);
            Console.WriteLine("p: {0}", p);
            Console.WriteLine("q: {0}", q);
            Console.WriteLine("h: {0}", h);
            Console.WriteLine("d: {0}", d);
            Console.WriteLine("s: {0}", s);
            Console.WriteLine("t: {0}", t);
        }

        public static void Build()
        {
            BigInteger p = Number.Parse("50685770167");
            BigInteger q = Number.Parse("78910111213");
            BigInteger n = p * q;
            BigInteger e = Number.Parse("1345678987654321");

            string t = "THE MORE WE KNOW THE LESS WE BELIEVE TO BE TRUE";

            TestEncrypt(p, q, e, t);
        }
        
        public static void TestEncrypt(BigInteger p, BigInteger q, BigInteger e, string s)
        {
            BigInteger n = p * q;
            BigInteger h = (p - 1) * (q - 1);
            BigInteger d = Number.Inv(e, h);

            string t = Message.EncryptString(s, n, e);
            string u = Message.EncryptString(t, n, d);

            Console.WriteLine("TestEncrypt");

            Console.WriteLine("p: {0}", p);
            Console.WriteLine("q: {0}", q);
            Console.WriteLine("n: {0}", n);
            Console.WriteLine("h: {0}", h);
            Console.WriteLine("e: {0}", e);
            Console.WriteLine("d: {0}", d);
            Console.WriteLine("e * d = {0}", (e * d) % h);
            Console.WriteLine("s: {0}", s);
            Console.WriteLine("t: {0}", t);
            Console.WriteLine("u: {0}", u);
        }

        public static string Decrypt(BigInteger n, BigInteger e, string s)
        {
            BigInteger p = Factor.Rho(n);
            BigInteger q = n / p;
            BigInteger h = (p - 1) * (q - 1);
            BigInteger d = Number.Inv(e, h);
            string t = Message.EncryptString(s, n, d);
            Console.WriteLine("p: {0}", p);
            Console.WriteLine("q: {0}", q);
            Console.WriteLine("n: {0}", n);
            Console.WriteLine("h: {0}", h);
            Console.WriteLine("e: {0}", e);
            Console.WriteLine("d: {0}", d);
            Console.WriteLine("t: {0}", t);
            return t;
        }
    }
}
