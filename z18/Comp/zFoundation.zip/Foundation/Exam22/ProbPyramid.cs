﻿using System;
using System.Numerics;

namespace Exam22
{
    class ProbPyramid
    {
        private static int sze;
        private static int[,] arr;

        public static void Go()
        {
            PartA(5);
            PartB(10);
            PartB(100);
            PartB(1000);
            PartB(10000);
        }

        public static void PartA(int n)
        {
            Generate(n);
            
            for (int i = 0; i < n; i++)
            {
                for (int j = 0; j <= i; j++)
                {
                    if (j > 0) Console.Write(" ");
                    Console.Write("{0, 2}", arr[i, j]);
                }
                Console.WriteLine();
            }
        }

        public static void PartB(int n)
        {
            Generate(n);

            for (int i = sze - 1; i >= 0; i--)
            {
                Sum(i);
            }
            int v = arr[0, 0];
            Console.WriteLine("n: {0}  v: {1}", n, v);
        }

        public static int Val(int i, int j)
        {
            int v = 0;
            if (i < sze && j <= i)
            {
                v = arr[i, j];
            }
            return v;
        }

        public static void Sum(int i)
        {
            for (int j = 0; j <= i; j++)
            {
                int v = 0, w = 0, x = 0;

                if (i + 1 < sze)
                {
                    w = Val(i + 1, j);
                    x = Val(i + 1, j + 1);
                    if (w < x) w = x;
                }
                v = Val(i, j) + w;
                arr[i, j] = v;
                //Console.Write("{0} ", v);
            }
            //Console.WriteLine();
        }

        public static void Generate(int n)
        {
            arr = new int[n, n];
            sze = n;
            for (int i = 0; i < n; i++)
            {
                for (int j = 0; j <= i; j++)
                {
                    arr[i, j] = Entry(i, j);
                }
            }
        }

        public static int Entry(BigInteger i, BigInteger j)
        {
            BigInteger k = 3 * i + 5 * j + i * j + 1;
            return (int)(((k * k * k) % 90) + 10);
        }
    }
}
