﻿using System;
using System.IO;
using Math;

namespace Exam22
{
    class ProbHill
    {
        public static void Go()
        {
            Matrix A = Get();
            Element e = A.Determinant();
            Matrix B = A.Inverse();
            string s = "QoGZMYDOHBAQPZWFKBMD";
            string t = Hill.Encrypt(s, B);

            Console.WriteLine("Prob 1a: {0}", e);
            Console.WriteLine("Prob 1b: {0}", B);
            Console.WriteLine("Prob 1c: {0}", t);

        }

        public static void Test()
        {
            Matrix A = Get();
            Matrix B = A.Inverse();
            Matrix C = A * B;
            Element e = A.Determinant();

            Console.WriteLine(A);
            Console.WriteLine(e);
            Console.WriteLine(B);
            Console.WriteLine(C);

            Make();
        }

        public static void Make()
        {
            Matrix A = Get();
            Matrix B = A.Inverse();
            Element d = A.Determinant();

            Console.WriteLine(d);
            Console.WriteLine(B);

            string s = "PLAY IT AGAIN SAM";
            string t = Hill.Encrypt(s, A);
            string u = Hill.Encrypt(t, B);
            Console.WriteLine(s);
            Console.WriteLine(t);
            Console.WriteLine(u);
            File.WriteAllText(@"C:\Text\Trap.txt", t);
        }

        private static Matrix Get()
        {
            Element[,] arx = new Element[4, 4];
            arx[0, 0] = new Element(5, 27);
            arx[0, 1] = new Element(13, 27);
            arx[0, 2] = new Element(11, 27);
            arx[0, 3] = new Element(7, 27);

            arx[1, 0] = new Element(23, 27);
            arx[1, 1] = new Element(19, 27);
            arx[1, 2] = new Element(17, 27);
            arx[1, 3] = new Element(2, 27);

            arx[2, 0] = new Element(1, 27);
            arx[2, 1] = new Element(19, 27);
            arx[2, 2] = new Element(20, 27);
            arx[2, 3] = new Element(7, 27);

            arx[3, 0] = new Element(19, 27);
            arx[3, 1] = new Element(25, 27);
            arx[3, 2] = new Element(3, 27);
            arx[3, 3] = new Element(7, 27);

            return new Matrix(arx);
        }
    }
}
