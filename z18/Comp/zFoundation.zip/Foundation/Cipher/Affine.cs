﻿using System;
using System.Collections.Generic;
using System.Text;

using Math;

namespace Cipher
{
    public class Affine
    {
        public static int Alpha { get { return Util.Alpha;  } }

        public static string Encrypt(string s, int a, int b)
        {
            StringBuilder sb = new StringBuilder();
            FixKey(ref a, ref b);
            s = Util.Strip(s);
            foreach (char c in s)
            {
                sb.Append(Util.itoc((Util.ctoi(c) * a + b) % Alpha));
            }
            return sb.ToString();
        }

        public static void FixKey(ref int a, ref int b)
        {
            a = Number.Mod(a, Alpha);
            b = Number.Mod(b, Alpha);
            if (Number.Gcd(a, Alpha) != 1) a = 1;
        }

        public static void InvKey(ref int a, ref int b)
        {
            int c = Number.Inv(a, Alpha);
            int d = Number.Mod(-b * c, Alpha);
            a = c;
            b = d;
        }

        public static void GuessKey(string s, out int a, out int b)
        {
            double e = 1;
            a = 0;
            b = 0;
            for (int x = 1; x < Alpha; x++)
            {
                for (int y = 0; y < Alpha; y++)
                {
                    string u = Affine.Encrypt(s, x, y);
                    double[] f = Util.Frequency(u);
                    double d = Util.Distance(Util.Freq, f);
                    if (d < e)
                    {
                        e = d;
                        a = x;
                        b = y;
                    }
                }
            }
        }
    }
}
