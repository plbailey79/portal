﻿using System;
using System.Text;

namespace Cipher
{
    public class Util
    {
        private static int alpha = 29;

        private static double[] freq26 =
        {
            0.08167, 0.01492, 0.02782, 0.04253, 0.12702,
            0.02228, 0.02015, 0.06094, 0.06966, 0.00153,
            0.00772, 0.04025, 0.02406, 0.06749, 0.07507,
            0.01929, 0.00095, 0.05987, 0.06327, 0.09056,
            0.02758, 0.00978, 0.02360, 0.00150, 0.01974, 0.00074
        };

        private static double[] freq29 =
        {
            0.06564, 0.01144, 0.01587, 0.03797, 0.09952,
            0.01898, 0.01459, 0.06187, 0.05012, 0.00156,
            0.00585, 0.03109, 0.01942, 0.05614, 0.05937,
            0.01207, 0.00045, 0.04358, 0.04845, 0.07456,
            0.02025, 0.00787, 0.01712, 0.00076, 0.01436,
            0.00074, 0.18643, 0.01521, 0.00872
        };

        public static int Alpha { get { return alpha; } }

        public static double[] Freq
        {
            get
            {
                if (alpha == 29) return (double[])freq29.Clone();
                return (double[])freq26.Clone();
            }
        }

        public static char itoc(int i)
        {
            char c = '@';
            if (i >= 0 && i <= 25) c = (char)(i + 'A');
            if (alpha == 29)
            {
                if (i == 26) c = ' ';
                if (i == 27) c = ',';
                if (i == 28) c = '.';
            }
            return c;
        }

        public static int ctoi(char c)
        {
            int i = -1;
            if (Char.IsLetter(c)) i = (int)(Char.ToUpper(c)) - 'A';
            else if (alpha == 29)
            {
                if (c == ' ') i = 26;
                if (c == ',') i = 27;
                if (c == '.') i = 28;
                if (c == '?') i = 28;
                if (c == '!') i = 28;
                if (c == '\r') i = 26;
                if (c == '\n') i = 26;
                if (c == '\t') i = 26;
                if (c == '\f') i = 26;
            }
            return i;
        }

        public static double Distance(double[] e, double[] f)
        {
            if (e.Length != f.Length) return 0;
            double t = 0;
            for (int i = 0; i < e.Length; i++)
            {
                double d = e[i] - f[i];
                t += d * d;
            }
            return t;    
        }

        public static double[] Frequency(string s)
        {
            double[] f = new double[alpha];
            int k = 0;
            s = Strip(s);
            foreach (char c in s)
            {
                int d = ctoi(c);
                f[d]++;
                k++;
                if (k > 100) break;
            }
            for (int i = 0; i < alpha; i++)
            {
                f[i] /= k;
            }
            return f;
        }

        public static string Strip(string s)
        {
            StringBuilder sb = new StringBuilder();
            int k = 0;
            int j = 0;
            while (k < s.Length)
            {
                char c = Char.ToUpper(s[k++]);
                int i = ctoi(c);
                if (i > 25 && i == j) continue;
                if (i >= 0) j = i;
                if (i >= 0) sb.Append(itoc(i));
            }
            return sb.ToString();
        }

        public static string Altstring(string s, int j, int n)
        {
            if (n < 2 || n >= s.Length || j < 0 || j >= n) return s;
            string t = "";
            for (int i = j; i < s.Length; i += n)
            {
                t += s[i];
            }
            return t;
        }
    }
}
