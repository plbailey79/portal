﻿using System;
using System.Collections.Generic;
using System.Text;
using Math;

namespace Cipher
{
    public class Vigenere
    {
        public static int Alpha { get { return Util.Alpha; } }

        public static string Encrypt(string s, string w)
        {
            StringBuilder sb = new StringBuilder();
            int i = 0;
            s = Util.Strip(s);
            while (i < s.Length)
            {
                char c = s[i];
                int k = Util.ctoi(w[i % w.Length]);
                sb.Append(Util.itoc((Util.ctoi(c) + k) % Alpha));
                i++;
            }
            return sb.ToString();
        }

        public static string InvKey(string w)
        {
            string x = "";
            foreach (char c in w)
            {
                x += Util.itoc(Alpha - Util.ctoi(c));
            }
            return x;
        }

        public static string Wrap(string s, int k)
        {
            k = Number.Mod(k, s.Length);
            return s.Substring(k) + s.Substring(0, k);
        }

        public static int Coincidences(string s, int k)
        {
            int n = 0;
            string t = Wrap(s, k);
            for (int i = 0; i < s.Length; i++)
            {
                if (s[i] == t[i]) n++;
            }
            return n;
        }

        public static int GuessKeyLength(string s)
        {
            int m = 0;
            int l = 0;
            int e = s.Length;
            if (e > 32) e = 32;
            for (int k = 1; k < e; k++)
            {
                int n = Coincidences(s, k);
                //Console.WriteLine("{0}: {1}", k, n);
                if (n > m)
                {
                    m = n;
                    l = k;
                }
            }
            return l;
        }

        public static string GuessKey(string s, int n)
        {
            string w = "";
            for (int j = 0; j < n; j++)
            {
                string t = Util.Altstring(s, j, n);
                int k = Caesar.GuessKey(t);
                w += (char)(Util.itoc(k));
            }
           return w;
        }
    }
}
