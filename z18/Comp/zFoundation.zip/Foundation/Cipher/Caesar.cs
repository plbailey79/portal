﻿using System;
using System.Collections.Generic;
using System.Text;

using Math;

namespace Cipher
{
    public class Caesar
    {
        public static int Alpha { get { return Util.Alpha; } }

        public static string Encrypt(string s, int k)
        {
            StringBuilder sb = new StringBuilder();
            k = FixKey(k);
            s = Util.Strip(s);
            foreach (char c in s)
            {
                sb.Append(Util.itoc((Util.ctoi(c) + k) % Alpha));
            }
            return sb.ToString();
        }

        public static int FixKey(int k)
        {
            return Number.Mod(k, Alpha);
        }

        public static int InvKey(int k)
        {
            return Alpha - FixKey(k);
        }

        public static int GuessKey(string s)
        {
            double e = 1;
            int k = 0;
            
            for (int j = 0; j < Alpha; j++)
            {
                string u = Caesar.Encrypt(s, j);
                double[] f = Util.Frequency(u);
                double d = Util.Distance(Util.Freq, f);
                if (d < e)
                {
                    e = d;
                    k = j;
                }
            }
            return k;
        }
    }
}
