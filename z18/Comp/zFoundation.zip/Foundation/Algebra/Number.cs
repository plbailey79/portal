﻿using System;
using System.Collections.Generic;
using System.Numerics;

namespace Algebra
{
    public class Number
    {
        public static BigInteger Mod(BigInteger a, BigInteger n)
        {
            if (n == 0) return a;
            if (n < 0) n = -n;
            a = a % n;
            if (a < 0) a = a + n;
            return a;
        }

        public static BigInteger Gcd(BigInteger m, BigInteger n)
        {
            if (m < 0) m = -m;
            if (n < 0) n = -n;
            if (m == 0) return n;
            if (n == 0) return m;
            BigInteger r = n % m;
            if (r > 0) return Gcd(r, m);
            return m;
        }

        public static BigInteger Euc(BigInteger m, BigInteger n, ref BigInteger x, ref BigInteger y)
        {
            if (m == 0) return 0;
            if (n == 0) return 0;
            if (m < 0) m = -m;
            if (n < 0) n = -n;
            BigInteger q = n / m;
            BigInteger r = n % m;
            BigInteger d = m;
            x = 0;
            y = 1;
            if (r > 0) d = Euc(r, m, ref x, ref y);
            BigInteger t = y;
            y = x;
            x = t - q * x;
            return d;
        }

        public static BigInteger Inv(BigInteger m, BigInteger n)
        {
            if (n == 0)
            {
                if (m == 1) return 1;
                if (m == -1) return -1;
                return 0;
            }
            BigInteger x = 0;
            BigInteger y = 0;
            BigInteger d = Euc(m, n, ref x, ref y);
            if (d > 1)
            {
                x = 0;
            }
            if (x < 0) x = n - (-x % n);
            return x % n;
        }

        public static BigInteger Crt(BigInteger a, BigInteger b, BigInteger m, BigInteger n)
        {
            if (m == 0 || n == 0) return 0;
            if (m < 0) m = -m;
            if (n < 0) n = -n;
            BigInteger c = 0;
            BigInteger x = 0;
            BigInteger y = 0;
            BigInteger d = Euc(m, n, ref x, ref y);
            if (d == 1) c = m * x * b + n * y * a;
            return c % (m * n);
        }

        public static BigInteger Sqrt(BigInteger a)
        {
            BigInteger r = a;
            BigInteger s = a / 2;
            while (r > s)
            {
                r = s;
                s = (s + (a / s)) / 2;
            }
            return r;
        }

        public static List<BigInteger> Primes(BigInteger n)
        {
            List<BigInteger> primes = new List<BigInteger>();

            BigInteger k = 2;
            while (n > 1)
            {
                if (n % k == 0)
                {
                    primes.Add(k);
                }
                while (n % k == 0)
                {
                    n /= k;
                }
                k++;
            }
            return primes;
        }

        public static List<BigInteger> Factors(BigInteger n)
        {
            List<BigInteger> primes = new List<BigInteger>();

            BigInteger k = 2;
            while (n > 1)
            {
                while (n % k == 0)
                {
                    primes.Add(k);
                    n /= k;
                }
                k++;
            }
            return primes;
        }

        public static BigInteger Phi(BigInteger n)
        {
            List<BigInteger> primes = Primes(n);
            foreach (BigInteger p in primes)
            {
                n /= p;
            }
            foreach (BigInteger p in primes)
            {
                n *= (p - 1);
            }
            return n;
        }

        public static BigInteger Pow(BigInteger a, BigInteger e)
        {
            BigInteger p = 1;
            while (e > 0)
            {
                if ((e & 1) > 0) p *= a;
                a *= a;
                e >>= 1;
            }
            return p;
        }

        public static BigInteger Pow(BigInteger a, BigInteger e, BigInteger n) // Modular Exp
        {
            BigInteger p = 1;

            while (e > 0)
            {
                if ((e & 1) > 0)
                {
                    p *= a;
                    p %= n;
                }
                a *= a;
                e >>= 1;
            }
            return p;
        }

        public static BigInteger Pow(BigInteger a, BigInteger e, BigInteger n, BigInteger h) // Modular Exp
        {
            BigInteger p = 1;

            e = e % h;

            while (e > 0)
            {
                if ((e & 1) > 0)
                {
                    p *= a;
                    p %= n;
                }
                a *= a;
                e >>= 1;
            }
            return p;
        }

        public static BigInteger Parse(string s)
        {
            BigInteger x = 0;
            BigInteger y;
            if (BigInteger.TryParse(s, out y))
            {
                x = y;
            }
            return x;
        }
    }
}

