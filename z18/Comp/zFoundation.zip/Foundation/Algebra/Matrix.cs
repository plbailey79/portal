﻿using System;
using System.Collections.Generic;

namespace Algebra
{
    public class Matrix
    {
        private Rational[,] arr;
        private Reducer reducer;

        public int Rows { get { return arr.GetLength(0); } }
        public int Cols { get { return arr.GetLength(1); } }
        public bool IsSquare { get { return Rows == Cols; } }
        public int Rank { get { return reducer.Rank(); } }
        public Rational[,] Array { get { return (Rational[,])arr.Clone(); } }

        public Matrix()
        {
            arr = new Rational[0, 0];
        }

        public Matrix(params Vector[] vectors)
        {
            arr = new Rational[vectors[0].Length, vectors.Length];

            for (int j = 0; j < Cols; j++)
            {
                for (int i = 0; i < Rows; i++)
                {
                    if (i < vectors[j].Length) arr[i, j] = vectors[j][i];
                }
            }
        }

        public Matrix(Rational[,] arx)
        {
            Load(arx);
        }

        public Matrix(Matrix M)
        {
            Load(M.arr);
        }

        private void Load(Rational[,] arx)
        {
            int m = arx.GetLength(0);
            int n = arx.GetLength(1);
            arr = new Rational[m, n];
            for (int i = 0; i < m; i++)
            {
                for (int j = 0; j < n; j++)
                {
                    arr[i, j] = arx[i, j];
                }
            }
            reducer = new Reducer(arx);
        }

        public override string ToString()
        {
            string s = "[";

            for (int i = 0; i < Rows; i++)
            {
                if (i > 0) s += "|";
                for (int j = 0; j < Cols; j++)
                {
                    if (j > 0) s += ",";
                    s += arr[i, j];
                }
            }
            s += "]";
            return s;
        }

        public Vector RowVector(int i)
        {
            Rational[] a = new Rational[Cols];
            for (int j = 0; j < Cols; j++)
            {
                a[j] = arr[i, j];
            }
            return new Vector(a);
        }

        public Vector ColVector(int j)
        {
            Rational[] a = new Rational[Rows];
            for (int i = 0; i < Rows; i++)
            {
                a[i] = arr[i, j];
            }
            return new Vector(a);
        }

        // Reduction Methods: they are more efficient

        public Rational Determinant()
        {
            return reducer.Determinant();
        }

        public Matrix Inverse()
        {
            return new Matrix(reducer.Inverse());
        }

        public Matrix RowEchelon()
        {
            return new Matrix(reducer.RowEchelon());
        }

        public Matrix RedRowEchelon()
        {
            return new Matrix(reducer.RedRowEchelon());
        }

        public Matrix RowOperator()
        {
            return new Matrix(reducer.RowOperator());
        }

        public Matrix RedRowOperator()
        {
            return new Matrix(reducer.RedRowOperator());
        }

        // Inductive Methods: they are slower

        public Matrix CramerInverse()
        {
            Matrix A = Adjugate();
            Rational d = InductiveDeterminant();
            return ~d * A;
        }

        public Rational InductiveDeterminant()
        {
            if (!IsSquare) return new Rational();

            if (Rows == 1) return arr[0, 0];

            Rational d = new Rational();
            for (int j = 0; j < Cols; j++)
            {
                Matrix C = Comatrix(0, j);
                Rational e = arr[0, j];
                Rational c = C.InductiveDeterminant();
                if (j % 2 == 1) e = -e;
                d += e * c;
            }
            return d;
        }

        public Matrix Adjugate()
        {
            if (!IsSquare) return new Matrix();
            Rational[,] arx = new Rational[Rows, Cols];
            for (int i = 0; i < Rows; i++)
            {
                for (int j = 0; j < Cols; j++)
                {
                    Matrix C = Comatrix(i, j);
                    Rational d = C.Determinant();
                    if ((i + j) % 2 == 1) d = -d;
                    arx[j, i] = d;
                }
            }
            return new Matrix(arx);
        }

        public Matrix Comatrix(int i, int j)
        {
            Matrix M = new Matrix();
            if (Rows > 1 && Cols > 1 && i >= 0 && i < Rows && j >= 0 && j < Cols)
            {
                Rational[,] arx = new Rational[Rows - 1, Cols - 1];
                for (int x = 0; x < Rows - 1; x++)
                {
                    for (int y = 0; y < Cols - 1; y++)
                    {
                        arx[x, y] = arr[x >= i ? x + 1 : x, y >= j ? y + 1 : y];
                    }
                }
                M = new Matrix(arx);
            }
            return M;
        }

        // Static Methods

        public static Matrix Zero(int m, int n)
        {
            return new Matrix(Reducer.Zero(m, n));
        }

        public static Matrix Identity(int m, int n)
        {
            return new Matrix(Reducer.Identity(n));
        }

        // Operations

        public static Matrix operator ~(Matrix A)
        {
            return A.Inverse();
        }

        public static Matrix operator *(Matrix A, Matrix B)
        {
            if (A.Cols != B.Rows) return new Matrix();
            Rational[,] arx = new Rational[A.Rows, B.Cols];
            for (int i = 0; i < A.Rows; i++)
            {
                for (int k = 0; k < B.Cols; k++)
                {
                    Rational c = new Rational();
                    for (int j = 0; j < A.Cols; j++)
                    {
                        c += A.arr[i, j] * B.arr[j, k];
                    }
                    arx[i, k] = c;
                }
            }
            return new Matrix(arx);
        }

        public static Vector operator *(Matrix A, Vector v)
        {
            if (A.Cols != v.Length) return new Vector();
            Rational[] a = new Rational[A.Rows];
            for (int i = 0; i < A.Rows; i++)
            {
                Vector w = A.RowVector(i);
                a[i] = v * w;
            }
            return new Vector(a);
        }

        public static Matrix operator *(Rational a, Matrix A)
        {
            Rational[,] arx = new Rational[A.Rows, A.Cols];
            for (int i = 0; i < A.Rows; i++)
            {
                for (int j = 0; j < A.Cols; j++)
                {
                    arx[i, j] = a * A.arr[i, j];
                }
            }
            return new Matrix(arx);
        }
        
        // Array Methods

        public class Pivot
        {
            private int row;
            private int col;

            public int Row { get { return row; } }
            public int Col { get { return col; } }

            public Pivot(int i, int j)
            {
                row = i;
                col = j;
            }
        }

        public class Reducer
        {
            private static Rational[,] err = new Rational[0, 0];

            private Rational[,] ori; // Original Matrix
            private Rational[,] trg; // Target Matrix (result of row operations)
            private Rational[,] inv; // Product of Elementary Invertible Matrices

            private int state;       // 0=Initial  1=Singular  2=Forward (row ech)  3=Backward (red row ech)
            private Rational diag;
            private Pivot[] pivots;

            public int Rows { get { return ori.GetLength(0); } }
            public int Cols { get { return ori.GetLength(1); } }
            public bool IsSquare { get { return Rows == Cols; } }

            public Rational[,] Ori { get { return (Rational[,])ori.Clone(); } }
            public Rational[,] Trg { get { return (Rational[,])trg.Clone(); } }
            public Rational[,] Inv { get { return (Rational[,])inv.Clone(); } }
            public Pivot[] Pivots { get { return (Pivot[])pivots.Clone(); } }
            public int State { get { return state; } }

            public Reducer(Rational[,] arx)
            {
                ori = arx;
            }

            private void Initialize()
            {
                trg = (Rational[,])ori.Clone();
                inv = Identity(Rows);
                state = 0;
                diag = 0;
                pivots = new Pivot[0];
            }

            public Rational[,] Inverse()
            {
                if (Rows != Cols) return err;
                if (Forward(true)) return err;
                Backward();
                return (Rational[,])inv.Clone();
            }

            public int Rank()
            {
                Forward(false);
                return pivots.Length;
            }

            public Rational Determinant()
            {
                if (Rows != Cols) return 0;
                if (Forward(true)) return 0;
                return diag;
            }

            public Rational[,] RowEchelon()
            {
                if (state > 2) Initialize();
                Forward(false);
                return Trg;
            }

            public Rational[,] RedRowEchelon()
            {
                Forward(false);
                Backward();
                return Trg;
            }

            public Rational[,] RowOperator()
            {
                if (state > 2) Initialize();
                Forward(false);
                return Inv;
            }

            public Rational[,] RedRowOperator()
            {
                Forward(false);
                Backward();
                return Inv;
            }

            private bool Forward(bool stop) // Stop if singular, return true if singular
            {
                if (state < 1) Initialize();
                if (state >= 2) return false;
                if (state == 1 && stop) return true;
                int m = Rows;
                int n = Cols;
                int v = 0; // Next Potential Pivot Row
                List<Pivot> p = new List<Pivot>();

                if (stop && m != n) return true;

                diag = 1;

                // Forward Elimination
                for (int j = 0; j < n; j++)
                {
                    // Get the Pivot
                    if (trg[v, j] == 0)
                    {
                        for (int i = v + 1; i < m; i++)
                        {
                            if (trg[i, j] != 0)
                            {
                                RowOpP(trg, i, v);
                                RowOpP(inv, i, v);
                                break;
                            }
                        }
                    }
                    if (trg[v, j] == 0)
                    {
                        if (stop)
                        {
                            state = 1; // Singular
                            return true;
                        }
                        continue;
                    }

                    // Zeros Below
                    for (int i = v + 1; i < m; i++)
                    {
                        Rational c = -trg[i, j] / trg[v, j];
                        RowOpE(trg, i, v, c);
                        RowOpE(inv, i, v, c);
                    }
                    diag *= trg[v, j];
                    p.Add(new Pivot(v, j));
                    v += 1;
                }
                pivots = p.ToArray();
                state = 2; // Row Ech
                return false;
            }

            private void Backward()
            {
                if (state < 2) Forward(false);
                if (state >= 3) return;
                for (int k = pivots.Length - 1; k >= 0; k--)
                {
                    Pivot pivot = pivots[k];
                    int v = pivot.Row;
                    int j = pivot.Col;
                    Rational e = ~trg[v, j];
                    RowOpD(trg, v, e);
                    RowOpD(inv, v, e);

                    for (int i = pivot.Row - 1; i >= 0; i--)
                    {
                        Rational c = -trg[i, j];
                        RowOpE(trg, i, v, c);
                        RowOpE(inv, i, v, c);
                    }
                }
                state = 3; // Red Row Ech
            }

            public static Rational[,] Zero(int m, int n)
            {
                if (m < 1) m = 1;
                if (n < 1) n = 1;
                Rational[,] arx = new Rational[m, n];
                return arx;
            }

            public static Rational[,] Identity(int n)
            {
                if (n < 1) n = 1;
                Rational[,] arx = new Rational[n, n];
                for (int i = 0; i < n; i++)
                {
                    for (int j = 0; j < n; j++)
                    {
                        arx[i, j] = (i == j) ? Rational.One : Rational.Zero;
                    }
                }
                return arx;
            }

            public static void RowOpE(Rational[,] arx, int i, int k, Rational c)
            {
                for (int j = 0; j < arx.GetLength(1); j++)
                {
                    arx[i, j] += c * arx[k, j];
                }
            }

            public static void RowOpD(Rational[,] arx, int i, Rational c)
            {
                for (int j = 0; j < arx.GetLength(1); j++)
                {
                    arx[i, j] *= c;
                }
            }

            public static void RowOpP(Rational[,] arx, int i, int k)
            {
                Rational[] tmp = new Rational[arx.GetLength(1)];
                for (int j = 0; j < arx.GetLength(1); j++)
                {
                    tmp[j] = arx[k, j];
                }
                for (int j = 0; j < arx.GetLength(1); j++)
                {
                    arx[k, j] = arx[i, j];
                }
                for (int j = 0; j < arx.GetLength(1); j++)
                {
                    arx[i, j] = tmp[j];
                }
            }
        }
    }
}
