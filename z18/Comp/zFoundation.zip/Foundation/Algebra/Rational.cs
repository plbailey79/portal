﻿using System;
using System.Numerics;

namespace Algebra
{
    public class Rational : IComparable
    {
        private static Rational zero = new Rational();
        private static Rational one = new Rational(1);

        public static Rational Zero { get { return zero; } }
        public static Rational One { get { return one; } }

        private BigInteger top = 0;
        private BigInteger bot = 1;

        public bool IsZero { get { return top == 0 && bot == 1; } }
        public bool IsOne { get { return top == 1 && bot == 1; } }
        public Rational Abs { get { return this >= 0 ? this : -this; } }

        public Rational()
        { }

        public Rational(BigInteger top)
        {
            this.top = top;
            this.bot = 1;
        }

        public Rational(BigInteger top, BigInteger bot)
        {
            this.top = top;
            this.bot = bot;
            Check();
        }

        private void Check()
        {
            if (top == 0 || bot == 0)
            {
                top = 0;
                bot = 1;
                return;
            }
            if (bot < 0)
            {
                top = -top;
                bot = -bot;
            }
            BigInteger d = Number.Gcd(top, bot);
            top /= d;
            bot /= d;
        }

        public override string ToString()
        {
            if (bot == 1) return top + "";
            return top + "/" + bot;
        }

        public override bool Equals(object obj)
        {
            if ((obj == null) || !this.GetType().Equals(obj.GetType()))
            {
                return false;
            }
            Rational that = (Rational)obj;
            return this.top == that.top && this.bot == that.bot;
        }

        public override int GetHashCode()
        {
            return base.GetHashCode();
        }

        public int CompareTo(object obj)
        {
            if ((obj == null) || !this.GetType().Equals(obj.GetType()))
            {
                return -1;
            }
            Rational that = (Rational)obj;

            BigInteger dif = this.top * that.bot - that.top * this.bot;

            if (dif < 0) return -1;
            if (dif > 0) return 1;
            return 0;
        }

        public static implicit operator Rational(BigInteger a)
        {
            return new Rational(a);
        }

        public static explicit operator BigInteger(Rational x)
        {
            return x.top / x.bot;
        }

        public static implicit operator Rational(int a)
        {
            return new Rational(a);
        }

        public static explicit operator double(Rational x)
        {
            return (double)x.top / (double)x.bot;
        }

        public static Rational operator -(Rational x)
        {
            return new Rational(-x.top, x.bot);
        }

        public static Rational operator ~(Rational x)
        {
            return new Rational(x.bot, x.top);
        }

        public static Rational operator +(Rational x, Rational y)
        {
            return new Rational(x.top * y.bot + x.bot * y.top, x.bot * y.bot);
        }

        public static Rational operator -(Rational x, Rational y)
        {
            return new Rational(x.top * y.bot - x.bot * y.top, x.bot * y.bot);
        }

        public static Rational operator *(Rational x, Rational y)
        {
            return new Rational(x.top * y.top, x.bot * y.bot);
        }

        public static Rational operator /(Rational x, Rational y)
        {
            return new Rational(x.top * y.bot, x.bot * y.top);
        }

        public static bool operator ==(Rational x, Rational y)
        {
            return (x ?? zero).Equals(y);
        }

        public static bool operator !=(Rational x, Rational y)
        {
            return !x.Equals(y);
        }

        public static bool operator <=(Rational x, Rational y)
        {
            return x.CompareTo(y) <= 0;
        }

        public static bool operator >=(Rational x, Rational y)
        {
            return x.CompareTo(y) >= 0;
        }

        public static bool operator <(Rational x, Rational y)
        {
            return x.CompareTo(y) < 0;
        }

        public static bool operator >(Rational x, Rational y)
        {
            return x.CompareTo(y) > 0;
        }
    }
}
