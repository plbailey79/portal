﻿using System;
using System.Numerics;

namespace Algebra
{
    public class Factor
    {
        public static BigInteger Trial(BigInteger n)
        {
            if (n % 2 == 0) return 2;
            BigInteger q = Number.Sqrt(n);
            BigInteger a = 3;
            while (a <= q)
            {
                if (n % a == 0) return a;
                a += 2;
            }
            return 0;
        }

        public static BigInteger Fermat(BigInteger n)
        {
            BigInteger a = 0;
            BigInteger q = Number.Sqrt(n);
            if (n == q * q) return q;
            BigInteger b = 0;
            q = q + 1;
            b = q * q - n;
            while (b < n)
            {
                BigInteger k = Number.Sqrt(b);
                if (b == k * k) return q - k;
                b = b + 2 * q + 1;
                q = q + 1;
            }
            return n;
        }

        public static BigInteger Pollard(BigInteger n)
        {
            BigInteger a = 2;
            BigInteger B = Number.Sqrt(Number.Sqrt(n));
            return Pollard(n, B, a);
        }

        public static BigInteger Pollard(BigInteger n, BigInteger B, BigInteger a)
        {
            BigInteger b = a;
            BigInteger k = 1;
            while (k <= B)
            {
                b = BigInteger.ModPow(b, k, n);
                k = k + 1;
            }
            return Number.Gcd(b - 1, n);
        }

        public static BigInteger Rho(BigInteger n)
        {
            BigInteger y = 1;
            Func<BigInteger, BigInteger> f = x => (x * x + 1);
            return Rho(n, y, f);
        }

        public static BigInteger Rho(BigInteger n, BigInteger y, Func<BigInteger, BigInteger> f)
        {
            BigInteger z = f(y) % n;
            BigInteger x = Number.Gcd(z - y, n);
            while (x == 1)
            {
                y = f(y) % n;
                z = f(z) % n;
                z = f(z) % n;
                x = Number.Gcd(z - y, n);
            }
            if (x == n) x = 1;
            return x;
        }
    }
}
