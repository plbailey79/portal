﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Algebra
{
    public class Point
    {
        private Rational x = Rational.Zero;
        private Rational y = Rational.Zero;

        public Rational X { get { return x; } }
        public Rational Y { get { return y; } }

        public Point()
        { }

        public Point(Rational x, Rational y)
        {
            this.x = x;
            this.y = y;
        }

        public override bool Equals(object obj)
        {
            if ((obj == null) || !this.GetType().Equals(obj.GetType()))
            {
                return false;
            }
            Point that = (Point)obj;
            return this.x == that.x && this.y == that.y;
        }

        public override int GetHashCode()
        {
            return base.GetHashCode();
        }
    }
}
