﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Algebra
{
    public class Sieve
    {
        private int[] primes = new int[0];
        private int[] checks = new int[0];

        public int Length { get { return primes.Length; } }
        public List<int> Primes { get { return primes.ToList<int>(); } }

        public int this[int i]
        {
            get
            {
                int p = 0;
                if (i >= 0 && i < primes.Length) p = primes[i];
                return p;
            }
        }

        public Sieve()
        { }

        public Sieve(int n)
        {
            Fill(n);
        }

        public void Fill(int n) // primes less than n absolute
        {
            if (n < 0) n = 0;
            int c = Check(n);
            int k = 0;
            primes = new int[c + 1];
            primes[k++] = 2;
            for (int i = 0; i < checks.Length; i++)
            {
                if (checks[i] == 2)
                {
                    primes[k++] = Num(i);
                }
                if (k > c) break;
            }
        }

        public int Check(int n) // 1 = composite  2 = prime  0 = not checked  Return # primes
        {
            checks = new int[Idx(n) + 1];
            int c = 0;
            int i = 0;
            while (i < checks.Length)
            {
                if (checks[i] == 0)
                {
                    checks[i] = 2;
                    c++;
                    int a = Num(i);
                    int b = a;
                    int j = 0;
                    while ((j = Idx(b += 2 * a)) < checks.Length)
                    {
                        checks[j] = 1;
                    }
                }
                i++;
            }
            return c;
        }

        public static int Num(int idx)
        {
            return idx * 2 + 3;
        }

        public static int Idx(int num)
        {
            return ((num - 1) / 2) - 1;
        }

        public static void Test()
        {
            Sieve sieve = new Sieve(1000000);
            for (int i = 0; i < sieve.Length; i++)
            {
                Console.WriteLine("[{0}] = {1}", i, sieve[i]);
            }
        }
    }
}
