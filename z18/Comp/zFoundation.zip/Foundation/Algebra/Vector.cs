﻿using System;

namespace Algebra
{
    public class Vector
    {
        private Rational[] arr;

        public int Length
        {
            get { return arr.Length; }
        }

        public Rational this[int i]
        {
            get
            {
                return arr[i];
            }
        }

        public Vector(params Rational[] arr)
        {
            this.arr = new Rational[arr.Length];
            for (int i = 0; i < arr.Length; i++)
            {
                this.arr[i] = arr[i];
            }
        }

        public override string ToString()
        {
            string s = "[";
            for (int i = 0; i < arr.Length; i++)
            {
                if (i > 0) s += ",";
                s += arr[i];
            }
            s += "]";
            return s;
        }

        public static Rational operator *(Vector v, Vector w)
        {
            Rational e = new Rational();
            if (v.Length > 0 && v.Length == w.Length)
            {
                e = 0;
                for (int i = 0; i < v.Length; i++)
                {
                    e = e + v[i] * w[i];
                }
            }
            return e;
        }
    }
}
