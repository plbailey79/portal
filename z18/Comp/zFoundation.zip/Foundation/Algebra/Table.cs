﻿using System;
using System.Collections.Generic;

namespace Algebra
{
    public class Table : List<Point>
    {
        public List<Rational> Domain
        {
            get
            {
                List<Rational> xs = new List<Rational>();
                foreach (Point point in this)
                {
                    xs.Add(point.X);
                }
                return xs;
            }
        }
        
        public Polynomial Cardinal(int i)
        {
            Polynomial l = Polynomial.One;
            int n = this.Count - 1;

            for (int j = 0; j <= n; j++)
            {
                if (i == j) continue;
                Rational c = -this[j].X;
                Rational b = this[i].X - this[j].X;
                Polynomial m = new Polynomial(c / b, 1 / b);
                l *= m;
            }
            return l;
        }

        public Polynomial LaGrange()
        {
            Polynomial f = Polynomial.Zero;
            int n = this.Count - 1;
            for (int i = 0; i <= n; i++)
            {
                Rational y = this[i].Y;
                f += y * Cardinal(i);
            }
            return f;
        }

        public Polynomial Newton()
        {
            Polynomial f = Polynomial.Zero;
            Polynomial z = Polynomial.One;
            int n = this.Count - 1;

            for (int i = 0; i <= n; i++)
            {
                Rational x = this[i].X;
                Rational y = this[i].Y;
                Rational c = (y - f.Value(x)) / z.Value(x);
                f += c * z;
                z *= new Polynomial(-x, 1);
            }
            return f;
        }
    }
}
