﻿using System;
using System.Text;

namespace Algebra
{
    public class Polynomial
    {
        private static Polynomial zero = new Polynomial();
        private static Polynomial one = new Polynomial(1);

        public static Polynomial Zero { get { return zero; } }
        public static Polynomial One { get { return one; } }

        private Rational[] coefs = new Rational[0];

        public Rational this[int i]
        {
            get
            {
                Rational a = 0;
                if (i >= 0 && i < coefs.Length) a = coefs[i];
                return a;
            }
        }

        public int Deg { get { return coefs.Length - 1; } }
        public Rational LC { get { return coefs[coefs.Length - 1]; } }
        public Rational CC { get { return coefs[0]; } }
        public bool IsZero { get { return Equals(zero); } }
        public bool IsOne { get { return Equals(one); } }
        public bool IsMonic { get { return LC.IsOne; } }

        public Polynomial Derivative
        {
            get
            {
                Rational[] C = new Rational[Deg];
                for (int i = 1; i < coefs.Length; i++)
                {
                    C[i - 1] = i * coefs[i];
                }
                return new Polynomial(C);
            }
        }

        public Polynomial Antiderivative
        {
            get
            {
                Rational[] C = new Rational[Deg + 2];
                for (int i = 0; i < coefs.Length; i++)
                {
                    C[i + 1] = coefs[i] / (i + 1);
                }
                C[0] = 0;
                return new Polynomial(C);
            }
        }

        public Polynomial Monic
        {
            get
            {
                Rational[] C = new Rational[coefs.Length];
                Rational x = LC;
                for (int i = 0; i < C.Length; i++)
                {
                    C[i] = coefs[i] / x;
                }
                return new Polynomial(C);
            }
        }

        public Polynomial()
        { }

        public Polynomial(params Rational[] coefs)
        {
            Install(coefs);
        }

        private void Install(Rational[] coefs)
        {
            int n = coefs.Length;
            while (n > 0 && coefs[n - 1] == null) n--;
            while (n > 0 && coefs[n - 1].IsZero) n--;

            this.coefs = new Rational[n];
            for (int i = 0; i < n; i++)
            {
                Rational x = coefs[i];
                if (x == null) x = 0;
                this.coefs[i] = x;
            }
        }

        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();

            sb.Append('[');

            for (int i = 0; i < coefs.Length; i++)
            {
                if (i > 0) sb.Append(',');
                sb.Append(coefs[i]);
            }
            sb.Append(']');
            return sb.ToString();
        }

        public override bool Equals(object obj)
        {
            if ((obj == null) || !this.GetType().Equals(obj.GetType()))
            {
                return false;
            }
            Polynomial that = (Polynomial)obj;
            if (this.coefs.Length != that.coefs.Length) return false;
            
            for (int i = 0; i < this.coefs.Length; i++)
            {
                if (this[i] != that[i]) return false;
            }
            return true;
        }

        public override int GetHashCode()
        {
            return base.GetHashCode();
        }

        public Rational Value(Rational x)
        {
            if (coefs.Length == 0) return Rational.Zero;
            Rational y = coefs[coefs.Length - 1];
            for (int i = coefs.Length - 2; i >= 0; i--)
            {
                y *= x;
                y += coefs[i];
            }
            return y;
        }

        public static Polynomial Gcd(Polynomial f, Polynomial g)
        {
            if (f.IsZero) return g;
            if (g.IsZero) return f;
            Polynomial r = g % f;
            if (!r.IsZero) return Gcd(r, f);
            return f.Monic;
        }

        public static Polynomial Euc(Polynomial g, Polynomial f, ref Polynomial x, ref Polynomial y)
        {
            if (f.IsZero) return Zero;
            if (g.IsZero) return Zero;
            Polynomial q = f / g;
            Polynomial r = f % g;
            Polynomial d = g;
            x = Zero;
            y = One;
            if (!r.IsZero) d = Euc(r, g, ref x, ref y);
            Polynomial t = y;
            y = x;
            x = t - q * x;
            if (!d.IsMonic)
            {
                Rational c = d.LC;
                x /= c;
                y /= c;
                d /= c;
            }
            return d;
        }

        public static Polynomial Inv(Polynomial g, Polynomial f)
        {
            if (f.IsZero)
            {
                return Zero;
            }
            Polynomial x = Zero;
            Polynomial y = Zero;
            Polynomial d = Euc(g, f, ref x, ref y);
            if (d.Deg > 0)
            {
                x = Zero;
            }
            return x % f;
        }

        public static implicit operator Polynomial(Rational x)
        {
            return new Polynomial(x);
        }

        public static Polynomial operator +(Polynomial f, Polynomial g)
        {
            Rational[] C = new Rational[(f.Deg > g.Deg ? f.Deg : g.Deg) + 1];
            for (int i = 0; i < C.Length; i++)
            {
                C[i] = f[i] + g[i];
            }
            return new Polynomial(C);
        }

        public static Polynomial operator -(Polynomial f, Polynomial g)
        {
            Rational[] C = new Rational[(f.Deg > g.Deg ? f.Deg : g.Deg) + 1];
            for (int i = 0; i < C.Length; i++)
            {
                C[i] = f[i] - g[i];
            }
            return new Polynomial(C);
        }

        public static Polynomial operator *(Polynomial f, Polynomial g)
        {
            Rational[] C = new Rational[f.Deg + g.Deg + 1];
            for (int k = 0; k < C.Length; k++)
            {
                Rational a = 0;
                for (int i = 0; i < C.Length; i++)
                {
                    int j = k - i;
                    a += f[i] * g[j];
                }
                C[k] = a;
            }
            return new Polynomial(C);
        }

        //public static Polynomial operator /(Polynomial f, Polynomial g)
        //{
        //    if (g.Deg > f.Deg) return Zero;
        //    Rational[] C = new Rational[f.Deg - g.Deg + 1];
        //    while (f.Deg >= g.Deg)
        //    {
        //        Rational lc = f.LC / g.LC;
        //        int deg = f.Deg - g.Deg;
        //        Polynomial h = Monomial(lc, deg);
        //        Console.WriteLine("f: {0}  g: {1}  h: {2}", f, g, h);
        //        C[deg] = lc;
        //        f -= h * g;
        //    }
        //    return new Polynomial(C);
        //}

        public static Polynomial operator /(Polynomial f, Polynomial g)
        {
            Polynomial q, r;
            Divide(f, g, out q, out r);
            return q;
        }

        public static Polynomial operator %(Polynomial f, Polynomial g)
        {
            Polynomial q, r;
            Divide(f, g, out q, out r);
            return r;
        }

        public static void Divide(Polynomial f, Polynomial g, out Polynomial q, out Polynomial r)
        {
            if (g.Deg > f.Deg)
            {
                q = Zero;
                r = f;
                return;
            }
            Rational[] C = new Rational[f.Deg - g.Deg + 1];
            while (f.Deg >= g.Deg)
            {
                Rational lc = f.LC / g.LC;
                int deg = f.Deg - g.Deg;
                Polynomial h = Monomial(lc, deg);
                C[deg] = lc;
                f -= h * g;
            }
            q = new Polynomial(C);
            r = f;
        }

        public static Polynomial Monomial(Rational lc, int deg)
        {
            Rational[] C = new Rational[deg + 1];
            for (int i = 0; i < deg; i++)
            {
                C[i] = 0;
            }
            C[deg] = lc;
            return new Polynomial(C);
        }
    }
}
