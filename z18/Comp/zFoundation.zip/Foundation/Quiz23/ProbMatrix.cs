﻿using System;
using Algebra;
namespace Quiz23
{
    class ProbMatrix
    {
        public static void Go()
        {
            Matrix A = BuildMatrix();
            Console.WriteLine("Rank: {0}", A.Rank);
            Show(A.Array);
            Show(A.RowEchelon().Array);
            Show(A.RedRowEchelon().Array);
        }

        public static Matrix BuildMatrix()
        {
            int m = 50;
            int n = 100;
            Rational[,] arx = new Rational[m, n];

            for (int i = 0; i < m; i++)
            {
                for (int j = 0; j < n; j++)
                {
                    arx[i, j] = (i + 1) * (j + 1) % 10;
                }
            }
            return new Matrix(arx);


        }

        public static void Show(Rational[,] arr)
        {
            Console.WriteLine();
            for (int i = 0; i < arr.GetLength(0); i++)
            {
                for (int j = 0; j < arr.GetLength(1); j++)
                {
                    Console.Write(arr[i, j]); // + " ");
                }
                Console.WriteLine();
            }
        }
    }
}
