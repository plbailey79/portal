﻿using System;
using Algebra;

namespace Quiz23
{
    class ProbPoly
    {
        public static void Go()
        {
            Table tf = new Table();
            tf.Add(new Point(0, 12));
            tf.Add(new Point(1, 0));
            tf.Add(new Point(2, 56));
            tf.Add(new Point(3, 840));
            tf.Add(new Point(4, 4788));
            tf.Add(new Point(5, 18032));
            tf.Add(new Point(6, 53040));

            Table tg = new Table();
            tg.Add(new Point(0, -18));
            tg.Add(new Point(1, 72));
            tg.Add(new Point(2, 868));
            tg.Add(new Point(3, 4680));
            tg.Add(new Point(4, 17442));
            tg.Add(new Point(5, 51352));
            tg.Add(new Point(6, 128232));

            Polynomial f = tf.LaGrange();
            Polynomial g = tg.LaGrange();
            Polynomial d = Polynomial.Gcd(f, g);

            Console.WriteLine("f: {0}", f);
            Console.WriteLine("g: {0}", g);
            Console.WriteLine("d: {0}", d);

            Rational v = 0;
            v = 0; Console.WriteLine("f({0}) = {1}", v, f.Value(v));
            v = 1; Console.WriteLine("f({0}) = {1}", v, f.Value(v));
            v = 2; Console.WriteLine("f({0}) = {1}", v, f.Value(v));
            v = 3; Console.WriteLine("f({0}) = {1}", v, f.Value(v));
            v = 4; Console.WriteLine("f({0}) = {1}", v, f.Value(v));
            v = 5; Console.WriteLine("f({0}) = {1}", v, f.Value(v));
            v = 6; Console.WriteLine("f({0}) = {1}", v, f.Value(v));

            v = 0; Console.WriteLine("g({0}) = {1}", v, g.Value(v));
            v = 1; Console.WriteLine("f({0}) = {1}", v, g.Value(v));
            v = 2; Console.WriteLine("g({0}) = {1}", v, g.Value(v));
            v = 3; Console.WriteLine("g({0}) = {1}", v, g.Value(v));
            v = 4; Console.WriteLine("g({0}) = {1}", v, g.Value(v));
            v = 5; Console.WriteLine("g({0}) = {1}", v, g.Value(v));
            v = 6; Console.WriteLine("g({0}) = {1}", v, g.Value(v));


            v = -2; Console.WriteLine("d({0}) = {1}", v, d.Value(v));

            // Riley
            v = new Rational(3, 4);
            Console.WriteLine("d({0}) = {1}", v, d.Value(v));

            // Kasi
            Polynomial k1 = f / d;
            Console.WriteLine("k1: {0}", k1);

            // Harsha
            Polynomial k2 = g / d;
            Polynomial k = k1 - k2;

            Console.WriteLine("k1: {0}", k1);
            Console.WriteLine("k: {0}", k);


            //Polynomial x = Polynomial.Zero;
            //Polynomial y = Polynomial.Zero;
            //Polynomial.Euc(g, f, ref x, ref y);
            //Console.WriteLine("x: {0}", x);
            //Console.WriteLine("y: {0}", y);
        }

        public static void Build()
        {
            Polynomial f1 = new Polynomial(6, 3, 2, 1);
            Polynomial f2 = new Polynomial(2, -2, -1, 1);
            Polynomial f = f1 * f2;

            Polynomial g1 = f1;
            Polynomial g2 = new Polynomial(-3, 3, 5, 1);
            Polynomial g = g1 * g2;

            Polynomial h = f - g;

            Console.WriteLine("f: {0}", f);
            Console.WriteLine("g: {0}", g);
            Console.WriteLine("gcd(f,g): {0}", Polynomial.Gcd(f, g));

            Console.WriteLine("deg(f) = {0}", f.Deg);
            Console.WriteLine("h: {0}", h);

            int v = 0;
            v = 0; Console.WriteLine("f({0}) = {1}", v, f.Value(v));
            v = 1; Console.WriteLine("f({0}) = {1}", v, f.Value(v));
            v = 2; Console.WriteLine("f({0}) = {1}", v, f.Value(v));
            v = 3; Console.WriteLine("f({0}) = {1}", v, f.Value(v));
            v = 4; Console.WriteLine("f({0}) = {1}", v, f.Value(v));
            v = 5; Console.WriteLine("f({0}) = {1}", v, f.Value(v));
            v = 6; Console.WriteLine("f({0}) = {1}", v, f.Value(v));

            v = 0; Console.WriteLine("g({0}) = {1}", v, g.Value(v));
            v = 1; Console.WriteLine("f({0}) = {1}", v, g.Value(v));
            v = 2; Console.WriteLine("g({0}) = {1}", v, g.Value(v));
            v = 3; Console.WriteLine("g({0}) = {1}", v, g.Value(v));
            v = 4; Console.WriteLine("g({0}) = {1}", v, g.Value(v));
            v = 5; Console.WriteLine("g({0}) = {1}", v, g.Value(v));
            v = 6; Console.WriteLine("f({0}) = {1}", v, g.Value(v));
        }
    }
}

    
