﻿using System;
using System.Collections.Generic;
using System.Numerics;
using Algebra;

namespace Quiz23
{
    class ProbSieve
    {
        public static void Go()
        {
            Sieve sieve = new Sieve(16000000);
            List<int> primes = sieve.Primes;

            NumberLessThan(primes, 150);
            NumberLessThan(primes, 15000000);

            NumberLessThanSecondDigit(primes, 150, 3);
            NumberLessThanSecondDigit(primes, 15000000, 3);

            Sum(primes, 150);
            Sum(primes, 15000000);

            ProductLastFourDigits(primes, 150);
            ProductLastFourDigits(primes, 15000000);
        }

        public static void NumberLessThan(List<int> primes, int n)
        {
            int c = 0;
            foreach(int p in primes)
            {
                if (p >= n) break;
                c++;
            }

            Console.WriteLine("Number of primes less than {0} is {1}", n, c);
        }

        public static void NumberLessThanSecondDigit(List<int> primes, int n, int d)
        {
            int c = 0;
            foreach (int p in primes)
            {
                if (p >= n) break;
                if ((p % 100) / 10 == d)
                {
                    c++;
                    //Console.WriteLine(p);
                }
            }
            Console.WriteLine("Number of primes less than {0} second digit {1} is {2}", n, d, c);
        }

        public static void Sum(List<int> primes, int n)
        {
            BigInteger c = 0;
            foreach (int p in primes)
            {
                if (p >= n) break;
                c += p;
                //if (n <= 100) Console.WriteLine("p: {0}  c: {1}", p, c);
            }
            Console.WriteLine("Sum of primes less than {0} is {1}", n, c);
        }

        public static void ProductLastFourDigits(List<int> primes, int n)
        {
            BigInteger c = 1;
            foreach (int p in primes)
            {
                if (p == 2) continue;
                if (p == 5) continue;
                if (p >= n) break;
                c = (c * (p % 10000)) % 10000;
                //if (k++ % 10000 == 0) Console.WriteLine("p: {0}  c: {1}", p % 10000, c);
            }
            Console.WriteLine("Last four digits of product of primes less than {0} is {1}", n, c);
        }
    }
}
