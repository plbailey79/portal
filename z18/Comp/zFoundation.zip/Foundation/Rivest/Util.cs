﻿using System;
using System.Numerics;

namespace Rivest
{
    class Util
    {
        public const int alpSize = 27;
        public const char alpChar = '@';


        public static char itoc(BigInteger i)
        {
            char c = '@';
            if (i == 0) c = ' ';
            if (i >= 1 && i <= 26) c = (char)(i + alpChar);
            return c;
        }

        public static BigInteger ctoi(char c)
        {
            BigInteger i = (int)c - alpChar;
            if (i < 0 || i > 26)
            {
                if (!char.IsLetter(c)) i = 0;
            }
            return i;
        }
    }
}
