﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Numerics;

namespace Rivest
{ 
    public class Message
    {
        public static string Strip(string s)
        {
            StringBuilder sb = new StringBuilder();
            int k = 0;
            while (k < s.Length)
            {
                char c = Char.ToUpper(s[k]);
                if (Char.IsLetter(c)) sb.Append(c);
                else
                {
                    if (Char.IsLetter(s[k - 1])) sb.Append(' ');
                    else sb.Append("");
                }
                k++;
            }
            return sb.ToString();
        }

        public static char itoc(BigInteger i)
        {
            char c = '@';
            if (i == 0) c = ' ';
            if (i >= 1 && i <= 26) c = (char)(i + 64);
            return c;
        }

        public static BigInteger ctoi(char c)
        {
            BigInteger i = (int)c - 64;
            if (i < 1 || i > 26)
            {
                i = -1;
                if (c == ' ') i = 0;
            }
            return i;
        }

        public static BigInteger StringToNumber(string s)
        {
            int k = 0;
            BigInteger b = 1;
            s = Strip(s);
            BigInteger t = 0;
            while (k < s.Length)
            {
                t += ctoi(s[k++]) * b;
                b *= 27;
            }            
            return t;
        }

        public static string NumberToString(BigInteger n)
        {
            BigInteger b = 27;
            StringBuilder sb = new StringBuilder();
            while (n > 0)
            {
                BigInteger r = n % b;
                n = n / b;
                sb.Append((char)(itoc(r)));
            }
            return sb.ToString();
        }

        public static List<BigInteger> NumberToSequence(BigInteger a, BigInteger n)
        {
            List<BigInteger> ans = new List<BigInteger>();
            while (a > 0)
            {
                BigInteger r = a % n;
                a /= n;
                ans.Add(r);
            }
            return ans;
        }

        public static BigInteger SequenceToNumber(List<BigInteger> L, BigInteger n)
        {
            BigInteger ans = 0;
            BigInteger b = 1;
            foreach (BigInteger a in L)
            {
                ans += a * b;
                b *= n;
            }
            return ans;
        }

        public static BigInteger EncryptChunk(BigInteger a, BigInteger n, BigInteger e)
        {
            return BigInteger.ModPow(a, e, n);
        }

        public static List<BigInteger> EncryptSequence(List<BigInteger> L, BigInteger n, BigInteger e)
        {
            List<BigInteger> ans = new List<BigInteger>();
            foreach (BigInteger a in L)
            {
                ans.Add(EncryptChunk(a, n, e));
            }
            return ans;
        }

        public static BigInteger EncryptNumber(BigInteger a, BigInteger n, BigInteger e)
        {
            List<BigInteger> x = new List<BigInteger>();
            x = NumberToSequence(a, n);
            return SequenceToNumber(EncryptSequence(x, n, e), n);
        }

        public static string EncryptString(string s, BigInteger n, BigInteger e)
        {
            BigInteger x = StringToNumber(s);
            BigInteger y = EncryptNumber(x, n, e);
            return NumberToString(y);
        }
    }
}
